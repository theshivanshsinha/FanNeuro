from flask import Flask, render_template, Response, redirect, url_for, request, jsonify
from flask_pymongo import PyMongo
from flask_bcrypt import Bcrypt
from flask_cors import CORS, cross_origin
import cv2
import threading
import pandas as pd
from datetime import datetime
import numpy as np
from deepface import DeepFace
import logging
import os
from bson import ObjectId
from flask import request
from twilio.rest import Client
import random
from flask_mail import Mail, Message 
import uuid
import time
from bson import json_util
import json
from bson.json_util import dumps
import traceback
from datetime import timedelta


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "http://localhost:3000"}})
app.config["MONGO_URI"] = "mongodb://localhost:27017/fanneuro"
app.config["UPLOAD_FOLDER"] = "./profile_photos"  # Folder to store profile photos

mongo = PyMongo(app)
bcrypt = Bcrypt(app)
mail = Mail(app) # instantiate the mail class



# Your Twilio account SID and auth token
account_sid = 'AC704889b352cf8bce8d4ebaf8c089c200'
auth_token = '346df5a4ac43ea27c74598d7679a8ab6'
twilio_client = Client(account_sid, auth_token)
twilio_phone_number = '+919905498909'

#mail OTP config
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USERNAME'] = 'f20221227@hyderabad.bits-pilani.ac.in'  
app.config['MAIL_PASSWORD'] = 'cnrb wfib ymqu cfbu'     
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False
mail = Mail(app)


# Global variables
emotion_detection_running = False
cap = None
emotion = "No face detected"
heart_rate = "Calculating..."
emotion_thread = None
user_input_text = "No input"
df = pd.DataFrame(columns=["timestamp", "emotion", "heart_rate", "user_input"])

# Gaussian Pyramid and Heart Rate Functions
def build_gauss(frame, levels):
    pyramid = [frame]
    for level in range(levels):
        frame = cv2.pyrDown(frame)
        pyramid.append(frame)
    return pyramid

def reconstruct_frame(pyramid, index, levels, video_height, video_width):
    filtered_frame = pyramid[index]
    for level in range(levels):
        filtered_frame = cv2.pyrUp(filtered_frame)
    filtered_frame = filtered_frame[:video_height, :video_width]
    return filtered_frame

def process_frame(frame, video_height, real_height, video_width, real_width, levels, buffer_size, buffer_index, alpha, min_frequency, max_frequency, video_frame_rate, fourier_transform_avg, mask, frequencies, video_gauss):
    detection_frame = frame[video_height // 2:real_height - video_height // 2, video_width // 2:real_width - video_width // 2, :]
    video_gauss[buffer_index] = build_gauss(detection_frame, levels + 1)[levels]
    fourier_transform = np.fft.fft(video_gauss, axis=0)
    fourier_transform[mask == False] = 0

    for buf in range(buffer_size):
        fourier_transform_avg[buf] = np.real(fourier_transform[buf]).mean()
    hz = frequencies[np.argmax(fourier_transform_avg)]
    bpm = 60.0 * hz

    filtered = np.real(np.fft.ifft(fourier_transform, axis=0))
    filtered = filtered * alpha

    filtered_frame = reconstruct_frame(filtered, buffer_index, levels, video_height, video_width)
    output_frame = detection_frame + filtered_frame
    output_frame = cv2.convertScaleAbs(output_frame)
    
    return output_frame, bpm

def heart_rate_monitor(webcam, video_width, video_height, real_width, real_height, levels, alpha, min_frequency, max_frequency, buffer_size, video_frame_rate):
    global heart_rate, emotion_detection_running, df, user_input_text
    first_frame = np.zeros((video_height, video_width, 3))
    first_gauss = build_gauss(first_frame, levels + 1)[levels]
    video_gauss = np.zeros((buffer_size, first_gauss.shape[0], first_gauss.shape[1], 3))
    fourier_transform_avg = np.zeros((buffer_size))

    frequencies = (1.0 * video_frame_rate) * np.arange(buffer_size) / (1.0 * buffer_size)
    mask = (frequencies >= min_frequency) & (frequencies <= max_frequency)

    bpm_buffer_index = 0
    bpm_buffer_size = 10
    bpm_buffer = np.zeros((bpm_buffer_size))

    buffer_index = 0
    while emotion_detection_running:
        ret, frame = webcam.read()
        if not ret:
            logger.warning("Failed to capture frame")
            break

        output_frame, bpm = process_frame(frame, video_height, real_height, video_width, real_width, levels, buffer_size, buffer_index, alpha, min_frequency, max_frequency, video_frame_rate, fourier_transform_avg, mask, frequencies, video_gauss)

        buffer_index = (buffer_index + 1) % buffer_size
        frame[video_height // 2:real_height - video_height // 2, video_width // 2:real_width - video_width // 2, :] = output_frame
        cv2.rectangle(frame, (video_width // 2, video_height // 2), (real_width - video_width // 2, real_height - video_height // 2), (0, 255, 0), 3)

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        heart_rate = bpm
        df = pd.concat([df, pd.DataFrame([{"timestamp": timestamp, "emotion": emotion, "heart_rate": bpm, "user_input": user_input_text}])], ignore_index=True)

        bpm_buffer[bpm_buffer_index] = bpm
        bpm_buffer_index = (bpm_buffer_index + 1) % bpm_buffer_size

        if len(df) > bpm_buffer_size:
            heart_rate = bpm_buffer.mean()
        else:
            heart_rate = "Calculating..."

def detect_emotion():
    global emotion, emotion_detection_running
    while emotion_detection_running:
        if cap.isOpened():
            ret, frame = cap.read()
            if ret:
                try:
                    result = DeepFace.analyze(frame, actions=['emotion'])
                    if isinstance(result, list) and len(result) > 0:
                        emotion = result[0]['dominant_emotion']
                    else:
                        logger.error("Unexpected result structure: %s", result)
                        emotion = "No face detected"
                except ValueError:
                    emotion = "No face detected"
                    logger.error("DeepFace ValueError: No face detected")
                except Exception as e:
                    emotion = "Error in emotion detection"
                    logger.exception("Error in emotion detection: %s", str(e))
            else:
                logger.warning("Failed to capture frame")
        else:
            logger.error("Webcam not opened")

def generate_frames():
    global cap, emotion_detection_running
    while emotion_detection_running:
        if cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                logger.warning("Failed to capture frame for streaming")
                break
            cv2.rectangle(frame, (160 // 2, 120 // 2), (320 - 160 // 2, 240 - 120 // 2), (0, 255, 0), 3)
            _, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        else:
            logger.error("Webcam not opened")

# User Authentication Routes
@app.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    name = data.get('name')
    email = data['email']
    password = bcrypt.generate_password_hash(data['password']).decode('utf-8')
    phone = data.get('phone')
    gender = data.get('gender')
    city = data.get('city')
    age = data.get('age')
    date_of_birth = data.get('date_of_birth')

    user = mongo.db.users.find_one({'email': email})
    if user:
        return jsonify({'message': 'Email already exists'}), 400

     # Save profile photo if available
    profile_photo_url = ""
    if 'profilePhotoUrl' in data:
        profile_photo_url = data['profilePhotoUrl']
    
    new_user = {
        'name': name,
        'email': email,
        'password': password,
        'phone': phone,
        'gender': gender,
        'city': city,
        'age': age,
        'date_of_birth': date_of_birth,
        'profile_photo_url': profile_photo_url  # Save profile photo URL in database
    }
    mongo.db.users.insert_one(new_user)

    # Send the new user data back to the client, excluding the password
    new_user_data = {
        'name': new_user['name'],
        'email': new_user['email'],
        'phone': new_user['phone'],
        'gender': new_user['gender'],
        'city': new_user['city'],
        'age': new_user['age'],
        'date_of_birth': new_user['date_of_birth'],
        'profile_photo_url': new_user['profile_photo_url']
    }

    return jsonify({'message': 'User created successfully', 'newUser': new_user_data}), 201

#agency_signup
@app.route('/agency_signup', methods=['POST'])
def agency_signup():
    data = request.get_json()
    print(data)
    companyName = data.get('companyName')
    companyEmail = data.get('companyEmail')
    password = data.get('password')
    companyTelephone = data.get('companyTelephone')
    companyAddress = data.get('companyAddress')
    password = bcrypt.generate_password_hash(data['password']).decode('utf-8')

    user = mongo.db.agencies.find_one({'companyEmail': companyEmail})
    if user:
        return jsonify({'message': 'Email already exists'}), 400
    
    new_agency = {
        'companyName': companyName,
        'companyEmail': companyEmail,
        'password': password,
        'companyTelephone': companyTelephone,
        'companyAddress' : companyAddress,
        'subscribers': [],
    }
    mongo.db.agencies.insert_one(new_agency)

    # Send the new user data back to the client, excluding the password
    new_agency_data = {
        'companyName': new_agency['companyName'],
        'companyEmail': new_agency['companyEmail'],
        'companyTelephone': new_agency['companyTelephone'],
        'companyAddress': new_agency['companyAddress'],
    }

    return jsonify({'message': 'User created successfully', 'newAgency': new_agency_data}), 201

    
@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data['email']
    password = data['password']

    user = mongo.db.users.find_one({'email': email})

    if user and bcrypt.check_password_hash(user['password'], password):
        # Send the user data back to the client, excluding the password
        user_data = {
            'name': user.get('name'),
            'email': user['email'],
            'phone': user.get('phone'),
            'gender': user.get('gender'),
            'city': user.get('city'),
            'age': user.get('age'),
            'date_of_birth': user.get('date_of_birth'),
        }
        return jsonify({'message': 'Login successful', 'userData': user_data}), 200
    else:
        return jsonify({'message': 'Invalid credentials'}), 401
    
    
# Endpoint for ad agency login
@app.route('/agency_login', methods=['POST'])
def agency_login():
    data = request.get_json()
    companyEmail = data['companyEmail']
    password = data['password']

    agency = mongo.db.agencies.find_one({'companyEmail': companyEmail})

    if agency and bcrypt.check_password_hash(agency['password'], password):
        # Send the user data back to the client, excluding the password
        agency_data = {
            'companyName': agency['companyName'],
            'companyEmail': agency['companyEmail'],
            'companyTelephone': agency['companyTelephone'],
            'companyAddress': agency['companyAddress']
        }
        print(agency_data)
        return jsonify({'message': 'Login successful', 'agencyData ': agency_data}), 200
    else:
        return jsonify({'message': 'Invalid credentials'}), 401

@app.route('/logout', methods=['POST'])
def logout():
    return jsonify({'message': 'Logout successful'}), 200

@app.route('/agency-logout', methods=['POST'])
def agencylogout():
    return jsonify({'message': 'Logout successful'}), 200


# Endpoint for video upload
@app.route('/upload_video', methods=['POST'])
def upload_video():
    data = request.form
    companyEmail = data.get('companyEmail')
    videoName = data.get('videoName')
    videoDescription = data.get('videoDescription')
    youtubeLink = data.get('youtubeLink')
    videoCover = data.get('videoCover')
    videoTags = data.get('videoTags').split(',')

    video_details = {
        'videoName': videoName,
        'videoDescription': videoDescription,
        'youtubeLink': youtubeLink,
        'videoCover': videoCover,
        'videoTags': videoTags,
        'likes': [],
        'comments': []
    }

    result = mongo.db.agencies.update_one(
        {'companyEmail': companyEmail},
        {'$push': {'videos': video_details}}
    )

    if result.modified_count > 0:
        return jsonify({'message': 'Video uploaded successfully'}), 201
    else:
        return jsonify({'message': 'Video upload failed'}), 400
    
@app.route('/videos', methods=['GET'])
def get_videos():
    agency_email = request.headers.get('companyEmail')
    if not agency_email:
        return jsonify({"error": "No agency email provided"}), 400

    agency = mongo.db.agencies.find_one({'companyEmail': agency_email})
    if not agency:
        return jsonify({"error": "Agency not found"}), 404

    videos = agency.get('videos', [])  # Fetch videos array from agency document
    video_list = []
    for video in videos:
        video_list.append({
            "videoName": video["videoName"],
            "videoDescription": video["videoDescription"],
            "youtubeLink": video["youtubeLink"],
            "videoCover": video["videoCover"],
            "videoTags": video["videoTags"],
            "likes": video["likes"],
            "views":video["views"],
            "comments":video["comments"]
        })

    return jsonify(video_list), 200

@app.route('/delete_video', methods=['DELETE'])
def delete_video():
    agency_email = request.headers.get('companyEmail')
    video_name = request.json.get('videoName')

    if not agency_email or not video_name:
        return jsonify({"error": "Missing required information"}), 400

    agency = mongo.db.agencies.find_one({'companyEmail': agency_email})
    if not agency:
        return jsonify({"error": "Agency not found"}), 404

    result = mongo.db.agencies.update_one(
        {'companyEmail': agency_email},
        {'$pull': {'videos': {'videoName': video_name}}}
    )

    if result.modified_count > 0:
        return jsonify({"message": "Video deleted successfully"}), 200
    else:
        return jsonify({"error": "Video not found or already deleted"}), 404
    
@app.route('/all_videos', methods=['GET'])
def get_all_videos():
    videos = list(mongo.db.agencies.aggregate([
        {'$unwind': '$videos'},
        {'$project': {
            '_id': {'$toString': '$_id'},
            'videoName': '$videos.videoName',
            'videoDescription': '$videos.videoDescription',
            'youtubeLink': '$videos.youtubeLink',
            'videoCover': '$videos.videoCover',
            'videoTags': '$videos.videoTags',
            'likes': {'$size': {'$ifNull': ['$videos.likes', []]}},
            'comments': '$videos.comments',
            'views': {'$size': {'$ifNull': ['$videos.views', []]}}
        }}
    ]))
    
    return json.loads(json_util.dumps(videos)), 200

@app.route('/get_video_url/<video_id>', methods=['GET'])
def get_video_url(video_id):
    video = mongo.db.agencies.find_one(
        {'videos._id': ObjectId(video_id)},
        {'videos.$': 1}
    )
    if video and video['videos']:
        return jsonify({'videoUrl': video['videos'][0].get('youtubeLink')})
    else:
        return jsonify({'error': 'Video not found'}), 404

#like video  
@app.route('/like_video', methods=['POST'])
def like_video():
    data = request.get_json()
    print("Received data:", data)
    video_name = data.get('videoName')  # Changed from videoId to videoName
    user_email = data.get('userEmail')

    # Log the values we're using in the query
    print(f"Searching for video name: {video_name}")
    print(f"User email: {user_email}")

    # First, find the agency that has the video
    agency = mongo.db.agencies.find_one({"videos.videoName": video_name})
    
    if not agency:
        print(f"No agency found with video named: {video_name}")
        return jsonify({'message': 'Video not found'}), 404

    # Now update the specific video in the found agency
    result = mongo.db.agencies.update_one(
        {"_id": agency["_id"], "videos.videoName": video_name},
        {"$addToSet": {"videos.$.likes": user_email}}
    )
    
    print("Update result:", result.raw_result)

    if result.modified_count > 0:
        return jsonify({'message': 'Video liked successfully'}), 200
    else:
        return jsonify({'message': 'Failed to like video'}), 400
@app.route('/unlike_video', methods=['POST'])
def unlike_video():
    data = request.get_json()
    video_name = data.get('videoName')
    user_email = data.get('userEmail')

    print(f"Attempting to unlike video: {video_name}")
    print(f"User email: {user_email}")

    # Find the agency that has the video
    agency = mongo.db.agencies.find_one({"videos.videoName": video_name})
    
    if not agency:
        print(f"No agency found with video named: {video_name}")
        return jsonify({'message': 'Video not found'}), 404

    # Update the specific video in the found agency
    result = mongo.db.agencies.update_one(
        {"_id": agency["_id"], "videos.videoName": video_name},
        {"$pull": {"videos.$.likes": user_email}}
    )
    
    print("Update result:", result.raw_result)

    if result.modified_count > 0:
        return jsonify({'message': 'Video unliked successfully'}), 200
    else:
        return jsonify({'message': 'Failed to unlike video'}), 400

@app.route('/add_comment', methods=['POST'])
def add_comment():
    data = request.get_json()
    print("Received data:", data)
    video_name = data.get('videoName')
    user_email = data.get('userEmail')
    comment_text = data.get('commentText')

    print(f"Attempting to add comment to video: {video_name}")
    print(f"User email: {user_email}")
    print(f"Comment text: {comment_text}")

    comment = {
        'user': user_email,
        'text': comment_text,
        'timestamp': datetime.utcnow()
    }

    # Find the agency that has the video
    agency = mongo.db.agencies.find_one({"videos.videoName": video_name})
    
    if not agency:
        print(f"No agency found with video named: {video_name}")
        return jsonify({'message': 'Video not found'}), 404

    print("Found agency:", json.loads(json_util.dumps(agency)))

    # Update the specific video in the found agency
    try:
        result = mongo.db.agencies.update_one(
            {"videos.videoName": video_name},
            {"$push": {"videos.$[elem].comments": comment}},
            array_filters=[{"elem.videoName": video_name}]
        )
        
        print("Update result:", result.raw_result)

        if result.modified_count > 0:
            return jsonify({'message': 'Comment added successfully', 'comment': comment}), 200
        else:
            return jsonify({'message': 'No changes made. Video might not exist or comment might be a duplicate'}), 400
    except Exception as e:
        print(f"Error updating document: {str(e)}")
        return jsonify({'message': 'Error adding comment', 'error': str(e)}), 500
    
@app.route('/delete_comment', methods=['POST'])
def delete_comment():
    data = request.get_json()
    video_name = data.get('videoName')
    comment_text = data.get('commentText')
    user_email = data.get('userEmail')

    try:
        # Find the agency that has the video
        agency = mongo.db.agencies.find_one({"videos.videoName": video_name})
        
        if not agency:
            return jsonify({'message': 'Video not found'}), 404
        
        video = None
        for v in agency['videos']:
            if v['videoName'] == video_name:
                video = v
                break

        if not video:
            return jsonify({'message': 'Video not found'}), 404

        comment_index = next((index for (index, comment) in enumerate(video['comments']) if comment['text'] == comment_text and comment['user'] == user_email), None)

        if comment_index is None:
            return jsonify({'message': 'Comment not found or you do not have permission to delete it'}), 404

        video['comments'].pop(comment_index)

        result = mongo.db.agencies.update_one(
            {"videos.videoName": video_name},
            {"$set": {"videos.$[elem].comments": video['comments']}},
            array_filters=[{"elem.videoName": video_name}]
        )

        if result.modified_count > 0:
            return jsonify({'message': 'Comment deleted successfully'}), 200
        else:
            return jsonify({'message': 'An error occurred while deleting the comment'}), 500

    except Exception as e:
        print('Error deleting comment:', str(e))
        return jsonify({'message': 'An error occurred while deleting the comment', 'error': str(e)}), 500

@app.route('/get_video_details', methods=['GET'])
def get_video_details():
    video_name = request.headers.get('VideoName')
    print("video name:",video_name)
    if not video_name:
        return jsonify({'error': 'VideoName header is required'}), 400

    try:
        video = mongo.db.agencies.aggregate([
            {'$unwind': '$videos'},
            {'$match': {'videos.videoName': video_name}},
            {'$project': {
                'videoName': '$videos.videoName',
                'videoDescription': '$videos.videoDescription',
                'youtubeLink': '$videos.youtubeLink',
                'videoCover': '$videos.videoCover',
                'videoTags': '$videos.videoTags',
                'likes': {'$size': {'$ifNull': ['$videos.likes', []]}},
                'comments': '$videos.comments'
            }}
        ]).next()
        print("video data:",video)
        return jsonify(video), 200
    except StopIteration:
        return jsonify({'error': 'Video not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/increment_view', methods=['POST'])
def increment_view():
    data = request.get_json()
    video_name = data.get('videoName')
    user_email = data.get('userEmail')
    view_duration = data.get('viewDuration')  # in seconds

    # Find the agency that has the video
    agency = mongo.db.agencies.find_one({"videos.videoName": video_name})
    
    if not agency:
        return jsonify({'message': 'Video not found'}), 404

    # Only increment view if more than 5 seconds were watched
    if view_duration > 5:
        result = mongo.db.agencies.update_one(
            {"videos.videoName": video_name},
            {
                "$addToSet": {"videos.$.views": user_email},
                "$set": {"videos.$.lastViewedAt": datetime.utcnow()}
            }
        )

        # Add to user's watch history only if it doesn't exist
        mongo.db.users.update_one(
            {
                "email": user_email,
                "watchedVideos.videoName": {"$ne": video_name}
            },
            {"$push": {
                "watchedVideos": {
                    "videoName": video_name,
                    "watchedAt": datetime.utcnow(),
                }
            }}
        )

        if result.modified_count > 0:
            return jsonify({'message': 'View counted and added to history'}), 200
        else:
            return jsonify({'message': 'View already counted'}), 200
    else:
        return jsonify({'message': 'View not counted (less than 5 seconds watched)'}), 200

@app.route('/get_watch_history/<user_email>', methods=['GET'])
def get_watch_history(user_email):
    user = mongo.db.users.find_one({"email": user_email})
    if not user:
        return jsonify({'message': 'User not found'}), 404

    watch_history = user.get('watchedVideos', [])
    if not watch_history:
        return jsonify({'watchHistory': []}), 200

    video_names = [video['videoName'] for video in watch_history]
    
    videos = list(mongo.db.agencies.aggregate([
        {'$unwind': '$videos'},
        {'$match': {'videos.videoName': {'$in': video_names}}},
        {'$project': {
            '_id': 0,
            'videoName': '$videos.videoName',
            'videoDescription': '$videos.videoDescription',
            'youtubeLink': '$videos.youtubeLink',
            'videoCover': '$videos.videoCover',
            'videoTags': '$videos.videoTags',
            'likes': {'$size': {'$ifNull': ['$videos.likes', []]}},
            'comments': '$videos.comments',
            'views': '$videos.views',
        }}
    ]))

    watch_history_with_details = []
    for item in watch_history:
        video_detail = next((video for video in videos if video['videoName'] == item['videoName']), {})
        if video_detail:
            watch_history_with_details.append({**item, **video_detail})
    
    return jsonify({'watchHistory': watch_history_with_details}), 200

@app.route('/remove_from_history', methods=['POST'])
def remove_from_history():
    data = request.json
    user_email = data.get('userEmail')
    video_name = data.get('videoName')
    print(f"Received request to remove video: {video_name} for user: {user_email}")

    if not user_email or not video_name:
        return jsonify({"error": "Invalid request"}), 400

    try:
        # Find the user and remove the video from the watch history
        result = mongo.db.users.update_one(
            {"email": user_email},
            {"$pull": {"watchedVideos": {"videoName": video_name}}}
        )
        print(result.raw_result)
        if result.modified_count == 0:
            return jsonify({"error": "Video not found in watch history"}), 404

        return jsonify({"message": "Video removed from watch history"}), 200
    except Exception as e:
        print(f"Error removing video from history: {e}")
        return jsonify({"error": "An error occurred"}), 500




@app.route('/subscribe', methods=['POST'])
def subscribe():
    try:
        data = request.get_json()
        print("Received data:", data)
        user_email = data.get('userEmail')
        video_name = data.get('videoName')

        print(f"Attempting to subscribe user: {user_email} to video: {video_name}")

        # Find the agency that has the video
        agency = mongo.db.agencies.find_one({"videos.videoName": video_name})

        if not agency:
            print(f"No agency found with video named: {video_name}")
            return jsonify({'message': 'Video not found'}), 404

        print("Found agency:", json.loads(json_util.dumps(agency)))

        agency_email = agency['companyEmail']

        # Add the user to the agency's subscribers
        agency_result = mongo.db.agencies.update_one(
            {'companyEmail': agency_email},
            {'$addToSet': {'subscribers': user_email}}
        )

        # Add the agency to the user's subscriptions
        user_result = mongo.db.users.update_one(
            {'email': user_email},
            {'$addToSet': {'subscriptions': agency_email}}
        )

        print("Agency update result:", agency_result.raw_result)
        print("User update result:", user_result.raw_result)

        if agency_result.modified_count > 0 or user_result.modified_count > 0:
            return jsonify({
                'message': 'Subscribed successfully',
                'userEmail': user_email,
                'agencyEmail': agency_email
            }), 200
        else:
            return jsonify({'message': 'No changes made. User might already be subscribed.'}), 200

    except Exception as e:
        print(f"An error occurred: {str(e)}")
        print(traceback.format_exc())
        return jsonify({'message': 'An error occurred while processing your request', 'error': str(e)}), 500

@app.route('/unsubscribe', methods=['POST'])
def unsubscribe():
    try:
        data = request.get_json()
        print("Received data:", data)
        user_email = data.get('userEmail')
        video_name = data.get('videoName')

        print(f"Attempting to unsubscribe user: {user_email} from video: {video_name}")

        # Find the agency that has the video
        agency = mongo.db.agencies.find_one({"videos.videoName": video_name})

        if not agency:
            print(f"No agency found with video named: {video_name}")
            return jsonify({'message': 'Video not found'}), 404

        print("Found agency:", json.loads(json_util.dumps(agency)))

        agency_email = agency['companyEmail']

        # Remove the user from the agency's subscribers
        agency_result = mongo.db.agencies.update_one(
            {'companyEmail': agency_email},
            {'$pull': {'subscribers': user_email}}
        )

        # Remove the agency from the user's subscriptions
        user_result = mongo.db.users.update_one(
            {'email': user_email},
            {'$pull': {'subscriptions': agency_email}}
        )

        print("Agency update result:", agency_result.raw_result)
        print("User update result:", user_result.raw_result)

        if agency_result.modified_count > 0 or user_result.modified_count > 0:
            return jsonify({
                'message': 'Unsubscribed successfully',
                'userEmail': user_email,
                'agencyEmail': agency_email
            }), 200
        else:
            return jsonify({'message': 'No changes made. User might not have been subscribed.'}), 200

    except Exception as e:
        print(f"An error occurred: {str(e)}")
        print(traceback.format_exc())
        return jsonify({'message': 'An error occurred while processing your request', 'error': str(e)}), 500

@app.route('/user_subscribed_videos/<user_email>', methods=['GET'])
def user_subscribed_videos(user_email):
    try:
        user = mongo.db.users.find_one({'email': user_email})
        subscribed_agencies = user.get('subscriptions', []) if user else []
        
        # Fetch all videos from subscribed agencies
        subscribed_videos = mongo.db.agencies.aggregate([
            {'$match': {'companyEmail': {'$in': subscribed_agencies}}},
            {'$unwind': '$videos'},
            {'$project': {'videoName': '$videos.videoName'}}
        ])
        
        video_names = [video['videoName'] for video in subscribed_videos]
        return jsonify({'subscribedVideos': video_names}), 200
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        print(traceback.format_exc())
        return jsonify({'message': 'An error occurred while processing your request', 'error': str(e)}), 500


@app.route('/user_subscribed_agencies/<user_email>', methods=['GET'])
def user_subscribed_agencies(user_email):
    try:
        # Fetch the user's subscriptions
        user = mongo.db.users.find_one({'email': user_email})
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        subscribed_agencies = user.get('subscriptions', [])
        
        # Fetch details of subscribed agencies and their videos
        agencies_data = list(mongo.db.agencies.aggregate([
            {'$match': {'companyEmail': {'$in': subscribed_agencies}}},
            {'$project': {
                '_id': 0,
                'companyName': 1,
                'companyEmail': 1,
                'companyTelephone': 1,
                'companyAddress': 1,
                'subscriberCount': {'$size': {'$ifNull': ['$subscribers', []]}},
                'videos': {
                    '$map': {
                        'input': '$videos',
                        'as': 'video',
                        'in': {
                            'videoName': '$$video.videoName',
                            'videoDescription': '$$video.videoDescription',
                            'youtubeLink': '$$video.youtubeLink',
                            'videoCover': '$$video.videoCover',
                            'videoTags': '$$video.videoTags',
                            'likes': {'$size': {'$ifNull': ['$$video.likes', []]}},
                            'views': {'$size': {'$ifNull': ['$$video.views', []]}},
                            'comments': {'$size': {'$ifNull': ['$$video.comments', []]}}
                        }
                    }
                }
            }}
        ]))
        
        return jsonify({'subscribedAgencies': agencies_data}), 200
    
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        print(traceback.format_exc())
        return jsonify({'message': 'An error occurred while processing your request', 'error': str(e)}), 500
    

@app.route('/subscribers', methods=['GET'])
def get_subscribers():
    try:
        agency_email = request.headers.get('companyEmail')
        agency = mongo.db.agencies.find_one({"companyEmail": agency_email})
        
        if not agency:
            return jsonify({"message": "Agency not found"}), 404
        
        subscribers = agency.get('subscribers', [])
        
        # Fetch user details for each subscriber
        subscriber_details = []
        for subscriber_email in subscribers:
            user = mongo.db.users.find_one({"email": subscriber_email})
            if user:
                subscriber_details.append({
                    "name": user.get("name"),
                    "email": user.get("email"),
                    "age": user.get("age"),
                    "gender": user.get("gender"),
                    "city": user.get("city")
                })
        
        return jsonify({"subscribers": subscriber_details}), 200
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        print(traceback.format_exc())
        return jsonify({'message': 'An error occurred while processing your request', 'error': str(e)}), 500

# Endpoint to fetch friends list for a user

@app.route('/friends', methods=['GET'])
def get_friends():
    try:
        # Query all users from the database excluding passwords
        users = mongo.db.users.find({}, {'password': 0})  # Exclude password field
        
        # Prepare list of users' data excluding password
        users_data = []
        for user in users:
            user_data = {
                'name': user['name'],
                'email': user['email'],
                'phone': user.get('phone', ''),
                'gender': user.get('gender', ''),
                'city': user.get('city', ''),
                'age': user.get('age', ''),
                'date_of_birth': user.get('date_of_birth', ''),
                'profile_photo_url': user.get('profile_photo_url', '')
            }
            users_data.append(user_data)

        return jsonify({'users': users_data}), 200

    except Exception as e:
        logger.error('Error fetching users:', str(e))
        return jsonify({'message': 'Error fetching users'}), 500
    
# Endpoint to send friend request
@app.route('/send_friend_request', methods=['POST'])
def send_friend_request():
    data = request.get_json()
    sender_email = data['senderEmail']
    receiver_email = data['receiverEmail']

    try:
        # Check if the receiver user exists
        receiver_user = mongo.db.users.find_one({'email': receiver_email})
        if not receiver_user:
            return jsonify({'message': 'Receiver user not found'}), 404

        # Check if the sender user exists
        sender_user = mongo.db.users.find_one({'email': sender_email})
        if not sender_user:
            return jsonify({'message': 'Sender user not found'}), 404

        # Update the receiver user's friendRequests array
        mongo.db.users.update_one(
            {'email': receiver_email},
            {'$push': {'friendRequests': {
                'email': sender_email,
                'name': sender_user['name']
            }}}
        )

        return jsonify({'message': 'Friend request sent successfully'}), 200

    except Exception as e:
        logger.error('Error sending friend request:', str(e))
        return jsonify({'message': 'Error sending friend request'}), 500
    
#friend request display    
@app.route('/friend_requests', methods=['GET'])
def get_friend_requests():
    logged_in_email = request.args.get('loggedInEmail')
    user = mongo.db.users.find_one({'email': logged_in_email})
    
    if not user:
        return jsonify({'message': 'User not found'}), 404

    return jsonify({'friendRequests': user.get('friendRequests', [])})

# Endpoint to accept friend request
@app.route('/accept_friend_request', methods=['POST'])
def accept_friend_request():
    data = request.get_json()
    sender_email = data['senderEmail']
    receiver_email = data['receiverEmail']

    try:
        # Check if the sender and receiver users exist
        sender_user = mongo.db.users.find_one({'email': sender_email})
        receiver_user = mongo.db.users.find_one({'email': receiver_email})

        if not sender_user or not receiver_user:
            return jsonify({'message': 'User not found'}), 404

        # Update the friends array for both users
        mongo.db.users.update_one(
            {'email': sender_email},
            {'$push': {'friends': {
                'email': receiver_email,
                'name': receiver_user['name'],
                'profile_photo_url': receiver_user.get('profile_photo_url', ''),
                'age': receiver_user.get('age', ''),
                'city': receiver_user.get('city', '')
            }}}
        )

        mongo.db.users.update_one(
            {'email': receiver_email},
            {'$push': {'friends': {
                'email': sender_email,
                'name': sender_user['name'],
                'profile_photo_url': sender_user.get('profile_photo_url', ''),
                'age': sender_user.get('age', ''),
                'city': sender_user.get('city', '')
            }}}
        )

        # Remove the friend request from the receiver's friendRequests array
        mongo.db.users.update_one(
            {'email': receiver_email},
            {'$pull': {'friendRequests': {'email': sender_email}}}
        )

        return jsonify({'message': 'Friend request accepted successfully'}), 200

    except Exception as e:
        logger.error('Error accepting friend request:', str(e))
        return jsonify({'message': 'Error accepting friend request'}), 500

# Endpoint to fetch friends list for a logged-in user
@app.route('/friends_list', methods=['GET'])
def get_friends_list():
    try:
        logged_in_email = request.args.get('loggedInEmail')
        user = mongo.db.users.find_one({'email': logged_in_email})
        
        if not user:
            return jsonify({'message': 'User not found'}), 404

        friends_list = user.get('friends', [])
        return jsonify({'friends': friends_list}), 200

    except Exception as e:
        logger.error('Error fetching friends list:', str(e))
        return jsonify({'message': 'Error fetching friends list'}), 500

@app.route('/remove_friend', methods=['POST'])
def remove_friend():
    data = request.get_json()
    friend_email = data['friendEmail']
    user_email = data['userEmail']
    
    try:
        # Remove the friend from the user's friends array
        mongo.db.users.update_one(
            {'email': user_email},
            {'$pull': {'friends': {'email': friend_email}}}
        )

        # Also remove the user from the friend's friends array
        mongo.db.users.update_one(
            {'email': friend_email},
            {'$pull': {'friends': {'email': user_email}}}
        )

        return jsonify({'message': 'Friend removed successfully'}), 200
    
    except Exception as e:
        logger.error('Error removing friend:', str(e))
        return jsonify({'message': 'Error removing friend'}), 500
    
@app.route('/remove_friend_request', methods=['POST'])
def remove_friend_request():
    data = request.get_json()
    sender_email = data['senderEmail']
    receiver_email = data['receiverEmail']
    
    try:
        # Remove the friend request from the receiver's friendRequests array
        mongo.db.users.update_one(
            {'email': receiver_email},
            {'$pull': {'friendRequests': {'email': sender_email}}}
        )

        return jsonify({'message': 'Friend request removed successfully'}), 200
    
    except Exception as e:
        logger.error('Error removing friend request:', str(e))
        return jsonify({'message': 'Error removing friend request'}), 500
    

#OTP 
def generate_otp():
    return str(random.randint(100000, 999999))

#store otp
def store_otp(email, phone, otp, otp_type):
    mongo.db.otps.insert_one({
        "email": email,
        "phone": phone,
        "otp": otp,
        "type": otp_type,
        "timestamp": datetime.utcnow()
    })

#verify stored otp
def verify_stored_otp(email, phone, otp, otp_type):
    query = {"otp": otp, "type": otp_type}
    if email:
        query["email"] = email
    if phone:
        query["phone"] = phone

    record = mongo.db.otps.find_one(query)
    if record and (datetime.utcnow() - record['timestamp']).total_seconds() < 300:
        mongo.db.otps.delete_one({"_id": record["_id"]})
        return True
    return False

#send otp

@app.route('/send_email_otp', methods=['POST'])
def send_email_otp():
    data = request.json
    email = data.get('email')
    
    if not email:
        return jsonify({"message": "Email is required"}), 400

    otp = generate_otp()
    store_otp(email, None, otp, 'email')
    msg = Message(
        subject=' Your OTP Verification Code for FanNeuro', 
        sender='f20221227@hyderabad.bits-pilani.ac.in',  
        recipients=[email]
    )
    msg.body = msg.body = f"""
    Dear User,

    Thank you for signing up with FanNeuro! To complete your registration, please verify your email address using the One-Time Password (OTP) provided below.

    Your OTP Code: {otp}

    Please enter this code in the verification section on the FanNeuro website to activate your account. For your security, this code is valid for the next 10 minutes.

    If you did not request this code, please ignore this email or contact our support team for assistance.

    Thank you for choosing FanNeuro. We are excited to have you on board!

    Best regards,
    The FanNeuro Team

    FanPlay IOT Technologies
    Bengaluru
    """
    mail.send(msg)
    print(f"Email OTP for {email}: {otp}")
    return jsonify({"message": "Email OTP sent successfully"}), 200

@app.route('/send_sms_otp', methods=['POST'])
def send_sms_otp():
    data = request.json
    phone_number = data.get('phone_number')
    
    if not phone_number:
        return jsonify({"message": "Phone number is required"}), 400

    otp = generate_otp()
    store_otp(None, phone_number, otp, 'sms')

    try:
        message = twilio_client.messages.create(
            body=f'Your OTP is {otp}',
            from_=twilio_phone_number,  
            to='+91' + phone_number,
        )
        return jsonify({"message": "SMS OTP sent successfully"}), 200
    except Exception as e:
        print(f"Error sending SMS: {str(e)}")
        return jsonify({"message": "Error sending SMS OTP"}), 500
    
#verify otp
@app.route('/verify_email_otp', methods=['POST'])
def verify_email_otp():
    data = request.json
    email = data.get('email')
    otp = data.get('otp')

    if not email or not otp:
        return jsonify({"message": "Email and OTP are required"}), 400

    if verify_stored_otp(email, None, otp, 'email'):
        return jsonify({"message": "Email OTP verified successfully"}), 200
    return jsonify({"message": "Invalid or expired Email OTP"}), 400
@app.route('/verify_sms_otp', methods=['POST'])
def verify_sms_otp():
    data = request.json
    phone_number = data.get('phone_number')
    otp = data.get('otp')

    if not phone_number or not otp:
        return jsonify({"message": "Phone number and OTP are required"}), 400

    if verify_stored_otp(None, phone_number, otp, 'sms'):
        return jsonify({"message": "SMS OTP verified successfully"}), 200
    return jsonify({"message": "Invalid or expired SMS OTP"}), 400

# Function to delete watch party after duration
def delete_watch_party(watch_party_id, duration):
    time.sleep(duration * 60)  # Convert minutes to seconds
    mongo.db.watch_parties.update_one(
        {"_id": ObjectId(watch_party_id)},
        {"$set": {"status": "expired"}}
    )
    print(f"Watch party {watch_party_id} expired after duration.")

# Create watch party
@app.route('/api/create-watch-party', methods=['POST'])
def create_watch_party():
    try:
        data = request.json
        watch_party_id = str(uuid.uuid4())
        invite_link = f"{request.host_url}join/{watch_party_id}"
        
        watch_party = {
            "_id": ObjectId(),
            "id": watch_party_id,
            "date": data['date'],
            "time": data['time'],
            "hostName": data['hostName'],
            "password": bcrypt.generate_password_hash(data['password']).decode('utf-8'),
            "duration": int(data['duration']),
            "maxParticipants": int(data['maxParticipants']),
            "inviteLink": invite_link,
            "createdAt": datetime.utcnow(),
            "participants": [data['hostName']],
            "status": "active",
            "kicked_out": []
        }
        
        result = mongo.db.watch_parties.insert_one(watch_party)
        
        # Schedule expiration after duration
        threading.Thread(target=delete_watch_party, args=(result.inserted_id, int(data['duration']))).start()
        
        return jsonify({
            "watchPartyId": watch_party_id,
            "inviteLink": invite_link,
            "date": data['date'],
            "time": data['time'],
            "duration": data['duration'],
            "maxParticipants": data['maxParticipants'],
            "hostName": data['hostName']
        }), 201
    except Exception as e:
        print(f"Error creating watch party: {str(e)}")
        return jsonify({"error": "Failed to create watch party"}), 500

# Join watch party
@app.route('/api/join-watch-party/<string:id>', methods=['GET'])
def join_watch_party(id):
    try:
        watch_party = mongo.db.watch_parties.find_one({"id": id})
        if not watch_party:
            return jsonify({"error": "Watch party not found"}), 404
        
        # Convert ObjectId to string for JSON serialization
        watch_party['_id'] = str(watch_party['_id'])
        
        return jsonify(watch_party), 200
    except Exception as e:
        print(f"Error joining watch party: {str(e)}")
        return jsonify({"error": "Failed to join watch party"}), 500
    
# End watch party
@app.route('/api/end-watch-party/<string:id>', methods=['POST'])
def end_watch_party(id):
    try:
        watch_party = mongo.db.watch_parties.find_one({"id": id})
        if not watch_party:
            return jsonify({"error": "Watch party not found"}), 404

        mongo.db.watch_parties.update_one({"id": id}, {"$set": {"status": "ended"}})
        return jsonify({"message": "Watch party ended successfully"}), 200
    except Exception as e:
        print(f"Error ending watch party: {str(e)}")
        return jsonify({"error": "Failed to end watch party"}), 500

# Verify watch party password
@app.route('/api/verify-watch-party-password/<string:id>', methods=['POST'])
def verify_watch_party_password(id):
    try:
        data = request.json
        provided_password = data['password']
        
        watch_party = mongo.db.watch_parties.find_one({"id": id})
        if not watch_party:
            return jsonify({"error": "Watch party not found"}), 404

        if bcrypt.check_password_hash(watch_party['password'], provided_password):
            return jsonify({
                "success": True,
                "watchPartyDetails": {
                    "watchPartyId": watch_party['id'],
                    "date": watch_party['date'],
                    "time": watch_party['time'],
                    "hostName": watch_party['hostName'],
                    "duration": watch_party['duration'],
                    "maxParticipants": watch_party['maxParticipants'],
                    "inviteLink": watch_party['inviteLink'],
                }
            }), 200
        else:
            return jsonify({"success": False, "error": "Incorrect password"}), 401
    except Exception as e:
        print(f"Error verifying watch party password: {str(e)}")
        return jsonify({"error": "Failed to verify password"}), 500

# Add participant to watch party
@app.route('/api/add-participant/<string:id>', methods=['POST'])
def add_participant(id):
    try:
        data = request.json
        participant_name = data['name']
        
        result = mongo.db.watch_parties.update_one(
            {"id": id},
            {
                "$addToSet": {"participants": participant_name},
                "$pull": {"kicked_out": participant_name}
            }
        )
        
        if result.modified_count == 0:
            return jsonify({"error": "Watch party not found or participant already added"}), 404
        
        return jsonify({"message": "Participant added successfully"}), 200
    except Exception as e:
        print(f"Error adding participant: {str(e)}")
        return jsonify({"error": "Failed to add participant"}), 500

# Remove participant from watch party
@app.route('/api/remove-participant/<string:id>', methods=['POST'])
def remove_participant(id):
    try:
        data = request.json
        participant_name = data['name']
        
        result = mongo.db.watch_parties.update_one(
            {"id": id},
            {
                "$pull": {"participants": participant_name},
                "$addToSet": {"kicked_out": participant_name}
            }
        )
        
        if result.modified_count == 0:
            return jsonify({"error": "Watch party not found or participant not in the party"}), 404
        
        return jsonify({"message": "Participant removed successfully"}), 200
    except Exception as e:
        print(f"Error removing participant: {str(e)}")
        return jsonify({"error": "Failed to remove participant"}), 500

# Get all participants in a watch party
@app.route('/api/get-participants/<string:id>', methods=['GET'])
def get_participants(id):
    try:
        watch_party = mongo.db.watch_parties.find_one({"id": id})
        if not watch_party:
            return jsonify({"error": "Watch party not found"}), 404
        
        participants = watch_party.get('participants', [])
        return jsonify({"participants": participants}), 200
    except Exception as e:
        print(f"Error getting participants: {str(e)}")
        return jsonify({"error": "Failed to get participants"}), 500

# Get meeting status
@app.route('/api/meeting-status/<string:id>', methods=['GET'])
def get_meeting_status(id):
    try:
        watch_party = mongo.db.watch_parties.find_one({"id": id})
        if not watch_party:
            return jsonify({"error": "Watch party not found"}), 404
        
        return jsonify({"status": watch_party.get('status', 'active')}), 200
    except Exception as e:
        print(f"Error getting meeting status: {str(e)}")
        return jsonify({"error": "Failed to get meeting status"}), 500

# Check participant status
@app.route('/api/check-participant-status/<string:id>/<string:name>', methods=['GET'])
def check_participant_status(id, name):
    try:
        watch_party = mongo.db.watch_parties.find_one({"id": id})
        if not watch_party:
            return jsonify({"error": "Watch party not found"}), 404
        
        if name in watch_party.get('kicked_out', []):
            return jsonify({"status": "kicked_out"}), 200
        elif name in watch_party.get('participants', []):
            return jsonify({"status": "active"}), 200
        else:
            return jsonify({"status": "not_found"}), 200
    except Exception as e:
        print(f"Error checking participant status: {str(e)}")
        return jsonify({"error": "Failed to check participant status"}), 500
    
# Chat functionality
@app.route('/api/chat/<string:watch_party_id>', methods=['GET', 'POST'])
def chat(watch_party_id):
    try:
        if request.method == 'POST':
            data = request.json
            message = {
                "author": data['author'],
                "text": data['text'],
                "timestamp": datetime.utcnow().isoformat()
            }
            mongo.db.watch_parties.update_one(
                {"id": watch_party_id},
                {"$push": {"chat_messages": message}}
            )
            return jsonify({"success": True, "message": "Message sent successfully"}), 200
        else:
            watch_party = mongo.db.watch_parties.find_one({"id": watch_party_id})
            if not watch_party:
                return jsonify({"error": "Watch party not found"}), 404
            
            chat_messages = watch_party.get('chat_messages', [])
            return jsonify({"chat_messages": chat_messages}), 200
    except Exception as e:
        print(f"Error in chat: {str(e)}")
        return jsonify({"error": "Failed to process chat request"}), 500
    
@app.route('/api/watch-party-state/<string:id>', methods=['GET'])
def get_watch_party_state(id):
    try:
        watch_party = mongo.db.watch_parties.find_one({"id": id})
        if not watch_party:
            return jsonify({"error": "Watch party not found"}), 404
        
        return jsonify({
            "currentVideo": watch_party.get('currentVideo'),
            "currentVideoTime": watch_party.get('currentVideoTime', 0)
        }), 200
    except Exception as e:
        print(f"Error getting watch party state: {str(e)}")
        return jsonify({"error": "Failed to get watch party state"}), 500

@app.route('/api/update-watch-party/<string:id>', methods=['POST'])
def update_watch_party(id):
    try:
        data = request.json
        update_data = {}
        if 'currentVideo' in data:
            update_data['currentVideo'] = data['currentVideo']
        if 'currentVideoTime' in data:
            update_data['currentVideoTime'] = data['currentVideoTime']
        
        result = mongo.db.watch_parties.update_one(
            {"id": id},
            {"$set": update_data}
        )
        
        if result.modified_count == 0:
            return jsonify({"error": "Watch party not found or no changes made"}), 404
        
        return jsonify({"message": "Watch party updated successfully"}), 200
    except Exception as e:
        print(f"Error updating watch party: {str(e)}")
        return jsonify({"error": "Failed to update watch party"}), 500
    
from datetime import datetime

@app.route('/store_emotion_stats', methods=['POST'])
def store_emotion_stats():
    data = request.get_json()
    print("data from frontend: ", data)
    user_email = data['userEmail']
    video_name = data['videoName']
    heart_rate = data['heartRate']
    emotions = data['emotion']
    timestamp = datetime.utcnow()

    # Prepare the emotion data object
    emotion_data_object = {
        "timestamp": timestamp,
        "videoName": video_name,
        "heartRate": heart_rate,
        "emotion": emotions
    }

    # Store data in users collection
    user = mongo.db.users.find_one({"email": user_email})
    if user:
        # Check if emotion_data array exists, if not create it
        if 'emotion_data' not in user:
            mongo.db.users.update_one(
                {"_id": user['_id']},
                {"$set": {"emotion_data": []}}
            )
        
        # Append new emotion data to the array
        mongo.db.users.update_one(
            {"_id": user['_id']},
            {"$push": {"emotion_data": [emotion_data_object]}}
        )
    else:
        return jsonify({"message": "User not found"}), 404

    # Store data in agencies collection
    agency = mongo.db.agencies.find_one({"videos.videoName": video_name})
    if agency:
        # Prepare the agency emotion data object
        agency_emotion_data_object = {
            "timestamp": timestamp,
            "userEmail": user_email,
            "heartRate": heart_rate,
            "emotion": emotions
        }

        # Find the specific video and update its emotion_data
        video = next((v for v in agency['videos'] if v['videoName'] == video_name), None)
        if video:
            if 'emotion_data' not in video:
                # If emotion_data doesn't exist, create it as an array with the new object
                mongo.db.agencies.update_one(
                    {"_id": agency['_id'], "videos.videoName": video_name},
                    {"$set": {"videos.$.emotion_data": [agency_emotion_data_object]}}
                )
            else:
                # If emotion_data exists, append the new object to the array
                mongo.db.agencies.update_one(
                    {"_id": agency['_id'], "videos.videoName": video_name},
                    {"$push": {"videos.$.emotion_data": agency_emotion_data_object}}
                )
        else:
            return jsonify({"message": "Video not found in the agency"}), 404
    else:
        return jsonify({"message": "Agency not found"}), 404

    return jsonify({"message": "Emotion stats stored successfully"}), 200


@app.route('/get_emotion_stats/<user_email>', methods=['GET'])
def get_emotion_stats(user_email):
    user = mongo.db.users.find_one({"email": user_email})
    if not user:
        return jsonify({"message": "User not found"}), 404

    emotion_data = user.get('emotion_data', [])
    print("emotion data: ", emotion_data)
    
    # Initialize a dictionary to store the count of each emotion
    emotion_counts = {}

    for entry in emotion_data:
        for emotion_entry in entry:
            emotion = emotion_entry['emotion']
            
            # Count occurrences of each emotion
            if emotion in emotion_counts:
                emotion_counts[emotion] += 1
            else:
                emotion_counts[emotion] = 1

    print(emotion_counts)
    # Convert counts (seconds) to minutes
    emotion_totals = {emotion: round(count / 60, 2) for emotion, count in emotion_counts.items()}

    return jsonify(emotion_totals), 200


@app.route('/get_user_engagement/<user_email>', methods=['GET'])
def get_user_engagement(user_email):
    user = mongo.db.users.find_one({"email": user_email})
    if not user:
        return jsonify({"message": "User not found"}), 404

    emotion_data = user.get('emotion_data', [])
    
    # Initialize a dictionary to store the count of each emotion
    emotion_counts = {}
    for entry in emotion_data:
        for emotion_entry in entry:
            emotion = emotion_entry['emotion']
            
            if emotion in emotion_counts:
                emotion_counts[emotion] += 1
            else:
                emotion_counts[emotion] = 1

    # Define weights for each emotion (adjust these based on your understanding of engagement)
    emotion_weights = {
        'happy': 1.0,
        'surprised': 1.0,
        'neutral': -0.5,
        'sad': 1.0,
        'angry': 1.0,
        'fear': 1.0
    }

    total_duration = sum(emotion_counts.values())
    weighted_sum = sum(emotion_counts.get(emotion, 0) * weight 
                       for emotion, weight in emotion_weights.items())

    # Calculate engagement score (0-100 scale)
    if total_duration > 0:
        engagement_score = (weighted_sum / total_duration) * 100
    else:
        engagement_score = 0

    # Convert counts to minutes for the frontend
    emotion_totals = {emotion: round(count / 60, 2) for emotion, count in emotion_counts.items()}

    return jsonify({
        "engagement_score": round(engagement_score, 2),
        "emotion_totals": emotion_totals
    }), 200

@app.route('/get_heart_rate_data/<user_email>', methods=['GET'])
def get_heart_rate_data(user_email):
    user = mongo.db.users.find_one({"email": user_email})
    if not user:
        return jsonify({"message": "User not found"}), 404

    emotion_data = user.get('emotion_data', [])
    
    heart_rates = []
    timestamps = []
    
    for entry in emotion_data:
        for emotion_entry in entry:
            heart_rates.append(emotion_entry['heartRate'])
            timestamps.append(emotion_entry['timestamp'].isoformat())

    return jsonify({
        "heart_rates": heart_rates,
        "timestamps": timestamps
    }), 200



@app.route('/start_emotion_detection', methods=['POST'])
def start_emotion_detection():
    global emotion_detection_running, cap
    if not emotion_detection_running:
        emotion_detection_running = True
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            return jsonify({'message': 'Webcam not functional'}), 500
        threading.Thread(target=detect_emotion).start()
        threading.Thread(target=heart_rate_monitor, args=(cap, 160, 120, 320, 240, 3, 170, 1.0, 2.0, 150, 15)).start()
    return jsonify({'message': 'Emotion detection started'}), 200


@app.route('/stop_emotion_detection', methods=['POST'])
def stop_emotion_detection():
    global emotion_detection_running, cap
    emotion_detection_running = False
    if cap:
        cap.release()
    df.to_csv('emotion_detection_results.csv', index=False)
    return jsonify({'message': 'Emotion detection stopped'}), 200

@app.route('/set_user_input/<input>', methods=['POST'])
def set_user_input(input):
    global user_input_text
    user_input_text = input
    return redirect(url_for('emotion_detection'))

@app.route('/emotion_detection')
def emotion_detection():
    return render_template('emotion_detection.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/emotion_feed')
def emotion_feed():
    global emotion, heart_rate, user_input_text
    return jsonify({
        "emotion": emotion,
        "heart_rate": heart_rate,
        "user_input": user_input_text
    })

# Route to fetch current time
@app.route('/get_current_time', methods=['GET'])
def get_current_time():
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return jsonify({'current_time': current_time})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
