import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./components/Home/Home";
import VideoFeed from "./components/VideoFeed/VideoFeed";
import AuthForm from "./components/AuthForm/AuthForm";
import Profile from "./components/Profile/Profile";
import HostWatchParty from "./components/HostWatchParty/HostWatchParty";
import JoinWatchParty from "./components/JoinWatchParty/JoinWatchParty";
import WatchParty from "./components/WatchParty/WatchParty";
import Friends from "./components/Friends/Friends";
import AgencyHome from "./components/AgencyHome/AgencyHome";
import VideoPlayer from "./components/VideoPlayer/VideoPlayer";
import ActiveWatchParty from "./components/ActiveWatchParty/ActiveWatchParty";
import WatchHistory from "./components/WatchHistory/WatchHistory";
import Subscriptions from "./components/Subscriptions/Subscriptions";

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<AuthForm />} />
        <Route path="/home" element={<Home />} />
        <Route path="/agency-home" element={<AgencyHome />} />
        <Route path="/video/:id" element={<VideoPlayer />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/friends" element={<Friends />} />
        <Route path="/host-watch-party" element={<HostWatchParty />} />
        <Route path="/join-watch-party" element={<JoinWatchParty />} />
        <Route path="/watch-party/:id" element={<WatchParty />} />
        <Route path="/active-watch-party" element={<ActiveWatchParty />} />
        <Route path="/watch-history" element={<WatchHistory />} />
        <Route path="/subscriptions" element={<Subscriptions />} />
      </Routes>
    </Router>
  );
};

export default App;
