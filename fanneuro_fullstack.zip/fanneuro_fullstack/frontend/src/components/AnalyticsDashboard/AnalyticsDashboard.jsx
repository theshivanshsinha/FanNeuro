import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const data = [
  { name: "Video 1", views: 4000, likes: 2400, comments: 2400 },
  { name: "Video 2", views: 3000, likes: 1398, comments: 2210 },
  { name: "Video 3", views: 2000, likes: 9800, comments: 2290 },
  { name: "Video 4", views: 2780, likes: 3908, comments: 2000 },
  { name: "Video 5", views: 1890, likes: 4800, comments: 2181 },
];

const AnalyticsDashboard = () => {
  return (
    <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 mt-4">
      <h2 className="text-2xl font-bold mb-4">Analytics Dashboard</h2>
      <ResponsiveContainer width="100%" height={400}>
        <BarChart data={data}>
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="views" fill="#8884d8" />
          <Bar dataKey="likes" fill="#82ca9d" />
          <Bar dataKey="comments" fill="#ffc658" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default AnalyticsDashboard;
