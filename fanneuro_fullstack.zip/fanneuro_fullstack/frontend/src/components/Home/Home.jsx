import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import axios from "axios";
import {
  FaThumbsUp,
  FaThumbsDown,
  FaHistory,
  FaComment,
  FaShare,
  FaSearch,
  FaEye,
  FaHome,
  FaUsers,
  FaVideo,
  FaTv,
  FaUserFriends,
  FaYoutube,
  FaTrash,
  FaBell,
  FaSignOutAlt,
  FaUserPlus,
  FaUserMinus,
  FaRss,
} from "react-icons/fa";

const Home = () => {
  const userData = useSelector((state) => state.user);
  const [videos, setVideos] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [commentText, setCommentText] = useState("");
  const [showAllComments, setShowAllComments] = useState(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [subscribedVideos, setSubscribedVideos] = useState([]);
  const [watchHistory, setWatchHistory] = useState([]);

  const navigate = useNavigate();

  useEffect(() => {
    fetchVideos();
    fetchSubscribedVideos();
    fetchWatchHistory();
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const fetchVideos = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await axios.get("http://localhost:5000/all_videos");
      setVideos(response.data);
    } catch (error) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchSubscribedVideos = async () => {
    try {
      const response = await axios.get(
        `http://localhost:5000/user_subscribed_videos/${userData.email}`
      );
      setSubscribedVideos(response.data.subscribedVideos);
      console.log("subscribed videos : ", response.data.subscribedVideos);
    } catch (error) {
      console.error("Error fetching subscribed videos:", error);
    }
  };

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleVideoClick = (video) => {
    navigate(`/video/${video._id}`, { state: { video } });
  };

  const fetchWatchHistory = async () => {
    try {
      const response = await axios.get(
        `http://localhost:5000/get_watch_history/${userData.email}`
      );
      setWatchHistory(response.data.watchHistory);
    } catch (error) {
      console.error("Error fetching watch history:", error);
    }
  };

  const handleVideoEnd = async (videoName, duration) => {
    try {
      await axios.post("http://localhost:5000/increment_view", {
        videoName: videoName,
        userEmail: userData.email,
        viewDuration: duration,
      });
      fetchVideos(); // Refresh videos to update view count
      fetchWatchHistory(); // Refresh watch history
    } catch (error) {
      console.error("Error incrementing view count:", error);
    }
  };

  const handleLike = async (videoName) => {
    try {
      console.log("Liking video:", videoName);
      const response = await axios.post("http://localhost:5000/like_video", {
        videoName: videoName,
        userEmail: userData.email,
      });
      console.log("Response from server:", response.data);
      fetchVideos();
    } catch (error) {
      console.error("Error liking video:", error);
    }
  };

  const handleUnlike = async (videoName) => {
    try {
      await axios.post("http://localhost:5000/unlike_video", {
        videoName: videoName,
        userEmail: userData.email,
      });
      fetchVideos();
    } catch (error) {
      console.error("Error unliking video:", error);
    }
  };

  const handleComment = async (videoName) => {
    try {
      await axios.post("http://localhost:5000/add_comment", {
        videoName: videoName,
        userEmail: userData.email,
        commentText,
      });
      setCommentText("");
      fetchVideos();
    } catch (error) {
      console.error("Error adding comment:", error);
    }
  };

  const handleDeleteComment = async (videoName, commentText) => {
    try {
      await axios.post("http://localhost:5000/delete_comment", {
        videoName: videoName,
        commentText: commentText,
        userEmail: userData.email,
      });
      fetchVideos();
    } catch (error) {
      console.error("Error deleting comment:", error);
    }
  };

  const handleShare = (video) => {
    const shareUrl = `${window.location.origin}/video/${video._id}`;
    navigator.clipboard.writeText(shareUrl);
    alert("Video link copied to clipboard!");
  };

  const handleLogout = () => {
    navigate("/");
  };

  const handleSubscribe = async (videoName) => {
    if (window.confirm("Are you sure you want to subscribe to this agency?")) {
      try {
        const response = await axios.post("http://localhost:5000/subscribe", {
          userEmail: userData.email,
          videoName: videoName,
        });

        if (response.status === 200) {
          console.log("Subscription successful:", response.data);
          setSubscribedVideos((prev) => [...prev, videoName]);
          alert("Subscribed successfully!");
        } else {
          console.error("Subscription failed:", response.data.message);
          alert("Subscription failed. Please try again.");
        }
      } catch (error) {
        console.error("Error subscribing:", error);
        alert("An error occurred while subscribing. Please try again.");
      }
    }
  };

  const handleUnsubscribe = async (videoName) => {
    if (
      window.confirm("Are you sure you want to unsubscribe from this agency?")
    ) {
      try {
        await axios.post("http://localhost:5000/unsubscribe", {
          userEmail: userData.email,
          videoName: videoName,
        });
        setSubscribedVideos((prev) => prev.filter((v) => v !== videoName));
        alert("Unsubscribed successfully!");
      } catch (error) {
        console.error("Error unsubscribing:", error);
        alert("An error occurred while unsubscribing. Please try again.");
      }
    }
  };

  function getYouTubeVideoId(url) {
    const regExp =
      /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return match && match[2].length === 11 ? match[2] : null;
  }

  const renderComments = (video, limit = 2) => {
    if (!video.comments || video.comments.length === 0) {
      return <p className="text-gray-500 text-sm">No comments yet.</p>;
    }

    const commentsToShow = limit
      ? video.comments.slice(0, limit)
      : video.comments;
    return (
      <div className="mt-4">
        {commentsToShow.map((comment, index) => (
          <div
            key={index}
            className="bg-gray-100 p-2 mb-2 rounded flex justify-between items-start"
          >
            <div>
              <p className="text-sm font-semibold">{comment.user}</p>
              <p className="text-sm">{comment.text}</p>
            </div>
            {comment.user === userData.email && (
              <button
                onClick={() =>
                  handleDeleteComment(video.videoName, comment.text)
                }
                className="text-red-500 hover:text-red-700"
              >
                <FaTrash />
              </button>
            )}
          </div>
        ))}
      </div>
    );
  };

  const filteredVideos = videos.filter((video) =>
    video.videoName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return <div className="text-center mt-8">Loading videos...</div>;
  }

  if (error) {
    return <div className="text-center mt-8 text-red-500">Error: {error}</div>;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navigation Bar */}
      <nav className="bg-gradient-to-r from-blue-500 to-purple-600 shadow-md p-4 flex items-center justify-between fixed top-0 left-0 right-0 z-10">
        <div className="flex items-center space-x-4">
          <Link to="/" className="text-white font-bold text-2xl">
            FanNeuro
          </Link>
        </div>
        <div className="flex-grow mx-8 relative">
          <input
            type="text"
            placeholder="Search videos..."
            className="w-full px-4 py-2 pl-10 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-300"
            value={searchTerm}
            onChange={handleSearch}
          />
          <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        </div>
        <div className="flex items-center space-x-4">
          <button className="text-white hover:text-gray-200">
            <FaBell className="text-xl" />
          </button>
          <Link to="/profile" className="text-white hover:text-gray-200">
            <img
              src={userData.avatar || "https://via.placeholder.com/40"}
              alt="Profile"
              className="w-8 h-8 rounded-full border-2 border-white"
            />
          </Link>
          <button
            onClick={handleLogout}
            className="text-white hover:text-gray-200 flex items-center"
          >
            <FaSignOutAlt className="mr-2" />
            Logout
          </button>
        </div>
      </nav>

      {/* Welcome Message */}
      <div className="bg-white shadow-md p-4 fixed top-16 left-64 right-0 z-5">
        <div className="container mx-auto flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">
            Welcome, {userData.name}!
          </h2>
          <p className="text-gray-600">
            {currentTime.toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto mt-36 p-4 ml-64">
        <h1 className="text-3xl font-bold mb-6 text-gray-800">
          Trending Videos
        </h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVideos.map((video) => (
            <div
              key={video._id}
              className="bg-white overflow-hidden shadow-lg rounded-lg transition-all duration-300 ease-in-out transform hover:scale-105 cursor-pointer"
              onClick={() => handleVideoClick(video)}
            >
              <div className="relative pb-[56.25%]">
                <iframe
                  src={`https://www.youtube.com/embed/${getYouTubeVideoId(
                    video.youtubeLink
                  )}`}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="absolute top-0 left-0 w-full h-full"
                  onTimeUpdate={(e) => {
                    const currentTime = e.target.currentTime;
                    if (currentTime >= 5) {
                      handleVideoEnd(video.videoName, 7);
                    }
                  }}
                ></iframe>
              </div>
              <div className="px-4 py-5 sm:p-6">
                <div className="flex items-center">
                  <FaYoutube className="text-red-500 mr-2 text-xl" />
                  <h3 className="text-lg font-medium text-gray-900 truncate">
                    {video.videoName}
                  </h3>
                </div>
                <p className="mt-2 text-sm text-gray-500 line-clamp-2">
                  {video.videoDescription}
                </p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {video.videoTags &&
                    video.videoTags.map((tag, index) => (
                      <span
                        key={index}
                        className="inline-block bg-gray-200 rounded-full px-3 py-1 text-xs font-semibold text-gray-700"
                      >
                        {tag}
                      </span>
                    ))}
                </div>
                <div className="mt-4 flex justify-between items-center">
                  <div className="flex space-x-4">
                    <button
                      className="flex items-center text-gray-600 hover:text-blue-500"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleLike(video.videoName);
                      }}
                    >
                      <FaThumbsUp className="mr-1" />
                      <span>{video.likes}</span>
                    </button>
                    <button
                      className="flex items-center text-gray-600 hover:text-red-500"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleUnlike(video.videoName);
                      }}
                    >
                      <FaThumbsDown className="mr-1" />
                      <span>{video.dislikes}</span>
                    </button>
                    <button
                      className="flex items-center text-gray-600 hover:text-green-500"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleVideoClick(video);
                      }}
                    >
                      <FaComment className="mr-1" />
                      <span>{video.comments.length}</span>
                    </button>
                    <button
                      className="flex items-center text-gray-600 hover:text-yellow-500"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleShare(video);
                      }}
                    >
                      <FaShare className="mr-1" />
                      <span>Share</span>
                    </button>
                    {subscribedVideos.includes(video.videoName) ? (
                      <button
                        className="flex items-center text-red-500 hover:text-red-700"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleUnsubscribe(video.videoName);
                        }}
                      >
                        <FaUserMinus className="mr-1" />
                        <span>Unsubscribe</span>
                        <div className="flex items-center text-gray-500 ml-3">
                          <FaEye className="mr-1 " />
                          <span>{video.views || 0}</span>
                        </div>
                      </button>
                    ) : (
                      <button
                        className="flex items-center text-green-500 hover:text-green-700"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSubscribe(video.videoName);
                        }}
                      >
                        <FaUserPlus className="mr-1" />
                        <span>Subscribe</span>
                      </button>
                    )}
                  </div>
                </div>
                <div className="mt-4">
                  {renderComments(
                    video,
                    showAllComments === video._id ? null : 2
                  )}
                  {video.comments.length > 2 && (
                    <button
                      className="text-blue-500 hover:underline mt-2 text-sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowAllComments(
                          showAllComments === video._id ? null : video._id
                        );
                      }}
                    >
                      {showAllComments === video._id
                        ? "Show Less"
                        : "Show All Comments"}
                    </button>
                  )}
                  <div className="mt-4 flex">
                    <input
                      type="text"
                      className="w-full p-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Add a comment..."
                      value={commentText}
                      onClick={(e) => e.stopPropagation()}
                      onChange={(e) => setCommentText(e.target.value)}
                    />
                    <button
                      className="bg-blue-500 text-white px-4 py-2 rounded-r-md"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleComment(video.videoName);
                      }}
                    >
                      Comment
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Sidebar */}
      <div className="fixed top-16 left-0 w-64 bg-white shadow-md h-full">
        <ul className="space-y-2 mt-4">
          <li>
            <Link
              to="/home"
              className="flex items-center p-3 text-gray-700 hover:bg-blue-100 rounded-lg transition-all duration-200"
            >
              <FaHome className="mr-3 text-blue-500" />
              <span>Home</span>
            </Link>
          </li>
          <li>
            <Link
              to="/subscriptions"
              className="flex items-center p-3 text-gray-700 hover:bg-blue-100 rounded-lg transition-all duration-200"
            >
              <FaRss className="mr-3 text-red-500" />
              <span>My Subscriptions</span>
            </Link>
          </li>
          <li>
            <Link
              to="/friends"
              className="flex items-center p-3 text-gray-700 hover:bg-blue-100 rounded-lg transition-all duration-200"
            >
              <FaUserFriends className="mr-3 text-green-500" />
              <span>Friends</span>
            </Link>
          </li>
          <li>
            <Link
              to="/watch-history"
              className="flex items-center p-3 text-gray-700 hover:bg-blue-100 rounded-lg transition-all duration-200"
            >
              <FaHistory className="mr-3 text-purple-500" />
              <span>Watch History</span>
            </Link>
          </li>
          <li>
            <Link
              to="/host-watch-party"
              className="flex items-center p-3 text-gray-700 hover:bg-blue-100 rounded-lg transition-all duration-200"
            >
              <FaTv className="mr-3 text-purple-500" />
              <span>Host Watch Party</span>
            </Link>
          </li>
          <li>
            <Link
              to="/join-watch-party"
              className="flex items-center p-3 text-gray-700 hover:bg-blue-100 rounded-lg transition-all duration-200"
            >
              <FaUsers className="mr-3 text-yellow-500" />
              <span>Join Watch Party</span>
            </Link>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Home;
