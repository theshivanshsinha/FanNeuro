import React, { useEffect, useState, useRef } from "react";
import { Line, Bar, Pie } from "react-chartjs-2";
import { useSelector } from "react-redux";
import axios from "axios";
import { Chart as ChartJS, registerables } from "chart.js";
ChartJS.register(...registerables);

const VideoFeed = ({ videoDetails }) => {
  const [emotion, setEmotion] = useState("Loading...");
  const [heartRate, setHeartRate] = useState("Loading...");
  const [emotionData, setEmotionData] = useState({});
  const [heartRateHistory, setHeartRateHistory] = useState([]);
  const [accumulatedHeartRate, setAccumulatedHeartRate] = useState([]);
  const [accumulatedEmotion, setAccumulatedEmotion] = useState([]);
  const user = useSelector((state) => state.user);
  const videoRef = useRef(null);

  useEffect(() => {
    const updateFeeds = async () => {
      try {
        const response = await fetch("http://localhost:5000/emotion_feed");
        const data = await response.json();
        console.log("emotion response data from emotion feed endpoint", data);

        // Store the emotion data immediately
        await storeEmotionData(data);

        setEmotion(data.emotion);
        setHeartRate(data.heart_rate);
        updateEmotionData(data.emotion);
        setHeartRateHistory((prevHistory) => [
          ...prevHistory,
          { time: new Date(), rate: data.heart_rate },
        ]);
      } catch (error) {
        console.error("Error fetching emotion feed:", error);
      }
    };

    const interval = setInterval(updateFeeds, 1000);

    const startVideoStream = async () => {
      try {
        const response = await fetch("http://localhost:5000/video_feed");
        if (response.ok) {
          videoRef.current.srcObject = response.body;
        } else {
          console.error("Failed to fetch video feed");
        }
      } catch (error) {
        console.error("Error fetching video feed:", error);
      }
    };

    startVideoStream();

    return () => {
      clearInterval(interval);
    };
  }, [videoDetails]);

  const storeEmotionData = async (data) => {
    if (!videoDetails) return;

    const emotionStats = {
      userEmail: user.email,
      videoName: videoDetails.videoName,
      companyEmail: videoDetails.companyEmail,
      heartRate: data.heart_rate,
      emotion: data.emotion,
      userInput: data.user_input,
    };

    try {
      const response = await axios.post(
        "http://localhost:5000/store_emotion_stats",
        emotionStats
      );

      if (response.status === 200) {
        console.log("Emotion stats stored successfully");
      } else {
        console.error("Failed to store emotion stats");
      }
    } catch (error) {
      console.error("Error storing emotion stats:", error);
    }
  };

  const updateEmotionData = (newEmotion) => {
    setEmotionData((prevData) => {
      const updatedData = { ...prevData };
      updatedData[newEmotion] = (updatedData[newEmotion] || 0) + 1;
      return updatedData;
    });
  };

  const getAggregateMood = () => {
    const maxDuration = Math.max(...Object.values(emotionData));
    return Object.keys(emotionData).find(
      (key) => emotionData[key] === maxDuration
    );
  };

  const getAverageHeartRate = () => {
    const total = heartRateHistory.reduce((sum, item) => sum + item.rate, 0);
    return heartRateHistory.length
      ? (total / heartRateHistory.length).toFixed(2)
      : 0;
  };

  const getTotalEmotionDuration = () => {
    return Object.values(emotionData).reduce(
      (sum, duration) => sum + duration,
      0
    );
  };

  const sendEmotionStats = async () => {
    if (!videoDetails) return;

    const currentStats = {
      userEmail: user.email,
      videoName: videoDetails.videoName,
      companyEmail: videoDetails.companyEmail,
      heartRate: accumulatedHeartRate,
      emotion: accumulatedEmotion,
    };

    console.log("Sending updated emotion stats to backend:", currentStats);

    try {
      const response = await axios.post(
        "http://localhost:5000/store_emotion_stats",
        currentStats
      );

      console.log("Response from server:", response.data);

      if (response.status === 200) {
        console.log("Emotion stats stored successfully");
      } else {
        console.error("Failed to store emotion stats");
      }
    } catch (error) {
      console.error("Error storing emotion stats:", error);
    }
  };

  const emotions = ["sad", "happy", "neutral", "angry", "surprise", "fear"];
  const colors = [
    "#FF6384",
    "#36A2EB",
    "#FFCE56",
    "#4BC0C0",
    "#9966FF",
    "#FF9F40",
    "#C9CBCF",
  ];

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: "bottom",
        labels: {
          font: {
            size: 12,
            family: "'Roboto', sans-serif",
          },
          color: "#555",
        },
      },
      title: {
        display: true,
        font: {
          size: 16,
          family: "'Roboto', sans-serif",
          weight: "bold",
        },
        color: "#333",
        padding: {
          top: 10,
          bottom: 20,
        },
      },
    },
    scales: {
      x: {
        grid: {
          color: "rgba(0, 0, 0, 0.05)",
        },
        ticks: {
          font: {
            size: 12,
            family: "'Roboto', sans-serif",
          },
          color: "#555",
        },
      },
      y: {
        grid: {
          color: "rgba(0, 0, 0, 0.05)",
        },
        ticks: {
          font: {
            size: 12,
            family: "'Roboto', sans-serif",
          },
          color: "#555",
        },
      },
    },
  };

  const barChartData = {
    labels: emotions,
    datasets: [
      {
        label: "Emotion Duration",
        data: emotions.map((e) => emotionData[e] || 0),
        backgroundColor: colors,
      },
    ],
  };

  const pieChartData = {
    labels: emotions,
    datasets: [
      {
        data: emotions.map((e) => emotionData[e] || 0),
        backgroundColor: colors,
      },
    ],
  };

  const lineChartData = {
    labels: emotions,
    datasets: [
      {
        label: "Emotion Duration",
        data: emotions.map((e) => emotionData[e] || 0),
        borderColor: "rgb(75, 192, 192)",
        tension: 0.1,
      },
    ],
  };

  const heartRateChartData = {
    labels: heartRateHistory.map((_, index) => index),
    datasets: [
      {
        label: "Heart Rate",
        data: heartRateHistory.map((item) => item.rate),
        borderColor: "rgb(255, 99, 132)",
        tension: 0.1,
      },
    ],
  };

  return (
    <div style={styles.container}>
      <header style={styles.header}>
        <h1 style={styles.title}>Emotion Analytics Dashboard</h1>
      </header>
      <div style={styles.contentContainer}>
        <div style={styles.sidebar}>
          <div style={styles.videoContainer}>
            <video
              ref={videoRef}
              autoPlay
              muted
              playsInline
              style={styles.video}
            />
          </div>
          <div style={styles.infoTableWrapper}>
            <h2 style={styles.sectionTitle}>Current Statistics</h2>
            <InfoTable
              emotion={emotion}
              heartRate={heartRate}
              aggregateMood={getAggregateMood()}
              averageHeartRate={getAverageHeartRate()}
            />
          </div>
        </div>
        <div style={styles.mainContent}>
          {videoDetails && (
            <div style={styles.videoInfo}>
              <h2 style={styles.videoTitle}>{videoDetails.videoName}</h2>
              <p style={styles.videoDescription}>
                {videoDetails.videoDescription}
              </p>
            </div>
          )}
          <div style={styles.chartsContainer}>
            <div style={styles.chartWrapper}>
              <h2 style={styles.chartTitle}>Emotion Duration</h2>
              <Bar
                data={barChartData}
                options={{
                  ...chartOptions,
                  plugins: {
                    ...chartOptions.plugins,
                    title: {
                      ...chartOptions.plugins.title,
                      text: "Emotion Duration",
                    },
                  },
                }}
              />
            </div>
            <div style={styles.chartWrapper}>
              <h2 style={styles.chartTitle}>Emotion Distribution</h2>
              <Pie
                data={pieChartData}
                options={{
                  ...chartOptions,
                  plugins: {
                    ...chartOptions.plugins,
                    title: {
                      ...chartOptions.plugins.title,
                      text: "Emotion Distribution",
                    },
                  },
                }}
              />
            </div>
            <div style={styles.chartWrapper}>
              <h2 style={styles.chartTitle}>Emotion Trend</h2>
              <Line
                data={lineChartData}
                options={{
                  ...chartOptions,
                  plugins: {
                    ...chartOptions.plugins,
                    title: {
                      ...chartOptions.plugins.title,
                      text: "Emotion Trend",
                    },
                  },
                }}
              />
            </div>
            <div style={styles.chartWrapper}>
              <h2 style={styles.chartTitle}>Heart Rate Trend</h2>
              <Line
                data={heartRateChartData}
                options={{
                  ...chartOptions,
                  plugins: {
                    ...chartOptions.plugins,
                    title: {
                      ...chartOptions.plugins.title,
                      text: "Heart Rate Trend",
                    },
                  },
                }}
              />
            </div>
          </div>
          <div style={styles.tableWrapper}>
            <h2 style={styles.sectionTitle}>Emotion Duration and Percentage</h2>
            <EmotionDurationTable emotionData={emotionData} />
          </div>
        </div>
      </div>
    </div>
  );
};

const InfoTable = ({ emotion, heartRate, aggregateMood, averageHeartRate }) => (
  <table style={styles.infoTable}>
    <tbody>
      <tr>
        <th style={styles.tableHeader}>Current Emotion</th>
        <td style={styles.tableData}>{emotion}</td>
      </tr>
      <tr>
        <th style={styles.tableHeader}>Current Heart Rate</th>
        <td style={styles.tableData}>{heartRate}</td>
      </tr>
      <tr>
        <th style={styles.tableHeader}>Aggregate Mood</th>
        <td style={styles.tableData}>{aggregateMood}</td>
      </tr>
      <tr>
        <th style={styles.tableHeader}>Average Heart Rate</th>
        <td style={styles.tableData}>{averageHeartRate}</td>
      </tr>
    </tbody>
  </table>
);

const EmotionDurationTable = ({ emotionData }) => {
  const totalDuration = Object.values(emotionData).reduce(
    (sum, value) => sum + value,
    0
  );
  const emotions = ["sad", "happy", "neutral", "angry", "surprise", "fear"];

  return (
    <table style={styles.emotionTable}>
      <thead>
        <tr>
          <th style={styles.emotionTableHeader}>Emotion</th>
          <th style={styles.emotionTableHeader}>Duration</th>
          <th style={styles.emotionTableHeader}>% Time</th>
        </tr>
      </thead>
      <tbody>
        {emotions.map((emotion) => (
          <tr key={emotion}>
            <td style={styles.emotionTableData}>{emotion}</td>
            <td style={styles.emotionTableData}>{emotionData[emotion] || 0}</td>
            <td style={styles.emotionTableData}>
              {(((emotionData[emotion] || 0) / totalDuration) * 100).toFixed(2)}
              %
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

const styles = {
  container: {
    maxWidth: "100%",
    margin: "0 auto",
    padding: "20px",
    fontFamily: "'Roboto', sans-serif",
    backgroundColor: "#f5f7fa",
    color: "#333",
  },
  header: {
    backgroundColor: "#2c3e50",
    padding: "20px",
    marginBottom: "20px",
    borderRadius: "8px",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
  },
  title: {
    color: "#ffffff",
    fontSize: "28px",
    margin: 0,
    textAlign: "center",
  },
  contentContainer: {
    display: "flex",
    gap: "20px",
  },
  sidebar: {
    flex: "0 0 300px",
    display: "flex",
    flexDirection: "column",
    gap: "20px",
  },
  mainContent: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    gap: "20px",
  },
  videoContainer: {
    width: "100%",
    backgroundColor: "#ffffff",
    borderRadius: "8px",
    overflow: "hidden",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
  },
  video: {
    width: "100%",
    height: "auto",
  },
  chartsContainer: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
    gap: "20px",
  },
  chartWrapper: {
    backgroundColor: "#ffffff",
    borderRadius: "8px",
    padding: "20px",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
    height: "300px",
  },
  chartTitle: {
    fontSize: "18px",
    fontWeight: "bold",
    marginBottom: "15px",
    color: "#2c3e50",
  },
  infoTableWrapper: {
    backgroundColor: "#ffffff",
    borderRadius: "8px",
    padding: "20px",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
  },
  tableWrapper: {
    backgroundColor: "#ffffff",
    borderRadius: "8px",
    padding: "20px",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
  },
  sectionTitle: {
    fontSize: "20px",
    fontWeight: "bold",
    marginBottom: "15px",
    color: "#2c3e50",
  },
  infoTable: {
    width: "100%",
    borderCollapse: "separate",
    borderSpacing: "0 8px",
  },
  tableHeader: {
    textAlign: "left",
    padding: "8px",
    backgroundColor: "#f1f3f5",
    color: "#2c3e50",
    fontWeight: "bold",
    borderRadius: "4px 0 0 4px",
  },
  tableData: {
    padding: "8px",
    backgroundColor: "#ffffff",
    borderRadius: "0 4px 4px 0",
  },
  emotionTable: {
    width: "100%",
    borderCollapse: "collapse",
  },
  emotionTableHeader: {
    backgroundColor: "#f1f3f5",
    color: "#2c3e50",
    fontWeight: "bold",
    padding: "12px",
    textAlign: "left",
  },
  emotionTableData: {
    padding: "12px",
    borderBottom: "1px solid #e9ecef",
  },
  videoInfo: {
    backgroundColor: "#ffffff",
    borderRadius: "8px",
    padding: "20px",
    marginBottom: "20px",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
  },
  videoTitle: {
    fontSize: "24px",
    fontWeight: "bold",
    color: "#2c3e50",
    marginBottom: "10px",
  },
  videoDescription: {
    fontSize: "16px",
    color: "#34495e",
  },
};

export default VideoFeed;
