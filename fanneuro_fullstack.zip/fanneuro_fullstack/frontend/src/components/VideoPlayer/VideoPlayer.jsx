import React, { useEffect, useState, useCallback } from "react";
import { useLocation } from "react-router-dom";
import axios from "axios";
import VideoFeed from "../VideoFeed/VideoFeed";
import { useSelector } from "react-redux";
import {
  FaThumbsUp,
  FaThumbsDown,
  FaShare,
  FaBell,
  FaEllipsisH,
  FaExpand,
  FaCompress,
} from "react-icons/fa";

const VideoPlayer = () => {
  const location = useLocation();
  const { video } = location.state;
  const userData = useSelector((state) => state.user);
  const [videoUrl, setVideoUrl] = useState("");
  const [isLiked, setIsLiked] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [subscriptions, setSubscriptions] = useState([]);
  const [viewDuration, setViewDuration] = useState(0);
  const [viewCounted, setViewCounted] = useState(false);

  useEffect(() => {
    fetch("http://localhost:5000/start_emotion_detection", { method: "POST" });
    fetchVideoUrl();
    fetchComments();
    fetchSubscriptions();
    checkSubscriptionStatus();
    return () => {
      fetch("http://localhost:5000/stop_emotion_detection", { method: "POST" });
    };
  }, [video]);

  const incrementViewDuration = useCallback(() => {
    setViewDuration((prevDuration) => prevDuration + 1);
  }, []);

  useEffect(() => {
    const interval = setInterval(incrementViewDuration, 1000);
    return () => clearInterval(interval);
  }, [incrementViewDuration]);

  const sendViewData = useCallback(async () => {
    if (viewDuration > 5 && !viewCounted) {
      try {
        const response = await axios.post(
          "http://localhost:5000/increment_view",
          {
            videoName: video.videoName,
            userEmail: userData.email,
            viewDuration: viewDuration,
          }
        );
        console.log(response.data.message);
        setViewCounted(true);
      } catch (error) {
        console.error("Error incrementing view:", error);
      }
    }
  }, [video.videoName, userData.email, viewDuration, viewCounted]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (!viewCounted) {
        sendViewData();
      }
    }, 5000);

    return () => {
      clearTimeout(timer);
      if (!viewCounted) {
        sendViewData();
      }
    };
  }, [sendViewData, viewCounted]);

  const fetchVideoUrl = async () => {
    try {
      const response = await fetch(
        `http://localhost:5000/get_video_url/${video._id}`
      );
      if (response.ok) {
        const data = await response.json();
        if (data.videoUrl) {
          setVideoUrl(data.videoUrl);
        } else {
          console.error("No video URL returned");
        }
      } else {
        const errorData = await response.json();
        console.error("Failed to fetch video URL:", errorData.error);
      }
    } catch (error) {
      console.error("Error fetching video URL:", error);
    }
  };

  const fetchComments = async () => {
    // Implement fetching comments logic here
  };

  const fetchSubscriptions = async () => {
    // Implement fetching subscriptions logic here
  };

  const checkSubscriptionStatus = async () => {
    try {
      const response = await axios.get(
        `http://localhost:5000/user_subscribed_videos/${userData.email}`
      );
      const subscribedVideos = response.data.subscribedVideos;
      setIsSubscribed(subscribedVideos.includes(video.videoName));
    } catch (error) {
      console.error("Error checking subscription status:", error);
    }
  };

  const handleLike = async (videoName) => {
    try {
      const response = await axios.post("http://localhost:5000/like_video", {
        videoName: videoName,
        userEmail: userData.email,
      });
      setIsLiked(true);
    } catch (error) {
      console.error("Error liking video:", error);
    }
  };

  const handleUnlike = async () => {
    try {
      await axios.post("http://localhost:5000/unlike_video", {
        videoName: video.videoName,
        userEmail: userData.email,
      });
      setIsLiked(false);
    } catch (error) {
      console.error("Error unliking video:", error);
    }
  };

  const handleShare = () => {
    const shareUrl = `${window.location.origin}/video/${video._id}`;
    navigator.clipboard.writeText(shareUrl);
    alert("Video link copied to clipboard!");
  };

  const handleSubscribe = async () => {
    try {
      const response = await axios.post("http://localhost:5000/subscribe", {
        userEmail: userData.email,
        videoName: video.videoName,
      });
      if (response.status === 200) {
        setIsSubscribed(true);
        alert("Subscribed successfully!");
      }
    } catch (error) {
      console.error("Error subscribing:", error);
      alert("An error occurred while subscribing. Please try again.");
    }
  };

  const handleUnsubscribe = async () => {
    try {
      const response = await axios.post("http://localhost:5000/unsubscribe", {
        userEmail: userData.email,
        videoName: video.videoName,
      });
      if (response.status === 200) {
        setIsSubscribed(false);
        alert("Unsubscribed successfully!");
      }
    } catch (error) {
      console.error("Error unsubscribing:", error);
      alert("An error occurred while unsubscribing. Please try again.");
    }
  };

  const handleFullScreen = () => {
    setIsFullScreen(!isFullScreen);
  };

  const handleCommentSubmit = async (e) => {
    e.preventDefault();
    // Implement comment submission logic here
  };

  function getYouTubeVideoId(url) {
    const regExp =
      /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return match && match[2].length === 11 ? match[2] : null;
  }

  const getEmbeddedVideo = () => {
    const videoClass = isFullScreen
      ? "fixed top-0 left-0 w-screen h-screen z-50"
      : "h-[70vh]";

    if (video.youtubeLink) {
      return (
        <div className={videoClass}>
          <iframe
            src={`https://www.youtube.com/embed/${getYouTubeVideoId(
              video.youtubeLink
            )}`}
            title="YouTube video player"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
            className="w-full h-full"
          ></iframe>
        </div>
      );
    } else if (videoUrl) {
      return (
        <div className={videoClass}>
          <video
            src={videoUrl}
            controls
            autoPlay
            className="w-full h-full object-cover"
          />
        </div>
      );
    } else {
      return (
        <div className="aspect-w-16 aspect-h-9 bg-gray-200 flex items-center justify-center">
          <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      );
    }
  };

  return (
    <div className="min-h-screen bg-[#f9f9f9]">
      <header className="bg-white shadow-sm p-2 sticky top-0 z-10">
        <div className="container mx-auto flex justify-between items-center">
          <a href="/" className="text-2xl font-bold text-red-600">
            FanWatch
          </a>
          <div className="flex items-center space-x-4">
            <input
              type="text"
              className="border rounded-full px-4 py-2 w-96 focus:outline-none focus:ring-2 focus:ring-gray-200 transition duration-300"
              placeholder="Search"
            />
          </div>
        </div>
      </header>
      <main className="container mx-auto flex flex-col lg:flex-row py-6 px-4 space-y-4 lg:space-y-0 lg:space-x-6">
        <div className="lg:w-[70%]">
          <div className="bg-black rounded-lg overflow-hidden h-[70vh]">
            {getEmbeddedVideo()}
          </div>
          <div className="mt-3">
            <h1 className="text-xl font-bold text-gray-900 mb-2">
              {video.videoName}
            </h1>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-4">
                <img
                  src={video.companyLogo || "https://via.placeholder.com/40"}
                  alt="Channel Logo"
                  className="w-10 h-10 rounded-full"
                />
                <div>
                  <p className="font-medium text-gray-900">
                    {video.companyName}
                  </p>
                  <p className="text-sm text-gray-500">
                    {video.subscribers} subscribers
                  </p>
                </div>
                {isSubscribed ? (
                  <button
                    onClick={handleUnsubscribe}
                    className="bg-gray-100 text-gray-900 px-4 py-2 rounded-full text-sm font-medium hover:bg-gray-200"
                  >
                    Unsubscribe
                  </button>
                ) : (
                  <button
                    onClick={handleSubscribe}
                    className="bg-red-600 text-white px-4 py-2 rounded-full text-sm font-medium hover:bg-red-700"
                  >
                    Subscribe
                  </button>
                )}
              </div>
              <div className="flex items-center space-x-2">
                <div className="flex items-center bg-gray-100 rounded-full">
                  <button
                    onClick={
                      isLiked ? handleUnlike : () => handleLike(video.videoName)
                    }
                    className={`flex items-center space-x-1 px-3 py-2 rounded-l-full ${
                      isLiked ? "text-blue-600" : "text-gray-600"
                    } hover:bg-gray-200`}
                  >
                    <FaThumbsUp />
                    <span>{video.likes}</span>
                  </button>
                  <div className="h-6 w-px bg-gray-300"></div>
                  <button className="flex items-center space-x-1 px-3 py-2 rounded-r-full text-gray-600 hover:bg-gray-200">
                    <FaThumbsDown />
                  </button>
                </div>
                <button
                  onClick={handleShare}
                  className="flex items-center space-x-1 bg-gray-100 text-gray-600 px-3 py-2 rounded-full hover:bg-gray-200"
                >
                  <FaShare />
                  <span>Share</span>
                </button>
                <button className="flex items-center space-x-1 bg-gray-100 text-gray-600 px-3 py-2 rounded-full hover:bg-gray-200">
                  <FaEllipsisH />
                </button>
              </div>
            </div>
            <div className="bg-gray-100 rounded-lg p-3 text-sm text-gray-900">
              <p>
                {video.views} views •{" "}
                {new Date(video.uploadDate).toLocaleDateString()}
              </p>
              <p className="mt-2">{video.videoDescription}</p>
            </div>
          </div>
          <div className="mt-6">
            <h3 className="text-xl font-semibold mb-4">
              {video.comments.length} Comments
            </h3>
            <form
              onSubmit={handleCommentSubmit}
              className="mb-6 flex items-start space-x-3"
            >
              <img
                src={
                  userData.profilePicture || "https://via.placeholder.com/40"
                }
                alt="User Avatar"
                className="w-10 h-10 rounded-full"
              />
              <input
                type="text"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                className="flex-grow p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Add a comment..."
              />
              <button
                type="submit"
                className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition duration-300"
              >
                Comment
              </button>
            </form>
            <div className="space-y-4">
              {video.comments.map((comment) => (
                <div key={comment.id} className="flex space-x-3">
                  <img
                    src={comment.userAvatar || "https://via.placeholder.com/40"}
                    alt="User Avatar"
                    className="w-10 h-10 rounded-full"
                  />
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{comment.user}</span>
                      <span className="text-sm text-gray-500">
                        {new Date(comment.timestamp).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="mt-1 text-gray-900">{comment.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="lg:w-[30%]">
          <h3 className="text-lg font-semibold mb-4">Up Next</h3>
        </div>
      </main>
      <VideoFeed videoDetails={video} />
    </div>
  );
};

export default VideoPlayer;
