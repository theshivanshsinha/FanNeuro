import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useDispatch } from "react-redux";
import { setUserData, setAgencyData } from "../../redux/store";

const AuthForm = () => {
  const dispatch = useDispatch();
  const [isLogin, setIsLogin] = useState(true);
  const [isAgency, setIsAgency] = useState(false);
  const [signupStep, setSignupStep] = useState(1);
  const [showEmailOTP, setShowEmailOTP] = useState(false);
  const [showPhoneOTP, setShowPhoneOTP] = useState(false);
  const [emailOTP, setEmailOTP] = useState(["", "", "", "", "", ""]);
  const [phoneOTP, setPhoneOTP] = useState(["", "", "", "", "", ""]);

  const {
    register,
    handleSubmit,
    formState: { errors },
    getValues,
  } = useForm();
  const navigate = useNavigate();

  const handleOTPChange = (index, value, type) => {
    if (type === "email") {
      const newEmailOTP = [...emailOTP];
      newEmailOTP[index] = value;
      setEmailOTP(newEmailOTP);
    } else {
      const newPhoneOTP = [...phoneOTP];
      newPhoneOTP[index] = value;
      setPhoneOTP(newPhoneOTP);
    }
  };

  const sendOTP = async (type) => {
    const endpoint = type === "email" ? "/send_email_otp" : "/send_sms_otp";
    const data =
      type === "email"
        ? { email: getValues("email") }
        : { phone_number: getValues("phone") };
    console.log("data ", data);

    try {
      const response = await fetch(`http://localhost:5000${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      console.log("response ", response);
      const result = await response.json();
      if (response.ok) {
        toast.success("OTP sent successfully");
        type === "email" ? setShowEmailOTP(true) : setShowPhoneOTP(true);
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      toast.error("An error occurred. Please try again.");
    }
  };

  const verifyOTP = async (type) => {
    const endpoint = type === "email" ? "/verify_email_otp" : "/verify_sms_otp";
    const otp = type === "email" ? emailOTP.join("") : phoneOTP.join("");
    const data =
      type === "email"
        ? { email: getValues("email"), otp }
        : { phone_number: getValues("phone"), otp };

    try {
      const response = await fetch(`http://localhost:5000${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await response.json();
      if (response.ok) {
        toast.success("OTP verified successfully");
        // Proceed with signup or login
        if (type === "email") {
          setShowEmailOTP(false);
        } else {
          setShowPhoneOTP(false);
        }
        handleNext();
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      toast.error("An error occurred. Please try again.");
    }
  };

  const onSubmit = async (data) => {
    console.log(data);
    const url = isLogin
      ? isAgency
        ? "http://localhost:5000/agency_login"
        : "http://localhost:5000/login"
      : isAgency
      ? "http://localhost:5000/agency_signup"
      : "http://localhost:5000/signup";

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();
      console.log("result ", result);
      if (response.ok) {
        if (isAgency) {
          dispatch(setAgencyData(result["agencyData "]));
          navigate("/agency-home");
        } else {
          dispatch(setUserData(result.userData));
          navigate("/home");
        }
        toast.success(isLogin ? "Login successful!" : "Signup successful!");
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      toast.error("An error occurred. Please try again.");
    }
  };

  const handleAgencyToggle = () => {
    setIsAgency(!isAgency);
    setSignupStep(1);
  };

  const handleNext = () => {
    if (signupStep < 4) {
      setSignupStep(signupStep + 1);
    }
  };

  const handlePrev = () => {
    if (signupStep > 1) {
      setSignupStep(signupStep - 1);
    }
  };

  return (
    <div className="relative flex flex-col justify-center items-center min-h-screen bg-gradient-to-r from-blue-500 to-indigo-500 p-4">
      <div className="relative bg-white p-8 rounded-lg shadow-lg w-full max-w-md transition-transform transform duration-500 z-10">
        <h1 className="text-3xl font-bold text-center mb-8 text-gray-700">
          {isAgency ? "FanNeuro for Producers" : "FanNeuro"}
        </h1>
        <h2 className="text-2xl font-bold mb-6 text-center text-gray-700">
          {isLogin ? "Login" : `Sign Up (Step ${signupStep}/4)`}
        </h2>
        <form onSubmit={handleSubmit(onSubmit)}>
          {isLogin && (
            <>
              <div className="mb-4">
                <label className="block text-gray-700 font-medium">
                  {isAgency ? "Company Email" : "Email"}
                </label>
                <input
                  {...register(isAgency ? "companyEmail" : "email", {
                    required: true,
                    pattern: /^\S+@\S+$/i,
                  })}
                  type="email"
                  className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                {errors.email && (
                  <p className="text-red-500 text-sm">
                    Valid email is required
                  </p>
                )}
              </div>
              <div className="mb-4">
                <label className="block text-gray-700 font-medium">
                  Password
                </label>
                <input
                  {...register("password", { required: true, minLength: 6 })}
                  type="password"
                  className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                {errors.password && (
                  <p className="text-red-500 text-sm">
                    Password must be at least 6 characters
                  </p>
                )}
              </div>
              <button
                type="submit"
                className="bg-blue-600 text-white py-2 px-4 rounded-lg w-full mt-4 hover:bg-blue-700"
              >
                Login
              </button>
            </>
          )}

          {!isLogin && !isAgency && (
            <>
              {signupStep === 1 && (
                <div className="mb-4">
                  <label className="block text-gray-700 font-medium">
                    Email
                  </label>
                  <input
                    {...register("email", {
                      required: true,
                      pattern: /^\S+@\S+$/i,
                    })}
                    type="email"
                    className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  {errors.email && (
                    <p className="text-red-500 text-sm">
                      Valid email is required
                    </p>
                  )}
                  <button
                    type="button"
                    onClick={() => sendOTP("email")}
                    className="bg-blue-600 text-white py-2 px-4 rounded-lg mt-2 hover:bg-blue-700"
                  >
                    Send Email OTP
                  </button>
                </div>
              )}
              {showEmailOTP && (
                <div className="mb-4">
                  <label className="block text-gray-700 font-medium">
                    Email OTP
                  </label>
                  <div className="flex justify-between mt-2">
                    {emailOTP.map((digit, index) => (
                      <input
                        key={index}
                        type="text"
                        maxLength="1"
                        value={digit}
                        onChange={(e) =>
                          handleOTPChange(index, e.target.value, "email")
                        }
                        className="w-12 h-12 text-center text-2xl border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    ))}
                  </div>
                  <button
                    type="button"
                    onClick={() => verifyOTP("email")}
                    className="bg-green-600 text-white py-2 -4 rounded-lg mt-4 hover:bg-green-700"
                  >
                    Verify Email OTP
                  </button>
                </div>
              )}
              {signupStep === 2 && (
                <>
                  <div className="mb-4">
                    <label className="block text-gray-700 font-medium">
                      Name
                    </label>
                    <input
                      {...register("name", { required: true })}
                      type="text"
                      className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    {errors.name && (
                      <p className="text-red-500 text-sm">Name is required</p>
                    )}
                  </div>
                  <div className="mb-4">
                    <label className="block text-gray-700 font-medium">
                      Gender
                    </label>
                    <select
                      {...register("gender", { required: true })}
                      className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Select Gender</option>
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                      <option value="other">Other</option>
                    </select>
                    {errors.gender && (
                      <p className="text-red-500 text-sm">Gender is required</p>
                    )}
                  </div>
                  <div className="mb-4">
                    <label className="block text-gray-700 font-medium">
                      City
                    </label>
                    <input
                      {...register("city", { required: true })}
                      type="text"
                      className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    {errors.city && (
                      <p className="text-red-500 text-sm">City is required</p>
                    )}
                  </div>
                  <div className="mb-4">
                    <label className="block text-gray-700 font-medium">
                      Age
                    </label>
                    <input
                      {...register("age", { required: true, pattern: /^\d+$/ })}
                      type="text"
                      className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    {errors.age && (
                      <p className="text-red-500 text-sm">
                        Age is required and should be a number
                      </p>
                    )}
                  </div>
                  <div className="mb-4">
                    <label className="block text-gray-700 font-medium">
                      Date of Birth
                    </label>
                    <input
                      {...register("date_of_birth", { required: true })}
                      type="date"
                      className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    {errors.date_of_birth && (
                      <p className="text-red-500 text-sm">
                        Date of Birth is required
                      </p>
                    )}
                  </div>
                </>
              )}
              {signupStep === 3 && (
                <div className="mb-4">
                  <label className="block text-gray-700 font-medium">
                    Phone Number
                  </label>
                  <input
                    {...register("phone", { required: true })}
                    type="tel"
                    className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  {errors.phone && (
                    <p className="text-red-500 text-sm">
                      Phone number is required
                    </p>
                  )}
                  <button
                    type="button"
                    onClick={() => sendOTP("phone")}
                    className="bg-blue-600 text-white py-2 px-4 rounded-lg mt-2 hover:bg-blue-700"
                  >
                    Send Phone OTP
                  </button>
                </div>
              )}
              {showPhoneOTP && (
                <div className="mb-4">
                  <label className="block text-gray-700 font-medium">
                    Phone OTP
                  </label>
                  <div className="flex justify-between mt-2">
                    {phoneOTP.map((digit, index) => (
                      <input
                        key={index}
                        type="text"
                        maxLength="1"
                        value={digit}
                        onChange={(e) =>
                          handleOTPChange(index, e.target.value, "phone")
                        }
                        className="w-12 h-12 text-center text-2xl border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    ))}
                  </div>
                  <button
                    type="button"
                    onClick={() => verifyOTP("phone")}
                    className="bg-green-600 text-white py-2 px-4 rounded-lg mt-4 hover:bg-green-700"
                  >
                    Verify Phone OTP
                  </button>
                </div>
              )}
              {signupStep === 4 && (
                <>
                  <div className="mb-4">
                    <label className="block text-gray-700 font-medium">
                      Password
                    </label>
                    <input
                      {...register("password", {
                        required: true,
                        minLength: 6,
                      })}
                      type="password"
                      className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    {errors.password && (
                      <p className="text-red-500 text-sm">
                        Password must be at least 6 characters
                      </p>
                    )}
                  </div>
                  <div className="mb-4">
                    <label className="block text-gray-700 font-medium">
                      Confirm Password
                    </label>
                    <input
                      {...register("confirmPassword", {
                        required: true,
                        validate: (value) =>
                          value === getValues("password") ||
                          "Passwords do not match",
                      })}
                      type="password"
                      className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    {errors.confirmPassword && (
                      <p className="text-red-500 text-sm">
                        {errors.confirmPassword.message}
                      </p>
                    )}
                  </div>
                </>
              )}
              <div className="flex justify-between mt-4">
                <button
                  type="button"
                  className={`bg-gray-300 text-gray-700 py-2 px-4 rounded-lg ${
                    signupStep === 1 ? "opacity-50 cursor-not-allowed" : ""
                  }`}
                  onClick={handlePrev}
                  disabled={signupStep === 1}
                >
                  Previous
                </button>
                {signupStep < 4 ? (
                  <button
                    type="button"
                    className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700"
                    onClick={handleNext}
                  >
                    Next
                  </button>
                ) : (
                  <button
                    type="submit"
                    className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700"
                  >
                    Sign Up
                  </button>
                )}
              </div>
            </>
          )}

          {!isLogin && isAgency && (
            <>
              {signupStep === 1 && (
                <div className="mb-4">
                  <label className="block text-gray-700 font-medium">
                    Company Email
                  </label>
                  <input
                    {...register("companyEmail", {
                      required: true,
                      pattern: /^\S+@\S+$/i,
                    })}
                    type="email"
                    className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  {errors.companyEmail && (
                    <p className="text-red-500 text-sm">
                      Valid company email is required
                    </p>
                  )}
                  <button
                    type="button"
                    onClick={() => sendOTP("email")}
                    className="bg-blue-600 text-white py-2 px-4 rounded-lg mt-2 hover:bg-blue-700"
                  >
                    Send Email OTP
                  </button>
                </div>
              )}
              {showEmailOTP && (
                <div className="mb-4">
                  <label className="block text-gray-700 font-medium">
                    Email OTP
                  </label>
                  <div className="flex justify-between mt-2">
                    {emailOTP.map((digit, index) => (
                      <input
                        key={index}
                        type="text"
                        maxLength="1"
                        value={digit}
                        onChange={(e) =>
                          handleOTPChange(index, e.target.value, "email")
                        }
                        className="w-12 h-12 text-center text-2xl border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    ))}
                  </div>
                  <button
                    type="button"
                    onClick={() => verifyOTP("email")}
                    className="bg-green-600 text-white py-2 px-4 rounded-lg mt-4 hover:bg-green-700"
                  >
                    Verify Email OTP
                  </button>
                </div>
              )}
              {signupStep === 2 && (
                <>
                  <div className="mb-4">
                    <label className="block text-gray-700 font-medium">
                      Company Name
                    </label>
                    <input
                      {...register("companyName", { required: true })}
                      type="text"
                      className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    {errors.companyName && (
                      <p className="text-red-500 text-sm">
                        Company name is required
                      </p>
                    )}
                  </div>
                  <div className="mb-4">
                    <label className="block text-gray-700 font-medium">
                      Company Telephone
                    </label>
                    <input
                      {...register("companyTelephone", {
                        required: true,
                        pattern: /^\d+$/,
                      })}
                      type="tel"
                      className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    {errors.companyTelephone && (
                      <p className="text-red-500 text-sm">
                        Valid company telephone number is required
                      </p>
                    )}
                  </div>
                  <div className="mb-4">
                    <label className="block text-gray-700 font-medium">
                      Company Address
                    </label>
                    <input
                      {...register("companyAddress", { required: true })}
                      type="text"
                      className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    {errors.companyAddress && (
                      <p className="text-red-500 text-sm">
                        Company address is required
                      </p>
                    )}
                  </div>
                </>
              )}
              {signupStep === 3 && (
                <div className="mb-4">
                  <label className="block text-gray-700 font-medium">
                    Company Logo
                  </label>
                  <input
                    {...register("companyLogo", { required: true })}
                    type="file"
                    accept="image/*"
                    className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  {errors.companyLogo && (
                    <p className="text-red-500 text-sm">
                      Company logo is required
                    </p>
                  )}
                </div>
              )}
              {signupStep === 4 && (
                <>
                  <div className="mb-4">
                    <label className="block text-gray-700 font-medium">
                      Password
                    </label>
                    <input
                      {...register("password", {
                        required: true,
                        minLength: 6,
                      })}
                      type="password"
                      className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    {errors.password && (
                      <p className="text-red-500 text-sm">
                        Password must be at least 6 characters
                      </p>
                    )}
                  </div>
                  <div className="mb-4">
                    <label className="block text-gray-700 font-medium">
                      Confirm Password
                    </label>
                    <input
                      {...register("confirmPassword", {
                        required: true,
                        validate: (value) =>
                          value === getValues("password") ||
                          "Passwords do not match",
                      })}
                      type="password"
                      className="w-full p-2 border border-gray-300 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    {errors.confirmPassword && (
                      <p className="text-red-500 text-sm">
                        {errors.confirmPassword.message}
                      </p>
                    )}
                  </div>
                </>
              )}
              <div className="flex justify-between mt-4">
                <button
                  type="button"
                  className={`bg-gray-300 text-gray-700 py-2 px-4 rounded-lg ${
                    signupStep === 1 ? "opacity-50 cursor-not-allowed" : ""
                  }`}
                  onClick={handlePrev}
                  disabled={signupStep === 1}
                >
                  Previous
                </button>
                {signupStep < 4 ? (
                  <button
                    type="button"
                    className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700"
                    onClick={handleNext}
                  >
                    Next
                  </button>
                ) : (
                  <button
                    type="submit"
                    className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700"
                  >
                    Sign Up
                  </button>
                )}
              </div>
            </>
          )}

          <div className="mt-6 text-center">
            <p className="text-gray-600">
              {isLogin ? "Don't have an account?" : "Already have an account?"}{" "}
              <button
                onClick={() => {
                  setIsLogin(!isLogin);
                  setSignupStep(1);
                }}
                className="text-blue-600 hover:underline transition duration-200 focus:outline-none"
              >
                {isLogin ? "Sign Up" : "Login"}
              </button>
            </p>
          </div>
          <div className="mt-6 text-center">
            <button
              onClick={handleAgencyToggle}
              className="text-blue-600 hover:underline transition duration-200 focus:outline-none"
            >
              {isAgency
                ? "Switch to Consumer Login/Signup"
                : "Agency Login/Signup"}
            </button>
          </div>
        </form>
      </div>
      <ToastContainer />
    </div>
  );
};

export default AuthForm;
