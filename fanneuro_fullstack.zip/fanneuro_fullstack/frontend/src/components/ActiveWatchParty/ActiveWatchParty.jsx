import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { clearWatchPartyDetails } from "../../redux/store";

const ActiveWatchParty = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const watchPartyDetails = useSelector((state) => state.watchParty);
  const user = useSelector((state) => state.user);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [timeRemaining, setTimeRemaining] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (watchPartyDetails) {
      const partyStartTime = new Date(
        watchPartyDetails.date + "T" + watchPartyDetails.time
      );
      const partyEndTime = new Date(
        partyStartTime.getTime() + watchPartyDetails.duration * 60000
      );

      const updateTimeRemaining = () => {
        if (currentTime < partyStartTime) {
          setTimeRemaining(Math.floor((partyStartTime - currentTime) / 1000));
        } else if (currentTime < partyEndTime) {
          setTimeRemaining(Math.floor((partyEndTime - currentTime) / 1000));
        } else {
          setTimeRemaining(0);
        }
      };

      updateTimeRemaining();
      const timer = setInterval(updateTimeRemaining, 1000);
      return () => clearInterval(timer);
    }
  }, [watchPartyDetails, currentTime]);

  const handleEndParty = async () => {
    try {
      await axios.post(
        `http://localhost:5000/api/end-watch-party/${watchPartyDetails.watchPartyId}`
      );
      dispatch(clearWatchPartyDetails());
      navigate("/home");
    } catch (error) {
      console.error("Error ending watch party:", error);
    }
  };

  const handleJoinAsHost = () => {
    const partyStartTime = new Date(
      watchPartyDetails.date + "T" + watchPartyDetails.time
    );
    if (currentTime >= partyStartTime) {
      navigate(`/watch-party/${watchPartyDetails.watchPartyId}`, {
        state: { isHost: true },
      });
    } else {
      alert(
        "The watch party hasn't started yet. Please wait until the scheduled time."
      );
    }
  };

  const handleCopyInviteLink = () => {
    navigator.clipboard.writeText(watchPartyDetails.inviteLink);
    alert("Invite link copied to clipboard!");
  };

  if (!watchPartyDetails) {
    return <div>No active watch party found.</div>;
  }

  const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`;
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <div className="w-full max-w-2xl p-8 bg-white rounded-lg shadow-md">
        <h1 className="text-3xl font-bold text-center text-blue-600 mb-6">
          Active Watch Party
        </h1>
        <div className="mb-6">
          <p className="text-lg">
            Host: <span className="font-semibold">{user.name}</span>
          </p>
          <p className="text-sm text-gray-600">
            Current time: {currentTime.toLocaleString()}
          </p>
        </div>
        <div className="space-y-4">
          <p>
            <span className="font-semibold">Invite Link:</span>{" "}
            <button
              onClick={handleCopyInviteLink}
              className="text-blue-500 underline"
            >
              {watchPartyDetails.inviteLink}
            </button>
          </p>
          <p>
            <span className="font-semibold">Time Remaining:</span>{" "}
            {formatTime(timeRemaining)}
          </p>
        </div>
        <div className="mt-8 flex justify-center space-x-4">
          <button
            onClick={handleEndParty}
            className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-full focus:outline-none transition-all duration-300"
          >
            End Party
          </button>
          <button
            onClick={handleJoinAsHost}
            className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-full focus:outline-none transition-all duration-300"
          >
            Join as Host
          </button>
        </div>
      </div>
    </div>
  );
};

export default ActiveWatchParty;
