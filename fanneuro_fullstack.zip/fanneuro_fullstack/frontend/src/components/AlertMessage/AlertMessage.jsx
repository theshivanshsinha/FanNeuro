// src/components/AlertMessage.js

import React from "react";
import "./AlertMessage.css";

const AlertMessage = ({ title, message, type, onClose, onConfirm }) => {
  return (
    <div className={`alert-message ${type}`}>
      <div className="alert-content">
        <h2>{title}</h2>
        <p>{message}</p>
        <div className="alert-buttons">
          <button onClick={onClose}>Close</button>
          {onConfirm && <button onClick={onConfirm}>Confirm</button>}
        </div>
      </div>
    </div>
  );
};

export default AlertMessage;
