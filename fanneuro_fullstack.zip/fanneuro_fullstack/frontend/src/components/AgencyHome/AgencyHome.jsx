import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { useForm } from "react-hook-form";
import { FaVideo, FaYoutube } from "react-icons/fa";
import Select from "react-select";
import VideoDetailsModal from "../VideoDetailsModal/VideoDetailsModal";
import {
  BarChart,
  Bar,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  AreaChart,
  Area,
} from "recharts";
import { useNavigate } from "react-router-dom";
import {
  FaThumbsUp,
  FaThumbsDown,
  FaComment,
  FaShare,
  FaEye,
} from "react-icons/fa";

const AgencyHome = () => {
  const agency = useSelector((state) => state.agency);
  const [activeTab, setActiveTab] = useState("home");
  const { register, handleSubmit, reset } = useForm();
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [selectedTags, setSelectedTags] = useState([]);
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [videoToDelete, setVideoToDelete] = useState(null);
  const [ageRange, setAgeRange] = useState(15);
  const [subscriberCount, setSubscriberCount] = useState(0);
  const [subscribers, setSubscribers] = useState([]);
  const [subscriberStats, setSubscriberStats] = useState({});
  const [videos, setVideos] = useState([]);
  const [totalViews, setTotalViews] = useState(0);
  const [totalLikes, setTotalLikes] = useState(0);
  const [totalComments, setTotalComments] = useState(0);
  const [monthlyWatchers, setMonthlyWatchers] = useState([]);
  useEffect(() => {
    const fetchVideos = async () => {
      try {
        const response = await fetch("http://localhost:5000/videos", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            companyEmail: agency.companyEmail,
          },
        });
        const data = await response.json();
        setVideos(Array.isArray(data) ? data : []);

        // Calculate totals
        let views = 0;
        let likes = 0;
        let comments = 0;
        data.forEach((video) => {
          views += video.views ? video.views.length : 0;
          likes += video.likes ? video.likes.length : 0;
          comments += video.comments ? video.comments.length : 0;
        });
        setTotalViews(views);
        setTotalLikes(likes);
        setTotalComments(comments);
      } catch (error) {
        console.error("Error fetching videos", error);
        setVideos([]);
      }
    };

    const fetchSubscribers = async () => {
      try {
        const response = await fetch("http://localhost:5000/subscribers", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            companyEmail: agency.companyEmail,
          },
        });
        const data = await response.json();
        setSubscriberCount(data.subscribers.length);
        setSubscribers(data.subscribers);
      } catch (error) {
        console.error("Error fetching subscribers", error);
      }
    };

    fetchVideos();
    fetchSubscribers();
  }, [agency.companyEmail]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchVideos = async () => {
      try {
        const response = await fetch("http://localhost:5000/videos", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            companyEmail: agency.companyEmail,
          },
        });
        const data = await response.json();
        setVideos(Array.isArray(data) ? data : []);

        // Calculate totals
        let views = 0;
        let likes = 0;
        let comments = 0;
        data.forEach((video) => {
          views += video.views ? video.views.length : 0;
          likes += video.likes ? video.likes.length : 0;
          comments += video.comments ? video.comments.length : 0;
        });
        setTotalViews(views);
        setTotalLikes(likes);
        setTotalComments(comments);

        // Update monthly watchers
        const updatedMonthlyWatchers = [
          { month: "Jan", watchers: 0 },
          { month: "Feb", watchers: 0 },
          { month: "Mar", watchers: 0 },
          { month: "Apr", watchers: 0 },
          { month: "May", watchers: 0 },
          { month: "Jun", watchers: 0 },
          { month: "Jul", watchers: views },
        ];
        setMonthlyWatchers(updatedMonthlyWatchers);
      } catch (error) {
        console.error("Error fetching videos", error);
        setVideos([]);
      }
    };

    const fetchSubscribers = async () => {
      try {
        const response = await fetch("http://localhost:5000/subscribers", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            companyEmail: agency.companyEmail,
          },
        });
        const data = await response.json();
        setSubscriberCount(data.subscribers.length);
        setSubscribers(data.subscribers);
      } catch (error) {
        console.error("Error fetching subscribers", error);
      }
    };

    fetchVideos();
    fetchSubscribers();
  }, [agency.companyEmail]);

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"];

  const emotionOptions = [
    { value: "happy", label: "Happy" },
    { value: "sad", label: "Sad" },
    { value: "surprised", label: "Surprised" },
    { value: "neutral", label: "Neutral" },
    { value: "angry", label: "Angry" },
    { value: "fear", label: "Fear" },
  ];

  const onSubmit = async (data) => {
    const formData = new FormData();
    formData.append("companyEmail", agency.companyEmail);
    formData.append("videoName", data.videoName);
    formData.append("videoDescription", data.videoDescription);
    formData.append("youtubeLink", data.youtubeLink);
    formData.append("videoCover", data.videoCover);
    formData.append("targetAgeGroup", data.targetAgeGroup);
    formData.append("targetGender", data.targetGender);
    formData.append("overallEmotion", data.overallEmotion);
    formData.append("adDescription", data.adDescription);
    formData.append("companyName", data.companyName);
    formData.append("productDetails", data.productDetails);

    const tagString = selectedTags.map((tag) => tag.value).join(",");
    formData.append("videoTags", tagString);

    try {
      const response = await fetch("http://localhost:5000/upload_video", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        setUploadSuccess(true);
        reset();
        // Refresh videos after successful upload
        const videosResponse = await fetch("http://localhost:5000/videos", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            companyEmail: agency.companyEmail,
          },
        });
        const updatedVideos = await videosResponse.json();
        setVideos(updatedVideos);
      }
    } catch (error) {
      console.error("Error uploading video", error);
    }
  };

  const handleLogout = () => {
    navigate("/");
  };

  // Helper function to extract YouTube video ID from URL
  function getYouTubeVideoId(url) {
    const regExp =
      /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return match && match[2].length === 11 ? match[2] : null;
  }

  const openVideoDetails = (video) => {
    setSelectedVideo(video);
  };

  const closeVideoDetails = () => {
    setSelectedVideo(null);
  };

  const handleDeleteVideo = (video) => {
    setVideoToDelete(video);
    setShowDeleteConfirmation(true);
  };

  const confirmDeleteVideo = async () => {
    try {
      const response = await fetch("http://localhost:5000/delete_video", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          companyEmail: agency.companyEmail,
        },
        body: JSON.stringify({ videoName: videoToDelete.videoName }),
      });

      if (response.ok) {
        setVideos(
          videos.filter((v) => v.videoName !== videoToDelete.videoName)
        );
        setShowDeleteConfirmation(false);
        setVideoToDelete(null);
      } else {
        console.error("Error deleting video");
      }
    } catch (error) {
      console.error("Error deleting video", error);
    }
  };

  const handleAgeRangeChange = (event) => {
    setAgeRange(event.target.value);
  };

  const getAgeRangeLabel = (value) => {
    if (value <= 15) return "0-15";
    if (value <= 25) return "15-25";
    if (value <= 45) return "25-45";
    return "45+";
  };
  const getCityAnalytics = () => {
    const cityCount = subscribers.reduce((acc, sub) => {
      acc[sub.city] = (acc[sub.city] || 0) + 1;
      return acc;
    }, {});
    return Object.entries(cityCount).map(([name, value]) => ({ name, value }));
  };

  const getGenderAnalytics = () => {
    const genderCount = subscribers.reduce((acc, sub) => {
      acc[sub.gender] = (acc[sub.gender] || 0) + 1;
      return acc;
    }, {});
    return Object.entries(genderCount).map(([name, value]) => ({
      name,
      value,
    }));
  };

  const cityData = getCityAnalytics();
  const genderData = getGenderAnalytics();

  return (
    <div className="bg-gray-100 min-h-screen">
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                {agency.companyLogo ? (
                  <img
                    className="h-8 w-auto"
                    src={agency.companyLogo}
                    alt={agency.companyName}
                  />
                ) : (
                  <span className="text-xl font-bold">
                    {agency.companyName}
                  </span>
                )}
              </div>
            </div>
            <div className="flex items-center">
              <button
                onClick={() => setActiveTab("home")}
                className={`px-3 py-2 rounded-md text-sm font-medium ${
                  activeTab === "home"
                    ? "bg-gray-900 text-white"
                    : "text-gray-300 hover:bg-gray-700 hover:text-white"
                }`}
              >
                Home
              </button>
              <button
                onClick={() => setActiveTab("upload")}
                className={`ml-4 px-3 py-2 rounded-md text-sm font-medium ${
                  activeTab === "upload"
                    ? "bg-gray-900 text-white"
                    : "text-gray-300 hover:bg-gray-700 hover:text-white"
                }`}
              >
                Upload Video
              </button>

              <button
                onClick={handleLogout}
                className="ml-4 px-3 py-2 rounded-md text-sm font-medium text-gray-300 hover:bg-gray-700 hover:text-white"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {activeTab === "home" && (
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              Welcome, {agency.companyName}
            </h1>
            <div className="bg-white shadow overflow-hidden sm:rounded-lg mb-6">
              <div className="px-4 py-5 sm:px-6">
                <h2 className="text-lg leading-6 font-medium text-gray-900">
                  Agency Information
                </h2>
              </div>
              <div className="border-t border-gray-200 px-4 py-5 sm:p-0">
                <dl className="sm:divide-y sm:divide-gray-200">
                  <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">Email</dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                      {agency.companyEmail}
                    </dd>
                  </div>
                  <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">Phone</dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                      {agency.companyTelephone}
                    </dd>
                  </div>
                  <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">
                      Address
                    </dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                      {agency.companyAddress}
                    </dd>
                  </div>
                  <div className="mt-8">
                    <h2 className="text-2xl font-bold text-gray-900 mb-4">
                      Subscribers ({subscribers.length})
                    </h2>
                    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
                      <div className="px-4 py-5 sm:px-6">
                        <h3 className="text-lg leading-6 font-medium text-gray-900">
                          Subscriber Details
                        </h3>
                      </div>
                      <div className="border-t border-gray-200">
                        <div className="max-h-96 overflow-y-auto">
                          <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50">
                              <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                  Name
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                  Email
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                  Age
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                  Gender
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                  City
                                </th>
                              </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                              {subscribers.map((subscriber, index) => (
                                <tr key={index}>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                    {subscriber.name}
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    {subscriber.email}
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    {subscriber.age}
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    {subscriber.gender}
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    {subscriber.city}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                      <div className="mt-8 bg-white shadow overflow-hidden sm:rounded-lg">
                        <div className="px-4 py-5 sm:p-6">
                          <h3 className="text-lg leading-6 font-medium text-gray-900">
                            Total Statistics
                          </h3>
                          <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-3">
                            <div className="bg-white overflow-hidden shadow rounded-lg">
                              <div className="px-4 py-5 sm:p-6">
                                <dt className="text-sm font-medium text-gray-500 truncate">
                                  Total Views
                                </dt>
                                <dd className="mt-1 text-3xl font-semibold text-gray-900">
                                  {totalViews}
                                </dd>
                              </div>
                            </div>
                            <div className="bg-white overflow-hidden shadow rounded-lg">
                              <div className="px-4 py-5 sm:p-6">
                                <dt className="text-sm font-medium text-gray-500 truncate">
                                  Total Likes
                                </dt>
                                <dd className="mt-1 text-3xl font-semibold text-gray-900">
                                  {totalLikes}
                                </dd>
                              </div>
                            </div>
                            <div className="bg-white overflow-hidden shadow rounded-lg">
                              <div className="px-4 py-5 sm:p-6">
                                <dt className="text-sm font-medium text-gray-500 truncate">
                                  Total Comments
                                </dt>
                                <dd className="mt-1 text-3xl font-semibold text-gray-900">
                                  {totalComments}
                                </dd>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </dl>
              </div>
            </div>
            {/* Monthly Watchers graph */}
            <div className="mt-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Monthly Watchers
              </h2>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart
                  data={monthlyWatchers}
                  margin={{ top: 5, right: 20, left: 10, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="watchers"
                    stroke="#8884d8"
                    activeDot={{ r: 8 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Video Performance */}
            <div className="mt-8 bg-white shadow overflow-hidden sm:rounded-lg">
              <div className="px-4 py-5 sm:p-6">
                <h3 className="text-lg leading-6 font-medium text-gray-900">
                  Video Performance
                </h3>
                {videos && videos.length > 0 ? (
                  <ResponsiveContainer width="100%" height={400}>
                    <BarChart
                      data={videos.map((video) => ({
                        name: video.videoName,
                        views: video.views ? video.views.length : 0,
                        likes: video.likes ? video.likes.length : 0,
                        comments: video.comments ? video.comments.length : 0,
                      }))}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="views" fill="#8884d8" />
                      <Bar dataKey="likes" fill="#82ca9d" />
                      <Bar dataKey="comments" fill="#ffc658" />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <p>No video performance data available</p>
                )}
                {/* Growth Suggestions */}
                <div className="bg-blue-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-4">
                    Growth Suggestions
                  </h3>
                  {videos && videos.length > 0 ? (
                    <ul className="list-disc pl-5 space-y-2">
                      {videos.map((video) => {
                        const viewCount = video.views ? video.views.length : 0;
                        const likeCount = video.likes ? video.likes.length : 0;
                        const commentCount = video.comments
                          ? video.comments.length
                          : 0;
                        const engagementRate =
                          viewCount > 0
                            ? ((likeCount + commentCount) / viewCount) * 100
                            : 0;

                        let suggestion = "";
                        if (engagementRate < 5) {
                          suggestion = `Improve engagement for "${video.videoName}" by encouraging likes and comments. Consider adding call-to-actions in the video.`;
                        } else if (viewCount < 1000) {
                          suggestion = `Boost visibility for "${video.videoName}" through cross-promotion and sharing on social media platforms.`;
                        } else if (likeCount < viewCount * 0.1) {
                          suggestion = `Enhance content quality for "${video.videoName}" to increase like-to-view ratio. Focus on delivering more value to viewers.`;
                        }

                        return suggestion ? (
                          <li key={video.videoName}>{suggestion}</li>
                        ) : null;
                      })}
                      <li>
                        Consistently post new content to keep your audience
                        engaged and attract new subscribers.
                      </li>
                      <li>
                        Analyze your most successful videos and create similar
                        content to replicate that success.
                      </li>
                      <li>
                        Collaborate with other content creators or brands to
                        reach new audiences.
                      </li>
                    </ul>
                  ) : (
                    <p>
                      Upload more videos to receive personalized growth
                      suggestions.
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Demographics */}
            <div className="mt-8 bg-white shadow overflow-hidden sm:rounded-lg">
              <div className="px-4 py-5 sm:p-6">
                <h3 className="text-lg leading-6 font-medium text-gray-900">
                  Subscriber Demographics
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div>
                    <h4 className="text-md font-medium mb-2">
                      City Distribution
                    </h4>
                    {cityData.length > 0 ? (
                      <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                          <Pie
                            data={cityData}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            outerRadius={80}
                            fill="#8884d8"
                            label
                          >
                            {cityData.map((entry, index) => (
                              <Cell
                                key={`cell-${index}`}
                                fill={COLORS[index % COLORS.length]}
                              />
                            ))}
                          </Pie>
                          <Tooltip />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    ) : (
                      <p>No city data available</p>
                    )}
                  </div>

                  <div>
                    <h4 className="text-md font-medium mb-2">
                      Gender Distribution
                    </h4>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={genderData}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          outerRadius={80}
                          fill="#82ca9d"
                          label
                        >
                          {genderData.map((entry, index) => (
                            <Cell
                              key={`cell-${index}`}
                              fill={COLORS[index % COLORS.length]}
                            />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="mt-4">
                      <h5 className="font-medium mb-2">
                        Demographic Insights:
                      </h5>
                      <ul className="list-disc pl-5 space-y-2">
                        {cityData.length > 0 && (
                          <li>
                            The most common city among subscribers is{" "}
                            {cityData.sort((a, b) => b.value - a.value)[0].name}
                            .
                          </li>
                        )}
                        {genderData.length > 0 && (
                          <li>
                            The gender distribution shows a{" "}
                            {genderData
                              .sort((a, b) => b.value - a.value)[0]
                              .name.toLowerCase()}{" "}
                            majority.
                          </li>
                        )}
                        <li>
                          Consider tailoring content to appeal to the dominant
                          demographics while also creating inclusive content for
                          all groups.
                        </li>
                        <li>
                          Explore opportunities to expand your subscriber base
                          in underrepresented cities or demographics.
                        </li>
                        <li>
                          Use these insights to inform your content strategy and
                          target your marketing efforts.
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <h2 className="text-2xl font-bold text-gray-900 mb-4 mt-8">
              Your YouTube Videos
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.isArray(videos) && videos.length > 0 ? (
                videos.map((video) => (
                  <div
                    key={video._id}
                    className="bg-white overflow-hidden shadow-lg rounded-lg transition-transform duration-300 ease-in-out transform hover:scale-105"
                  >
                    <div className="relative pb-[56.25%]">
                      <iframe
                        src={`https://www.youtube.com/embed/${getYouTubeVideoId(
                          video.youtubeLink
                        )}`}
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        className="absolute top-0 left-0 w-full h-full"
                      ></iframe>
                    </div>
                    <div className="px-4 py-5">
                      <div className="flex items-center mb-3">
                        <FaYoutube className="text-red-500 mr-2 text-xl" />
                        <h3 className="text-lg font-medium text-gray-900 truncate">
                          {video.videoName}
                        </h3>
                      </div>
                      <p className="text-sm text-gray-500 mb-4 line-clamp-2">
                        {video.videoDescription}
                      </p>
                      <div className="flex flex-wrap gap-2 mb-4">
                        {video.videoTags.map((tag, index) => (
                          <span
                            key={index}
                            className="inline-block bg-gray-200 rounded-full px-3 py-1 text-xs font-semibold text-gray-700"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                      <div className="flex justify-between items-center mb-4">
                        <div className="flex space-x-4">
                          <button className="flex items-center text-gray-600 hover:text-blue-500 transition-colors">
                            <FaThumbsUp className="mr-1" />
                            <span>{video.likes ? video.likes.length : 0}</span>
                          </button>
                          <button className="flex items-center text-gray-600 hover:text-red-500 transition-colors">
                            <FaThumbsDown className="mr-1" />
                            <span>{video.dislikes || 0}</span>
                          </button>
                          <button className="flex items-center text-gray-600 hover:text-green-500 transition-colors">
                            <FaComment className="mr-1" />
                            <span>
                              {video.comments ? video.comments.length : 0}
                            </span>
                          </button>
                        </div>
                        <button className="flex items-center text-gray-600 hover:text-purple-500 transition-colors">
                          <FaShare className="mr-1" />
                          Share
                        </button>
                        <button className="flex items-center text-gray-600 hover:text-blue-500 transition-colors">
                          <FaEye className="mr-1" />
                          <span>{video.views ? video.views.length : 0}</span>
                        </button>
                      </div>
                    </div>
                    <div className="px-4 py-3 bg-gray-50">
                      <button
                        onClick={() => openVideoDetails(video)}
                        className="w-full bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
                      >
                        View Details
                      </button>
                      <button
                        onClick={() => handleDeleteVideo(video)}
                        className="w-full bg-red-500 text-white mt-3 py-2 px-4 rounded-lg hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-colors"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-10">
                  <p className="text-xl text-gray-600">No videos available</p>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === "upload" && (
          <div className="bg-white shadow-lg rounded-lg px-8 pt-6 pb-8 mb-4 mt-4">
            <h2 className="text-3xl font-bold mb-6 text-gray-800">
              Upload YouTube Video
            </h2>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div>
                <label
                  htmlFor="videoName"
                  className="block text-sm font-semibold text-gray-700 mb-2"
                >
                  Video Name
                </label>
                <input
                  type="text"
                  id="videoName"
                  {...register("videoName", { required: true })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-gray-700"
                  placeholder="Enter video name"
                />
              </div>

              <div>
                <label
                  htmlFor="videoDescription"
                  className="block text-sm font-semibold text-gray-700 mb-2"
                >
                  Video Description
                </label>
                <textarea
                  id="videoDescription"
                  {...register("videoDescription", { required: true })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-gray-700"
                  rows="4"
                  placeholder="Enter video description"
                ></textarea>
              </div>

              <div>
                <label
                  htmlFor="youtubeLink"
                  className="block text-sm font-semibold text-gray-700 mb-2"
                >
                  YouTube Video Link
                </label>
                <div className="flex">
                  <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 text-sm">
                    <FaYoutube className="h-5 w-5 text-red-500" />
                  </span>
                  <input
                    type="text"
                    id="youtubeLink"
                    {...register("youtubeLink", { required: true })}
                    className="flex-1 w-full px-4 py-2 border border-gray-300 rounded-r-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-gray-700"
                    placeholder="https://www.youtube.com/watch?v=..."
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="videoCover"
                  className="block text-sm font-semibold text-gray-700 mb-2"
                >
                  Video Cover Image
                </label>
                <input
                  type="text"
                  id="videoCover"
                  {...register("videoCover", { required: true })}
                  placeholder="Enter image URL"
                  className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-gray-700"
                />
              </div>

              <div>
                <label
                  htmlFor="targetAgeGroup"
                  className="block text-sm font-semibold text-gray-700 mb-2"
                >
                  Target Age Group
                </label>
                <input
                  type="range"
                  id="targetAgeGroup"
                  {...register("targetAgeGroup", { required: true })}
                  min="0"
                  max="55"
                  step="10"
                  value={ageRange}
                  onChange={handleAgeRangeChange}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-gray-500">
                  <span>0</span>
                  <span>15</span>
                  <span>25</span>
                  <span>45</span>
                  <span>55+</span>
                </div>
                <div className="text-sm text-gray-500 mt-2">
                  Selected Age Range: {getAgeRangeLabel(ageRange)}
                </div>
              </div>

              <div>
                <label
                  htmlFor="targetGender"
                  className="block text-sm font-semibold text-gray-700 mb-2"
                >
                  Target Gender
                </label>
                <select
                  id="targetGender"
                  {...register("targetGender", { required: true })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-gray-700"
                >
                  <option value="">Select gender</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="unisex">Unisex</option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="overallEmotion"
                  className="block text-sm font-semibold text-gray-700 mb-2"
                >
                  Overall Emotion
                </label>
                <select
                  id="overallEmotion"
                  {...register("overallEmotion", { required: true })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-gray-700"
                >
                  <option value="">Select emotion</option>
                  <option value="happy">Happy</option>
                  <option value="sad">Sad</option>
                  <option value="angry">Angry</option>
                  <option value="fear">Fear</option>
                  <option value="surprise">Surprise</option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="adDescription"
                  className="block text-sm font-semibold text-gray-700 mb-2"
                >
                  Ad Description
                </label>
                <textarea
                  id="adDescription"
                  {...register("adDescription", { required: true })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-gray-700"
                  rows="4"
                  placeholder="Enter ad description"
                ></textarea>
              </div>

              <div>
                <label
                  htmlFor="videoTags"
                  className="block text-sm font-semibold text-gray-700 mb-2"
                >
                  Product Tags
                </label>
                <Select
                  isMulti
                  options={emotionOptions}
                  value={selectedTags}
                  onChange={(selectedOptions) =>
                    setSelectedTags(selectedOptions)
                  }
                  className="mt-1"
                  classNamePrefix="select"
                  placeholder="Select tags..."
                  theme={(theme) => ({
                    ...theme,
                    colors: {
                      ...theme.colors,
                      primary: "#3B82F6",
                      primary25: "#BFDBFE",
                    },
                  })}
                />
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition duration-200 ease-in-out transform hover:-translate-y-1 hover:scale-105"
              >
                Upload Video
              </button>

              {uploadSuccess && (
                <div className="mt-4 p-4 bg-green-100 border-l-4 border-green-500 text-green-700">
                  <p className="font-medium">Success!</p>
                  <p>Your video has been uploaded successfully.</p>
                </div>
              )}
            </form>
          </div>
        )}
        {selectedVideo && (
          <VideoDetailsModal
            video={selectedVideo}
            onClose={closeVideoDetails}
            agencyEmail={agency.companyEmail}
          />
        )}
      </main>
      {showDeleteConfirmation && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="mt-3 text-center">
              <h3 className="text-lg leading-6 font-medium text-gray-900">
                Delete Video
              </h3>
              <div className="mt-2 px-7 py-3">
                <p className="text-sm text-gray-500">
                  Are you sure you want to delete this video from the database?
                </p>
              </div>
              <div className="items-center px-4 py-3">
                <button
                  onClick={confirmDeleteVideo}
                  className="px-4 py-2 bg-red-500 text-white text-base font-medium rounded-md w-full shadow-sm hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-300 mb-2"
                >
                  Delete
                </button>
                <button
                  onClick={() => setShowDeleteConfirmation(false)}
                  className="px-4 py-2 bg-gray-500 text-white text-base font-medium rounded-md w-full shadow-sm hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-300"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AgencyHome;
