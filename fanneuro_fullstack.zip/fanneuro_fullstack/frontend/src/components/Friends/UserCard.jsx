import React from "react";

const UserCard = ({ user, actionButton }) => {
  return (
    <li className="py-4 transition-all duration-300 hover:bg-gray-50">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <img
            src={user.profile_photo_url || "https://via.placeholder.com/50"}
            alt={user.name}
            className="w-12 h-12 rounded-full mr-4 object-cover"
          />
          <div>
            <h5 className="text-lg font-semibold">{user.name}</h5>
            <p className="text-gray-500 text-sm">
              {user.age && `Age: ${user.age}`}
              {user.age && user.city && " | "}
              {user.city && `City: ${user.city}`}
            </p>
          </div>
        </div>
        <div className="ml-4">{actionButton}</div>
      </div>
    </li>
  );
};

export default UserCard;
