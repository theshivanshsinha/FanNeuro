import React from "react";
import { FaUserFriends } from "react-icons/fa";

const EmptyState = ({ message }) => {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-gray-500">
      <FaUserFriends className="text-6xl mb-4" />
      <p className="text-center">{message}</p>
    </div>
  );
};

export default EmptyState;
