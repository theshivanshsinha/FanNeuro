import React, { useState, useEffect, useMemo, useCallback } from "react";
import { useSelector, useDispatch } from "react-redux";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {
  setFriends,
  addFriend,
  removeFriend,
  setFriendRequests,
  addFriendRequest,
  removeFriendRequest,
} from "../../redux/store";
import {
  FaUserPlus,
  FaUserMinus,
  FaCheck,
  FaTimes,
  FaSearch,
  FaSortAlphaDown,
  FaUserFriends,
  FaUserClock,
  FaMapMarkerAlt,
} from "react-icons/fa";
import { motion, AnimatePresence } from "framer-motion";

const Friends = () => {
  const dispatch = useDispatch();
  const userData = useSelector((state) => state.user);
  const friends = useSelector((state) => state.friends);
  const friendRequests = useSelector((state) => state.friendRequests);

  const [allUsers, setAllUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortOption, setSortOption] = useState("name");
  const [isLoading, setIsLoading] = useState(true);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [confirmAction, setConfirmAction] = useState(null);
  const [activeTab, setActiveTab] = useState("addFriends");

  const fetchData = useCallback(async () => {
    try {
      const [usersResponse, requestsResponse, friendsResponse] =
        await Promise.all([
          axios.get("http://localhost:5000/friends", {
            params: { loggedInEmail: userData.email },
          }),
          axios.get("http://localhost:5000/friend_requests", {
            params: { loggedInEmail: userData.email },
          }),
          axios.get("http://localhost:5000/friends_list", {
            params: { loggedInEmail: userData.email },
          }),
        ]);

      const filteredUsers = usersResponse.data.users.filter(
        (user) =>
          user.email !== userData.email &&
          !friendsResponse.data.friends.some(
            (friend) => friend.email === user.email
          ) &&
          !requestsResponse.data.friendRequests.some(
            (request) => request.email === user.email
          )
      );

      setAllUsers(filteredUsers);
      dispatch(setFriendRequests(requestsResponse.data.friendRequests));
      dispatch(setFriends(friendsResponse.data.friends));
    } catch (error) {
      console.error("Error fetching data:", error);
      toast.error("Failed to fetch data");
    } finally {
      setIsLoading(false);
    }
  }, [userData.email, dispatch]);

  useEffect(() => {
    fetchData();
    const pollInterval = setInterval(fetchData, 10000);
    return () => clearInterval(pollInterval);
  }, [fetchData]);

  const filteredAndSortedUsers = useMemo(() => {
    return allUsers
      .filter((user) =>
        user.name.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .sort((a, b) => {
        if (sortOption === "name") return a.name.localeCompare(b.name);
        if (sortOption === "age") return a.age - b.age;
        if (sortOption === "city")
          return (a.city || "").localeCompare(b.city || "");
        return 0;
      });
  }, [allUsers, searchTerm, sortOption]);

  const handleConfirm = async () => {
    if (confirmAction) {
      await confirmAction();
    }
    setShowConfirmModal(false);
  };

  const addFriendRequest = async (email) => {
    try {
      const response = await axios.post(
        "http://localhost:5000/send_friend_request",
        {
          senderEmail: userData.email,
          receiverEmail: email,
        }
      );

      if (response.data.success) {
        dispatch(addFriendRequest({ email, name: email.split("@")[0] }));
        toast.success(`Friend request sent to ${email}`);
        setAllUsers((prevUsers) =>
          prevUsers.filter((user) => user.email !== email)
        );
      } else {
        throw new Error(
          response.data.message || "Failed to send friend request"
        );
      }
    } catch (error) {
      console.error("Error sending friend request:", error);
      toast.error(
        error.response
          ? error.response.data.message
          : "Failed to send friend request"
      );
    }
  };

  const acceptFriendRequest = async (request) => {
    try {
      await axios.post("http://localhost:5000/accept_friend_request", {
        senderEmail: request.email,
        receiverEmail: userData.email,
      });
      dispatch(addFriend(request));
      dispatch(removeFriendRequest(request.email));
      toast.success(`Friend request accepted from ${request.email}`);
    } catch (error) {
      console.error("Error accepting friend request:", error);
      toast.error("Failed to accept friend request");
    }
  };

  const removeFriendRequestHandler = async (request) => {
    setConfirmAction(() => async () => {
      try {
        await axios.post("http://localhost:5000/remove_friend_request", {
          senderEmail: userData.email,
          receiverEmail: request.email,
        });
        dispatch(removeFriendRequest(request.email));
        toast.success(`Removed friend request sent to ${request.email}`);
      } catch (error) {
        console.error("Error removing friend request:", error);
        toast.error("Failed to remove friend request");
      }
    });
    setShowConfirmModal(true);
  };

  const removeFriendHandler = async (friendEmail) => {
    setConfirmAction(() => async () => {
      try {
        await axios.post("http://localhost:5000/remove_friend", {
          userEmail: userData.email,
          friendEmail: friendEmail,
        });
        dispatch(removeFriend(friendEmail));
        toast.success(`Friend removed: ${friendEmail}`);
      } catch (error) {
        console.error("Error removing friend:", error);
        toast.error("Failed to remove friend");
      }
    });
    setShowConfirmModal(true);
  };

  const UserCard = ({ user, actionButton }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="bg-white rounded-lg shadow-md p-6 mb-4 transition-all duration-300 hover:shadow-lg"
    >
      <div className="flex items-start">
        <img
          src={user.profile_photo_url || "https://via.placeholder.com/80"}
          alt={user.name}
          className="w-20 h-20 rounded-full mr-6 object-cover"
        />
        <div className="flex-grow">
          <h5 className="text-xl font-semibold text-gray-800 mb-2">
            {user.name}
          </h5>
          <p className="text-gray-600 text-sm mb-2">
            {user.age && `Age: ${user.age}`}
          </p>
          <div className="flex items-center text-gray-500 text-sm">
            <FaMapMarkerAlt className="mr-2" />
            <span>{user.city || "Location not specified"}</span>
          </div>
        </div>
        <div className="ml-4">{actionButton}</div>
      </div>
    </motion.div>
  );

  const TabButton = ({ icon, label, isActive, onClick }) => (
    <button
      className={`flex items-center px-6 py-3 rounded-full transition-all duration-200 ${
        isActive
          ? "bg-blue-600 text-white"
          : "bg-gray-100 text-gray-700 hover:bg-gray-200"
      }`}
      onClick={onClick}
    >
      {icon}
      <span className="ml-2 font-medium">{label}</span>
    </button>
  );

  const EmptyState = ({ message, icon }) => (
    <div className="flex flex-col items-center justify-center py-16 text-gray-400">
      {icon}
      <p className="text-center mt-6 text-lg">{message}</p>
    </div>
  );

  return (
    <div className="bg-gray-100 min-h-screen">
      <ToastContainer position="bottom-right" autoClose={3000} />
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        <h1 className="text-4xl font-bold mb-8 text-center text-gray-800">
          Friends
        </h1>
        <div className="mb-8 flex justify-center space-x-4">
          <TabButton
            icon={<FaUserPlus className="text-xl" />}
            label="Add Friends"
            isActive={activeTab === "addFriends"}
            onClick={() => setActiveTab("addFriends")}
          />
          <TabButton
            icon={<FaUserClock className="text-xl" />}
            label="Friend Requests"
            isActive={activeTab === "friendRequests"}
            onClick={() => setActiveTab("friendRequests")}
          />
          <TabButton
            icon={<FaUserFriends className="text-xl" />}
            label="My Friends"
            isActive={activeTab === "myFriends"}
            onClick={() => setActiveTab("myFriends")}
          />
        </div>
        {activeTab === "addFriends" && (
          <div className="mb-6">
            <div className="flex items-center mb-4 bg-white rounded-full shadow-md">
              <FaSearch className="text-gray-400 ml-4" />
              <input
                type="text"
                placeholder="Search friends..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="flex-grow border-none rounded-full px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <select
                value={sortOption}
                onChange={(e) => setSortOption(e.target.value)}
                className="mr-2 border-none rounded-full px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="name">Sort by Name</option>
                <option value="age">Sort by Age</option>
                <option value="city">Sort by City</option>
              </select>
            </div>
          </div>
        )}
        <AnimatePresence>
          {isLoading ? (
            <div className="animate-pulse space-y-4">
              {[...Array(3)].map((_, index) => (
                <div key={index} className="h-32 bg-gray-200 rounded-lg"></div>
              ))}
            </div>
          ) : (
            <>
              {activeTab === "addFriends" && (
                <>
                  {filteredAndSortedUsers.length > 0 ? (
                    <div className="space-y-4">
                      {filteredAndSortedUsers.map((user) => (
                        <UserCard
                          key={user.email}
                          user={user}
                          actionButton={
                            <button
                              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-full transition duration-200 flex items-center"
                              onClick={() => addFriendRequest(user.email)}
                            >
                              <FaUserPlus className="mr-2" />
                              Add Friend
                            </button>
                          }
                        />
                      ))}
                    </div>
                  ) : (
                    <EmptyState
                      message="No users available to add as friends."
                      icon={<FaUserPlus className="text-7xl" />}
                    />
                  )}
                </>
              )}
              {activeTab === "friendRequests" && (
                <>
                  {friendRequests.length > 0 ? (
                    <div className="space-y-4">
                      {friendRequests.map((request) => (
                        <UserCard
                          key={request.email}
                          user={request}
                          actionButton={
                            <div className="flex space-x-2">
                              <button
                                className="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded-full transition duration-200 flex items-center"
                                onClick={() => acceptFriendRequest(request)}
                              >
                                <FaCheck className="mr-2" />
                                Accept
                              </button>
                              <button
                                className="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-full transition duration-200 flex items-center"
                                onClick={() =>
                                  removeFriendRequestHandler(request)
                                }
                              >
                                <FaTimes className="mr-2" />
                                Reject
                              </button>
                            </div>
                          }
                        />
                      ))}
                    </div>
                  ) : (
                    <EmptyState
                      message="No pending friend requests."
                      icon={<FaUserClock className="text-7xl" />}
                    />
                  )}
                </>
              )}
              {activeTab === "myFriends" && (
                <>
                  {friends.length > 0 ? (
                    <div className="space-y-4">
                      {friends.map((friend) => (
                        <UserCard
                          key={friend.email}
                          user={friend}
                          actionButton={
                            <button
                              className="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-6 rounded-full transition duration-200 flex items-center"
                              onClick={() => removeFriendHandler(friend.email)}
                            >
                              <FaUserMinus className="mr-2" />
                              Remove
                            </button>
                          }
                        />
                      ))}
                    </div>
                  ) : (
                    <EmptyState
                      message="You don't have any friends yet."
                      icon={<FaUserFriends className="text-7xl" />}
                    />
                  )}
                </>
              )}
            </>
          )}
        </AnimatePresence>
      </div>
      {showConfirmModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-sm w-full">
            <h2 className="text-xl font-semibold mb-4">Confirm Action</h2>
            <p className="mb-6">
              Are you sure you want to perform this action?
            </p>
            <div className="flex justify-end space-x-4">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-full text-gray-700 hover:bg-gray-100 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirm}
                className="px-4 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Friends;
