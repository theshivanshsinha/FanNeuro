import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import {
  FaThumbsUp,
  FaThumbsDown,
  FaComment,
  FaShare,
  FaUserMinus,
  FaEye,
  FaSearch,
  FaBell,
  FaSignOutAlt,
  FaHome,
  FaRss,
  FaUserFriends,
  FaHistory,
  FaTv,
  FaUsers,
} from "react-icons/fa";

const Subscriptions = () => {
  const userData = useSelector((state) => state.user);
  const [subscribedAgencies, setSubscribedAgencies] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedAgency, setSelectedAgency] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentTime, setCurrentTime] = useState(new Date());

  const navigate = useNavigate();

  useEffect(() => {
    fetchSubscribedAgencies();
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const fetchSubscribedAgencies = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await axios.get(
        `http://localhost:5000/user_subscribed_agencies/${userData.email}`
      );
      console.log(response.data);
      setSubscribedAgencies(response.data.subscribedAgencies || []);
    } catch (error) {
      setError("Error fetching subscribed agencies");
    } finally {
      setIsLoading(false);
    }
  };

  const handleLike = async (videoName) => {
    try {
      await axios.post("http://localhost:5000/like_video", {
        videoName: videoName,
        userEmail: userData.email,
      });
      fetchSubscribedAgencies();
    } catch (error) {
      console.error("Error liking video:", error);
    }
  };

  const handleUnlike = async (videoName) => {
    try {
      await axios.post("http://localhost:5000/unlike_video", {
        videoName: videoName,
        userEmail: userData.email,
      });
      fetchSubscribedAgencies();
    } catch (error) {
      console.error("Error unliking video:", error);
    }
  };

  const handleUnsubscribe = async (agencyEmail) => {
    try {
      await axios.post("http://localhost:5000/unsubscribe", {
        videoName: "",
        userEmail: userData.email,
      });
      fetchSubscribedAgencies();
    } catch (error) {
      console.error("Error unsubscribing:", error);
    }
  };

  const handleShare = (video) => {
    const shareUrl = `${window.location.origin}/video/${video._id}`;
    navigator.clipboard.writeText(shareUrl);
    alert("Video link copied to clipboard!");
  };

  const getYouTubeVideoId = (url) => {
    const regExp =
      /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return match && match[2].length === 11 ? match[2] : null;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) return "1 day ago";
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;
    return `${Math.floor(diffDays / 365)} years ago`;
  };

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleLogout = () => {
    navigate("/");
  };

  const renderAgencyDetails = () => {
    if (!selectedAgency) return null;

    const agency = subscribedAgencies.find(
      (a) => a.companyEmail === selectedAgency
    );
    if (!agency) return null;

    return (
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex items-center mb-4">
          <img
            src={agency.logo || "https://via.placeholder.com/64"}
            alt={agency.companyName}
            className="w-16 h-16 rounded-full mr-4"
          />
          <div>
            <h2 className="text-2xl font-bold">{agency.companyName}</h2>
            <p className="text-gray-600">{agency.companyEmail}</p>
          </div>
        </div>
        <div className="flex justify-between items-center">
          <p className="text-gray-600">
            <span className="font-semibold">{agency.subscriberCount || 0}</span>{" "}
            subscribers
          </p>
          <button
            onClick={() => handleUnsubscribe(agency.companyEmail)}
            className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-full transition-colors duration-200"
          >
            Unsubscribe
          </button>
        </div>
      </div>
    );
  };

  const renderVideos = () => {
    const filteredVideos = selectedAgency
      ? subscribedAgencies.find(
          (agency) => agency.companyEmail === selectedAgency
        )?.videos || []
      : subscribedAgencies.flatMap((agency) => agency.videos || []);

    return filteredVideos
      .filter((video) =>
        video.videoName.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .map((video) => (
        <div
          key={video.videoName}
          className="bg-white rounded-lg shadow-md overflow-hidden mb-6 transition-transform duration-200 hover:scale-105"
        >
          <div className="relative pb-[56.25%]">
            <iframe
              src={`https://www.youtube.com/embed/${getYouTubeVideoId(
                video.youtubeLink
              )}`}
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="absolute top-0 left-0 w-full h-full"
            ></iframe>
          </div>
          <div className="p-4">
            <h3 className="text-lg font-semibold mb-2 line-clamp-2">
              {video.videoName}
            </h3>
            <p className="text-sm text-gray-600 mb-2 line-clamp-2">
              {video.videoDescription}
            </p>
            <div className="flex items-center text-sm text-gray-500 mb-2">
              <FaEye className="mr-1" />
              <span>{video.views} views</span>
              <span className="mx-2">•</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex space-x-4">
                <button
                  className="flex items-center text-gray-600 hover:text-blue-500 transition-colors duration-200"
                  onClick={() => handleLike(video.videoName)}
                >
                  <FaThumbsUp className="mr-1" />
                  <span>{video.likes}</span>
                </button>
                <button
                  className="flex items-center text-gray-600 hover:text-red-500 transition-colors duration-200"
                  onClick={() => handleUnlike(video.videoName)}
                >
                  <FaThumbsDown className="mr-1" />
                </button>
                <Link
                  to={`/video/${video._id}`}
                  className="flex items-center text-gray-600 hover:text-green-500 transition-colors duration-200"
                >
                  <FaComment className="mr-1" />
                  <span>{video.comments}</span>
                </Link>
                <button
                  className="flex items-center text-gray-600 hover:text-yellow-500 transition-colors duration-200"
                  onClick={() => handleShare(video)}
                >
                  <FaShare className="mr-1" />
                </button>
              </div>
            </div>
          </div>
        </div>
      ));
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-red-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center mt-8 text-red-500 font-semibold text-xl">
        Error: {error}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navigation Bar */}
      <nav className="bg-white shadow-md p-4 flex items-center justify-between fixed top-0 left-0 right-0 z-10">
        <div className="flex items-center space-x-4">
          <Link to="/" className="text-red-500 font-bold text-2xl">
            FanNeuro
          </Link>
        </div>
        <div className="flex-grow mx-8 relative">
          <input
            type="text"
            placeholder="Search videos..."
            className="w-full px-4 py-2 pl-10 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-red-300"
            value={searchTerm}
            onChange={handleSearch}
          />
          <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        </div>
        <div className="flex items-center space-x-4">
          <button className="text-gray-600 hover:text-gray-800 transition-colors duration-200">
            <FaBell className="text-xl" />
          </button>
          <Link
            to="/profile"
            className="text-gray-600 hover:text-gray-800 transition-colors duration-200"
          >
            <img
              src={userData.avatar || "https://via.placeholder.com/40"}
              alt="Profile"
              className="w-8 h-8 rounded-full border-2 border-gray-200"
            />
          </Link>
          <button
            onClick={handleLogout}
            className="text-gray-600 hover:text-gray-800 flex items-center transition-colors duration-200"
          >
            <FaSignOutAlt className="mr-2" />
            Logout
          </button>
        </div>
      </nav>

      {/* Sidebar */}
      <div className="fixed top-16 left-0 w-64 bg-white shadow-md h-full overflow-y-auto">
        <ul className="space-y-2 mt-4">
          <li>
            <Link
              to="/home"
              className="flex items-center p-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-all duration-200"
            >
              <FaHome className="mr-3 text-red-500" />
              <span>Home</span>
            </Link>
          </li>
          <li>
            <Link
              to="/subscriptions"
              className="flex items-center p-3 text-gray-700 bg-gray-100 rounded-lg transition-all duration-200"
            >
              <FaRss className="mr-3 text-red-500" />
              <span>Subscriptions</span>
            </Link>
          </li>
          <li>
            <Link
              to="/friends"
              className="flex items-center p-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-all duration-200"
            >
              <FaUserFriends className="mr-3 text-red-500" />
              <span>Friends</span>
            </Link>
          </li>
          <li>
            <Link
              to="/watch-history"
              className="flex items-center p-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-all duration-200"
            >
              <FaHistory className="mr-3 text-red-500" />
              <span>Watch History</span>
            </Link>
          </li>
          <li>
            <Link
              to="/host-watch-party"
              className="flex items-center p-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-all duration-200"
            >
              <FaTv className="mr-3 text-red-500" />
              <span>Host Watch Party</span>
            </Link>
          </li>
          <li>
            <Link
              to="/join-watch-party"
              className="flex items-center p-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-all duration-200"
            >
              <FaUsers className="mr-3 text-red-500" />
              <span>Join Watch Party</span>
            </Link>
          </li>
        </ul>
      </div>

      {/* Main Content */}
      <div className="container mx-auto mt-24 p-4 ml-64">
        <h1 className="text-3xl font-bold mb-6 text-gray-800">Subscriptions</h1>
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="col-span-1 bg-white rounded-lg shadow-md p-4">
            <h2 className="text-xl font-semibold mb-4">Subscribed Agencies</h2>
            <ul className="space-y-2">
              {subscribedAgencies.map((agency) => (
                <li
                  key={agency.companyEmail}
                  className={`p-2 rounded-lg cursor-pointer transition-colors duration-200 ${
                    selectedAgency === agency.companyEmail
                      ? "bg-red-100"
                      : "hover:bg-gray-100"
                  }`}
                  onClick={() => setSelectedAgency(agency.companyEmail)}
                >
                  <div className="flex items-center justify-between">
                    <span>{agency.companyName}</span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleUnsubscribe(agency.companyEmail);
                      }}
                      className="text-red-500 hover:text-red-700 transition-colors duration-200"
                    >
                      <FaUserMinus />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div className="col-span-3">
            {renderAgencyDetails()}
            <h2 className="text-2xl font-semibold mb-4">
              {selectedAgency
                ? `Videos from ${
                    subscribedAgencies.find(
                      (a) => a.companyEmail === selectedAgency
                    )?.companyName
                  }`
                : "All Subscribed Videos"}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {renderVideos()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Subscriptions;
