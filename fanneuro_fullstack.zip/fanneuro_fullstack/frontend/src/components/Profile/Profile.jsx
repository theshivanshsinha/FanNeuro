import React, { useState, useEffect } from "react";
import axios from "axios";
import { useSelector } from "react-redux";
import { Bar, Line } from "react-chartjs-2";
import "chart.js/auto";
import {
  FaUserFriends,
  FaVideo,
  FaChartBar,
  FaTrophy,
  FaHeartbeat,
  FaCamera,
  FaEllipsisH,
} from "react-icons/fa";
import "chartjs-adapter-date-fns";
import { enUS } from "date-fns/locale";

const Profile = () => {
  const [friends, setFriends] = useState([]);
  const [friendRequests, setFriendRequests] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [emotionStats, setEmotionStats] = useState({});
  const [engagementScore, setEngagementScore] = useState(null);
  const [heartRateData, setHeartRateData] = useState(null);

  const {
    name,
    email,
    phone,
    gender,
    city,
    age,
    date_of_birth,
    profilePictureUrl,
    videoHistory,
  } = useSelector((state) => state.user);

  const emotionData = {
    labels: Object.keys(emotionStats),
    datasets: [
      {
        label: "Duration in minutes",
        data: Object.values(emotionStats),
        backgroundColor: [
          "#4267B2",
          "#898F9C",
          "#3578E5",
          "#1877F2",
          "#00B2FF",
          "#0068FF",
        ],
      },
    ],
  };

  const weeklyEngagementLeaderboard = [
    { name: "John Doe", engagement: 70 },
    { name: "Jane Smith", engagement: 65 },
    { name: "Mike Johnson", engagement: 60 },
    { name: "Emily Brown", engagement: 55 },
    { name: "Michael Williams", engagement: 50 },
  ];

  useEffect(() => {
    const fetchEmotionStats = async () => {
      try {
        const response = await axios.get(
          `http://localhost:5000/get_emotion_stats/${email}`
        );
        setEmotionStats(response.data);
      } catch (error) {
        console.error("Error fetching emotion stats:", error);
      }
    };

    fetchEmotionStats();
  }, [email]);

  const fetchFriends = async () => {
    try {
      const response = await axios.get(
        `http://localhost:5000/friends_list?loggedInEmail=${email}`
      );
      setFriends(response.data.friends);
    } catch (error) {
      console.error("Error fetching friends:", error);
    }
  };

  const fetchFriendRequests = async () => {
    try {
      const response = await axios.get(
        `http://localhost:5000/friend_requests?loggedInEmail=${email}`
      );
      setFriendRequests(response.data.friendRequests);
    } catch (error) {
      console.error("Error fetching friend requests:", error);
    }
  };

  useEffect(() => {
    const fetchEngagementData = async () => {
      try {
        const response = await axios.get(
          `http://localhost:5000/get_user_engagement/${email}`
        );
        setEmotionStats(response.data.emotion_totals);
        setEngagementScore(response.data.engagement_score);
      } catch (error) {
        console.error("Error fetching engagement data:", error);
      }
    };

    fetchEngagementData();
  }, [email]);

  useEffect(() => {
    const fetchHeartRateData = async () => {
      try {
        const response = await axios.get(
          `http://localhost:5000/get_heart_rate_data/${email}`
        );
        setHeartRateData({
          timestamps: response.data.timestamps.map((ts) => new Date(ts)),
          heart_rates: response.data.heart_rates,
        });
      } catch (error) {
        console.error("Error fetching heart rate data:", error);
      }
    };

    fetchHeartRateData();
  }, [email]);

  useEffect(() => {
    const fetchFriends = async () => {
      try {
        const response = await axios.get(
          `http://localhost:5000/friends_list?loggedInEmail=${email}`
        );
        setFriends(response.data.friends);
      } catch (error) {
        console.error("Error fetching friends:", error);
      }
    };

    const fetchFriendRequests = async () => {
      try {
        const response = await axios.get(
          `http://localhost:5000/friend_requests?loggedInEmail=${email}`
        );
        setFriendRequests(response.data.friendRequests);
      } catch (error) {
        console.error("Error fetching friend requests:", error);
      }
    };

    const fetchAllUsers = async () => {
      try {
        const response = await axios.get("http://localhost:5000/friends");
        setAllUsers(response.data.users);
      } catch (error) {
        console.error("Error fetching all users:", error);
      }
    };

    fetchFriends();
    fetchFriendRequests();
    fetchAllUsers();
  }, [email]);

  const sendFriendRequest = async (receiverEmail) => {
    try {
      await axios.post("http://localhost:5000/send_friend_request", {
        senderEmail: email,
        receiverEmail,
      });
      alert("Friend request sent successfully!");
    } catch (error) {
      console.error("Error sending friend request:", error);
      alert("Failed to send friend request");
    }
  };

  const acceptFriendRequest = async (senderEmail) => {
    try {
      await axios.post("http://localhost:5000/accept_friend_request", {
        senderEmail,
        receiverEmail: email,
      });
      alert("Friend request accepted!");
      // Refresh friends list and friend requests
      fetchFriends();
      fetchFriendRequests();
    } catch (error) {
      console.error("Error accepting friend request:", error);
      alert("Failed to accept friend request");
    }
  };

  const removeFriend = async (friendEmail) => {
    try {
      await axios.post("http://localhost:5000/remove_friend", {
        userEmail: email,
        friendEmail,
      });
      alert("Friend removed successfully!");
      fetchFriends();
    } catch (error) {
      console.error("Error removing friend:", error);
      alert("Failed to remove friend");
    }
  };

  const removeFriendRequest = async (senderEmail) => {
    try {
      await axios.post("http://localhost:5000/remove_friend_request", {
        senderEmail,
        receiverEmail: email,
      });
      alert("Friend request removed!");
      fetchFriendRequests();
    } catch (error) {
      console.error("Error removing friend request:", error);
      alert("Failed to remove friend request");
    }
  };

  const heartRateChartData = heartRateData
    ? {
        labels: heartRateData.timestamps,
        datasets: [
          {
            label: "Heart Rate",
            data: heartRateData.heart_rates.map((rate, index) => ({
              x: heartRateData.timestamps[index],
              y: rate,
            })),
            fill: false,
            borderColor: "#1877F2",
            tension: 0.1,
          },
        ],
      }
    : null;

  return (
    <div className="bg-gray-100 min-h-screen">
      <div className="max-w-6xl mx-auto">
        {/* Cover Photo and Profile Picture */}
        <div className="relative h-80 bg-gradient-to-r from-blue-400 to-blue-600 rounded-b-lg">
          <img
            src={
              profilePictureUrl ||
              "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png"
            }
            alt="Profile"
            className="absolute bottom-0 left-8 transform translate-y-1/2 w-40 h-40 rounded-full border-4 border-white shadow-lg"
          />
        </div>

        {/* Profile Info */}
        <div className="mt-24 px-8 flex justify-between items-end">
          <div>
            <h1 className="text-4xl font-bold text-gray-800">{name}</h1>
            <p className="text-gray-600">{email}</p>
          </div>
        </div>

        {/* Main Content */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-8 px-8">
          {/* Left Column */}
          <div className="col-span-1">
            {/* About Section */}
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-semibold mb-4 text-blue-600">
                About
              </h2>
              <div className="space-y-2 text-gray-700">
                <p>
                  <strong>Phone:</strong> {phone}
                </p>
                <p>
                  <strong>Gender:</strong> {gender}
                </p>
                <p>
                  <strong>City:</strong> {city}
                </p>
                <p>
                  <strong>Age:</strong> {age}
                </p>
                <p>
                  <strong>Date of Birth:</strong> {date_of_birth}
                </p>
              </div>
            </div>

            {/* Friends Section */}
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center text-blue-600">
                <FaUserFriends className="mr-2" />
                Friends ({friends.length})
              </h2>
              <div className="grid grid-cols-3 gap-4">
                {friends.slice(0, 6).map((friend, index) => (
                  <div key={index} className="text-center">
                    <img
                      src={
                        friend.profile_photo_url ||
                        "https://via.placeholder.com/64"
                      }
                      alt={friend.name}
                      className="w-16 h-16 rounded-full mx-auto mb-2 object-cover"
                    />
                    <p className="text-sm truncate text-gray-700">
                      {friend.name}
                    </p>
                    <button
                      onClick={() => removeFriend(friend.email)}
                      className="mt-2 text-xs text-red-500 hover:underline"
                    >
                      Remove Friend
                    </button>
                  </div>
                ))}
              </div>
              {friends.length > 6 && (
                <button className="mt-4 text-blue-500 hover:underline font-semibold">
                  See All Friends
                </button>
              )}
            </div>

            {/* Friend Requests Section */}
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center text-blue-600">
                <FaUserFriends className="mr-2" />
                Friend Requests ({friendRequests.length})
              </h2>
              <div className="space-y-4">
                {friendRequests.map((request, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between"
                  >
                    <div className="flex items-center">
                      <img
                        src={
                          request.profile_photo_url ||
                          "https://via.placeholder.com/40"
                        }
                        alt={request.name}
                        className="w-10 h-10 rounded-full mr-3 object-cover"
                      />
                      <span className="text-gray-700">{request.name}</span>
                    </div>
                    <div>
                      <button
                        onClick={() => acceptFriendRequest(request.email)}
                        className="bg-blue-500 text-white px-3 py-1 rounded mr-2 hover:bg-blue-600"
                      >
                        Accept
                      </button>
                      <button
                        onClick={() => removeFriendRequest(request.email)}
                        className="bg-gray-300 text-gray-700 px-3 py-1 rounded hover:bg-gray-400"
                      >
                        Decline
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Middle Column */}
          <div className="col-span-2">
            {/* Video History */}
            {videoHistory && videoHistory.length > 0 && (
              <div className="bg-white rounded-lg shadow p-6 mb-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center text-blue-600">
                  <FaVideo className="mr-2" />
                  Video History
                </h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {videoHistory.map((video, index) => (
                    <div key={index} className="relative group">
                      <img
                        src={video}
                        alt={`Video ${index + 1}`}
                        className="w-full h-32 object-cover rounded-md"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="text-white bg-blue-500 px-3 py-1 rounded-md hover:bg-blue-600 transition">
                          Play
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Analytics Section */}
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center text-blue-600">
                <FaChartBar className="mr-2" />
                Analytics
              </h2>
              <div className="space-y-6">
                {/* Emotion Analysis */}
                <div>
                  <h3 className="text-lg font-semibold mb-2 text-gray-800">
                    Emotion Analysis
                  </h3>
                  {Object.keys(emotionStats).length > 0 ? (
                    <Bar data={emotionData} />
                  ) : (
                    <p className="text-gray-600">Loading emotion data...</p>
                  )}
                </div>

                {/* Engagement Score */}
                <div>
                  <h3 className="text-lg font-semibold mb-2 text-gray-800">
                    Engagement Score
                  </h3>
                  {engagementScore !== null ? (
                    <div>
                      <div className="text-4xl font-bold text-blue-600 mb-2">
                        {engagementScore.toFixed(1)}%
                      </div>
                      <p className="mb-4 text-gray-600">
                        Your engagement score represents how actively you
                        interact with content and other users on the platform.
                      </p>
                      {engagementScore >= 50 ? (
                        <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded">
                          <p className="text-green-700 font-semibold mb-2">
                            Great job! Your engagement score is positive.
                          </p>
                          <p className="text-green-600">To improve further:</p>
                          <ul className="list-disc list-inside text-green-600 mt-2">
                            <li>Interact more with other users' content</li>
                            <li>Create and share more of your own content</li>
                            <li>
                              Participate in community discussions and events
                            </li>
                          </ul>
                        </div>
                      ) : (
                        <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded">
                          <p className="text-yellow-700 font-semibold mb-2">
                            Your engagement score could use some improvement.
                          </p>
                          <p className="text-yellow-600">
                            Here are some ways to increase your score:
                          </p>
                          <ul className="list-disc list-inside text-yellow-600 mt-2">
                            <li>
                              Spend more time exploring content on the platform
                            </li>
                            <li>
                              Like, comment, and share posts more frequently
                            </li>
                            <li>
                              Join and participate in groups related to your
                              interests
                            </li>
                          </ul>
                        </div>
                      )}
                    </div>
                  ) : (
                    <p className="text-gray-600">Loading engagement score...</p>
                  )}
                </div>

                {/* Heart Rate Analysis */}
                <div>
                  <h3 className="text-lg font-semibold mb-2 text-gray-800 flex items-center">
                    <FaHeartbeat className="mr-2 text-red-500" />
                    Heart Rate Analysis
                  </h3>
                  {heartRateChartData ? (
                    <Line
                      data={heartRateChartData}
                      options={{
                        responsive: true,
                        plugins: {
                          title: {
                            display: true,
                            text: "Heart Rate Over Time",
                            font: { size: 16, weight: "bold" },
                          },
                        },
                        scales: {
                          x: {
                            type: "time",
                            time: {
                              unit: "minute",
                              displayFormats: {
                                minute: "HH:mm",
                              },
                            },
                            adapters: {
                              date: {
                                locale: enUS,
                              },
                            },
                            title: {
                              display: true,
                              text: "Time",
                            },
                          },
                          y: {
                            title: {
                              display: true,
                              text: "Heart Rate (BPM)",
                            },
                            suggestedMin: 40,
                            suggestedMax: 120,
                          },
                        },
                      }}
                    />
                  ) : (
                    <p className="text-gray-600">Loading heart rate data...</p>
                  )}
                </div>
                <div className="mt-6 bg-blue-50 p-4 rounded-lg">
                  <h3 className="text-lg font-semibold mb-2 text-blue-800">
                    Understanding Your Heart Rate During Video Viewing
                  </h3>
                  <p className="mb-4 text-blue-700">
                    Your heart rate can provide valuable insights into your
                    emotional and physiological responses to video content.
                    Here's what the graph above might reveal:
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-blue-600">
                    <li>
                      <strong>Emotional Responses:</strong> Sudden spikes in
                      heart rate may indicate moments of excitement, fear, or
                      surprise in the video.
                    </li>
                    <li>
                      <strong>Content Engagement:</strong> A sustained elevated
                      heart rate throughout the video might indicate high
                      engagement with the content.
                    </li>
                    <li>
                      <strong>Physiological Arousal:</strong> Action scenes or
                      intense moments can trigger a fight-or-flight response.
                    </li>
                    <li>
                      <strong>Emotional Resonance:</strong> Strong emotional
                      content may cause noticeable changes in your heart rate
                      pattern.
                    </li>
                    <li>
                      <strong>Stress or Relaxation:</strong> Stressful content
                      might lead to elevated heart rates, while calming videos
                      could show a trend of decreasing heart rate.
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Suggested Friends Section */}
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center text-blue-600">
                <FaUserFriends className="mr-2" />
                Suggested Friends
              </h2>
              <div className="grid grid-cols-3 gap-4">
                {allUsers
                  .filter(
                    (user) =>
                      user.email !== email &&
                      !friends.some((friend) => friend.email === user.email)
                  )
                  .slice(0, 6)
                  .map((user, index) => (
                    <div key={index} className="text-center">
                      <img
                        src={
                          user.profile_photo_url ||
                          "https://via.placeholder.com/64"
                        }
                        alt={user.name}
                        className="w-16 h-16 rounded-full mx-auto mb-2 object-cover"
                      />
                      <p className="text-sm truncate text-gray-700">
                        {user.name}
                      </p>
                      <button
                        onClick={() => sendFriendRequest(user.email)}
                        className="mt-2 text-xs text-blue-500 hover:underline"
                      >
                        Send Friend Request
                      </button>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
