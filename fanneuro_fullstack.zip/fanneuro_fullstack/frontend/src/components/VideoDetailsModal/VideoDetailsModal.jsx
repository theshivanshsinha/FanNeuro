import React, { useState, useEffect } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie,
} from "recharts";
import { FaEye, FaThumbsUp, FaComment, FaUsers, FaTimes } from "react-icons/fa";

const VideoDetailsModal = ({ video, onClose, agencyEmail }) => {
  const [subscribers, setSubscribers] = useState([]);
  const [activeTab, setActiveTab] = useState("engagement");

  useEffect(() => {
    const fetchSubscribers = async () => {
      try {
        const response = await fetch("http://localhost:5000/subscribers", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            companyEmail: agencyEmail,
          },
        });
        const data = await response.json();
        setSubscribers(Array.isArray(data.subscribers) ? data.subscribers : []);
      } catch (error) {
        console.error("Error fetching subscribers", error);
        setSubscribers([]);
      }
    };

    fetchSubscribers();
  }, [agencyEmail]);

  const viewsCount = video.views ? video.views.length : 0;
  const likesCount = video.likes ? video.likes.length : 0;
  const commentsCount = video.comments ? video.comments.length : 0;

  const calculateSatisfactionScore = () => {
    const viewsToLikesRatio =
      viewsCount > 0 ? (likesCount / viewsCount) * 100 : 0;
    const commentsToViewsRatio =
      viewsCount > 0 ? (commentsCount / viewsCount) * 100 : 0;
    const engagementRate =
      viewsCount > 0 ? ((likesCount + commentsCount) / viewsCount) * 100 : 0;

    const weights = {
      viewsToLikes: 0.4,
      commentsToViews: 0.3,
      engagementRate: 0.3,
    };

    return (
      viewsToLikesRatio * weights.viewsToLikes +
      commentsToViewsRatio * weights.commentsToViews +
      engagementRate * weights.engagementRate
    );
  };

  const satisfactionScore = calculateSatisfactionScore();

  const engagementData = [
    { name: "Views", value: viewsCount },
    { name: "Likes", value: likesCount },
    { name: "Comments", value: commentsCount },
  ];

  const emotionData = video.emotion_data
    ? Object.entries(video.emotion_data).map(([name, value]) => ({
        name,
        value,
      }))
    : [
        { name: "Happy", value: 0 },
        { name: "Neutral", value: 0 },
        { name: "Sad", value: 0 },
        { name: "Angry", value: 0 },
        { name: "Surprised", value: 0 },
        { name: "Fear", value: 0 },
      ];

  const COLORS = [
    "#0088FE",
    "#00C49F",
    "#FFBB28",
    "#FF8042",
    "#8884d8",
    "#82ca9d",
  ];

  const TabButton = ({ name, label, icon: Icon }) => (
    <button
      onClick={() => setActiveTab(name)}
      className={`flex items-center px-4 py-2 ${
        activeTab === name
          ? "bg-blue-500 text-white"
          : "bg-gray-200 text-gray-700 hover:bg-gray-300"
      } rounded-t-lg transition-colors duration-200`}
    >
      <Icon className="mr-2" />
      {label}
    </button>
  );

  const StatCard = ({ icon: Icon, label, value }) => (
    <div className="bg-white p-4 rounded-lg shadow-md flex items-center">
      <Icon className="text-blue-500 text-2xl mr-3" />
      <div>
        <p className="text-sm text-gray-500">{label}</p>
        <p className="text-lg font-semibold">{value}</p>
      </div>
    </div>
  );

  const getPredominantMoodTips = (emotionData) => {
    const sortedEmotions = [...emotionData].sort((a, b) => b.value - a.value);
    const predominantMood = sortedEmotions[0].name;

    const moodTips = {
      Happy: [
        "Capitalize on the positive mood by creating more uplifting content.",
        "Use bright colors and upbeat music in future videos.",
        "Encourage viewers to share their own happy experiences in the comments.",
      ],
      Neutral: [
        "Add more emotional elements to your content to evoke stronger reactions.",
        "Experiment with different storytelling techniques to engage viewers.",
        "Use more dynamic editing to maintain viewer interest.",
      ],
      Sad: [
        "Balance emotional content with hopeful or inspirational messages.",
        "Provide resources or actionable steps for viewers dealing with similar emotions.",
        "Create follow-up content that addresses the issues raised in a constructive way.",
      ],
      Angry: [
        "Address the source of anger in a constructive manner in future videos.",
        "Provide a platform for viewers to express their concerns and discuss solutions.",
        "Balance critical content with positive alternatives or calls to action.",
      ],
      Surprised: [
        "Create more content that reveals unexpected information or plot twists.",
        "Use cliffhangers or teasers to maintain viewer curiosity.",
        "Encourage viewers to share their own surprising experiences or knowledge.",
      ],
      Fear: [
        "Balance fear-inducing content with reassuring information or solutions.",
        "Provide context and factual information to help viewers process the content.",
        "Consider creating follow-up videos that address viewers' concerns.",
      ],
    };

    return (
      <div className="bg-white p-4 rounded-lg shadow-md mt-4">
        <h5 className="font-medium mb-2">
          Tips Based on Predominant Mood ({predominantMood}):
        </h5>
        <ul className="list-disc pl-5 space-y-2">
          {moodTips[predominantMood].map((tip, index) => (
            <li key={index}>{tip}</li>
          ))}
        </ul>
      </div>
    );
  };

  const getCityAnalytics = () => {
    const cityCount = subscribers.reduce((acc, sub) => {
      acc[sub.city] = (acc[sub.city] || 0) + 1;
      return acc;
    }, {});
    return Object.entries(cityCount).map(([name, value]) => ({ name, value }));
  };

  const getGenderAnalytics = () => {
    const genderCount = subscribers.reduce((acc, sub) => {
      acc[sub.gender] = (acc[sub.gender] || 0) + 1;
      return acc;
    }, {});
    return Object.entries(genderCount).map(([name, value]) => ({
      name,
      value,
    }));
  };

  const cityData = getCityAnalytics();
  const genderData = getGenderAnalytics();

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50 flex items-center justify-center">
      <div className="relative bg-white w-11/12 max-w-4xl rounded-lg shadow-xl p-6">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <FaTimes size={24} />
        </button>
        <h2 className="text-2xl font-bold mb-4 text-center text-gray-800">
          {video.videoName || "Untitled Video"}
        </h2>
        <p className="text-gray-600 mb-6 text-center">
          {video.videoDescription || "No description available"}
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <StatCard icon={FaThumbsUp} label="Likes" value={likesCount} />
          <StatCard icon={FaComment} label="Comments" value={commentsCount} />
          <StatCard
            icon={FaUsers}
            label="Subscribers"
            value={subscribers.length}
          />
          <StatCard icon={FaEye} label="Views" value={viewsCount} />
        </div>

        <div className="mb-4 flex space-x-2">
          <TabButton name="engagement" label="Engagement" icon={FaEye} />
          <TabButton
            name="satisfaction"
            label="Satisfaction"
            icon={FaThumbsUp}
          />
        </div>

        <div className="bg-gray-100 p-4 rounded-lg">
          {activeTab === "engagement" && (
            <div>
              <h4 className="font-medium mb-2">Fan Engagement</h4>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={engagementData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
          {activeTab === "satisfaction" && (
            <div>
              <h4 className="font-medium mb-2">Consumer Satisfaction</h4>
              <div className="text-center mb-4">
                <p className="text-2xl font-bold">
                  {satisfactionScore.toFixed(2)}%
                </p>
                <p className="text-sm text-gray-500">
                  Overall Satisfaction Score
                </p>
              </div>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-white p-4 rounded-lg shadow-md">
                  <h5 className="font-medium mb-2">Likes to Views Ratio</h5>
                  <p className="text-xl font-semibold">
                    {((likesCount / viewsCount) * 100).toFixed(2)}%
                  </p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-md">
                  <h5 className="font-medium mb-2">Comments to Views Ratio</h5>
                  <p className="text-xl font-semibold">
                    {((commentsCount / viewsCount) * 100).toFixed(2)}%
                  </p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-md">
                  <h5 className="font-medium mb-2">Engagement Rate</h5>
                  <p className="text-xl font-semibold">
                    {(
                      ((likesCount + commentsCount) / viewsCount) *
                      100
                    ).toFixed(2)}
                    %
                  </p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-md">
                  <h5 className="font-medium mb-2">Total Subscribers</h5>
                  <p className="text-xl font-semibold">{subscribers.length}</p>
                </div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-md">
                <h5 className="font-medium mb-2">
                  Tips to Increase Consumer Satisfaction:
                </h5>
                <ul className="list-disc pl-5 space-y-2">
                  <li>Encourage viewers to like and comment on your videos.</li>
                  <li>
                    Create engaging content that prompts discussion in the
                    comments.
                  </li>
                  <li>Respond to comments to increase viewer interaction.</li>
                  <li>
                    Optimize your video titles, descriptions, and thumbnails to
                    attract more views.
                  </li>
                  <li>
                    Consistently produce high-quality content to retain and grow
                    your subscriber base.
                  </li>
                </ul>
              </div>
              {getPredominantMoodTips(emotionData)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VideoDetailsModal;
