import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { setWatchPartyDetails } from "../../redux/store";

const JoinWatchParty = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const user = useSelector((state) => state.user);
  const [inviteLink, setInviteLink] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [requiresPassword, setRequiresPassword] = useState(false);

  const handleInviteLinkChange = (e) => {
    setInviteLink(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    const watchPartyId = inviteLink.split("/").pop();

    try {
      const response = await axios.get(
        `http://localhost:5000/api/join-watch-party/${watchPartyId}`
      );

      if (response.data) {
        const partyStartTime = new Date(
          `${response.data.date}T${response.data.time}`
        );
        const currentTime = new Date();

        if (currentTime < partyStartTime) {
          setError(
            "The watch party hasn't started yet. Please wait until the scheduled time."
          );
        } else if (response.data.hostName === user.name) {
          // If the user is the host
          dispatch(setWatchPartyDetails(response.data));
          navigate("/active-watch-party");
        } else {
          // If the user is not the host
          setRequiresPassword(true);
        }
      } else {
        setError("Invalid invite link or watch party not found.");
      }
    } catch (error) {
      console.error("Error joining watch party:", error);
      setError("Failed to join watch party. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    const watchPartyId = inviteLink.split("/").pop();

    try {
      const response = await axios.post(
        `http://localhost:5000/api/verify-watch-party-password/${watchPartyId}`,
        { password }
      );

      if (response.data.success) {
        dispatch(setWatchPartyDetails(response.data.watchPartyDetails));
        navigate(`/watch-party/${watchPartyId}`);
      } else {
        setError("Incorrect password. Please try again.");
      }
    } catch (error) {
      console.error("Error verifying password:", error);
      setError("Failed to verify password. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold mb-4">Join a Watch Party</h2>
        {!requiresPassword ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="inviteLink" className="block font-bold mb-2">
                Invite Link:
              </label>
              <input
                type="text"
                id="inviteLink"
                value={inviteLink}
                onChange={handleInviteLinkChange}
                className="border border-gray-300 p-2 w-full rounded focus:outline-none transition-colors duration-300"
                required
              />
            </div>
            {error && <p className="text-red-500">{error}</p>}
            <button
              type="submit"
              className={`bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none transition-opacity duration-300 ${
                loading ? "opacity-50 cursor-not-allowed" : ""
              }`}
              disabled={loading}
            >
              {loading ? "Joining..." : "Join Watch Party"}
            </button>
          </form>
        ) : (
          <form onSubmit={handlePasswordSubmit} className="space-y-4">
            <div>
              <label htmlFor="password" className="block font-bold mb-2">
                Password:
              </label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={handlePasswordChange}
                className="border border-gray-300 p-2 w-full rounded focus:outline-none transition-colors duration-300"
                required
              />
            </div>
            {error && <p className="text-red-500">{error}</p>}
            <button
              type="submit"
              className={`bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none transition-opacity duration-300 ${
                loading ? "opacity-50 cursor-not-allowed" : ""
              }`}
              disabled={loading}
            >
              {loading ? "Verifying..." : "Submit Password"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default JoinWatchParty;
