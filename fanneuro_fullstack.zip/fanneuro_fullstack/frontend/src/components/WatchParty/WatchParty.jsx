import React, { useState, useEffect, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useParams, useNavigate } from "react-router-dom";
import { Line, Pie } from "react-chartjs-2";
import ReactPlayer from "react-player";
import moment from "moment";
import AlertMessage from "../AlertMessage/AlertMessage";
import EmojiPicker from "emoji-picker-react";
import {
  FaRegCommentAlt,
  FaHeart,
  FaShareAlt,
  FaUserFriends,
  FaUserSlash,
  FaLink,
  FaThumbsUp,
  FaThumbsDown,
  FaComment,
  FaShare,
  FaEye,
  FaYoutube,
  FaBell,
  FaChevronDown,
  FaChevronUp,
} from "react-icons/fa";
import { clearWatchPartyDetails } from "../../redux/store";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const WatchParty = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const watchParty = useSelector((state) => state.watchParty);
  const user = useSelector((state) => state.user);
  const [isHost, setIsHost] = useState(false);
  const [isChatEnabled, setIsChatEnabled] = useState(true);
  const [chatMessages, setChatMessages] = useState([]);
  const [newComment, setNewComment] = useState("");
  const [groupSentiment, setGroupSentiment] = useState({
    Happy: Math.floor(Math.random() * 100),
    Sad: Math.floor(Math.random() * 100),
    Fear: Math.floor(Math.random() * 100),
    Angry: Math.floor(Math.random() * 100),
    Surprised: Math.floor(Math.random() * 100),
  });
  const [leaderboard, setLeaderboard] = useState([
    { user: "User1", engagement: 80, rank: 1 },
    { user: "User2", engagement: 70, rank: 2 },
    { user: "User3", engagement: 60, rank: 3 },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [videoSentiments, setVideoSentiments] = useState({});
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [partyEnded, setPartyEnded] = useState(false);
  const [inviteLink, setInviteLink] = useState(watchParty.inviteLink);
  const [showEndPartyAlert, setShowEndPartyAlert] = useState(false);
  const [participants, setParticipants] = useState([]);
  const [meetingStatus, setMeetingStatus] = useState("active");
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const emojiPickerRef = useRef(null);
  const [currentVideo, setCurrentVideo] = useState(null);
  const [currentVideoTime, setCurrentVideoTime] = useState(0);
  const [videos, setVideos] = useState([]);
  const playerRef = useRef(null);
  const [currentVideoDetails, setCurrentVideoDetails] = useState(null);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const videoListRef = useRef(null);
  const [emotion, setEmotion] = useState("Loading...");
  const [heartRate, setHeartRate] = useState("Loading...");
  const [emotionData, setEmotionData] = useState({});
  const [heartRateHistory, setHeartRateHistory] = useState([]);
  const [accumulatedHeartRate, setAccumulatedHeartRate] = useState([]);
  const [accumulatedEmotion, setAccumulatedEmotion] = useState([]);
  const [groupEmotionData, setGroupEmotionData] = useState({});
  const [groupHeartRateHistory, setGroupHeartRateHistory] = useState([]);
  const [showVideoList, setShowVideoList] = useState(true);
  // New state variables for search and filtering
  const [searchTerm, setSearchTerm] = useState("");
  const [filterMood, setFilterMood] = useState("");
  const [sortBy, setSortBy] = useState("default");
  const [videoMood, setVideoMood] = useState("");
  const [groupEngagement, setGroupEngagement] = useState(50);
  const [averageHeartRate, setAverageHeartRate] = useState(70);

  useEffect(() => {
    fetch("http://localhost:5000/start_emotion_detection", { method: "POST" });

    return () => {
      fetch("http://localhost:5000/stop_emotion_detection", { method: "POST" });
    };
  }, [currentVideo]);

  const fetchWatchPartyState = async () => {
    try {
      const response = await axios.get(
        `http://localhost:5000/api/watch-party-state/${id}`
      );
      return response.data;
    } catch (error) {
      console.error("Error fetching watch party state:", error);
      return null;
    }
  };

  useEffect(() => {
    const updateGroupEngagement = () => {
      setGroupEngagement(getRandomEngagement());
    };

    // Update group engagement every 5 seconds
    const interval = setInterval(updateGroupEngagement, 5000);

    // Initial update
    updateGroupEngagement();

    // Clean up interval on component unmount
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const pollInterval = setInterval(async () => {
      const state = await fetchWatchPartyState();
      if (state) {
        if (currentVideo !== state.currentVideo) {
          setCurrentVideo(state.currentVideo);
          if (playerRef.current) {
            playerRef.current.seekTo(state.currentVideoTime);
          }
        } else if (playerRef.current) {
          const currentTime = playerRef.current.getCurrentTime();
          const timeDifference = Math.abs(currentTime - state.currentVideoTime);
          if (timeDifference > 5) {
            playerRef.current.seekTo(state.currentVideoTime);
          }
        }
      }
    }, 5000);

    return () => clearInterval(pollInterval);
  }, [id, currentVideo]);

  const fetchVideos = async () => {
    try {
      const response = await axios.get("http://localhost:5000/all_videos");
      setVideos(response.data);
    } catch (error) {
      console.error("Error fetching videos:", error);
      setError("Failed to fetch videos. Please try again.");
    }
  };

  useEffect(() => {
    fetchVideos();
  }, []);

  const playVideo = async (videoId) => {
    if (!isHost) {
      toast.info("Only the host can change videos.", {
        position: "top-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
      });
      return;
    }

    try {
      const videoToPlay = videos.find((v) => v._id === videoId);
      if (videoToPlay) {
        setCurrentVideo(videoToPlay.youtubeLink);
        setCurrentVideoDetails(videoToPlay);
        setVideoMood(videoToPlay.mood);
        await axios.post(`http://localhost:5000/api/update-watch-party/${id}`, {
          currentVideo: videoToPlay.youtubeLink,
          currentVideoTime: 0,
        });
      }
    } catch (error) {
      console.error("Error playing video:", error);
      setError("Failed to play the selected video. Please try again.");
    }
  };

  const calculateIndividualEngagement = (userEmotion, videoMood) => {
    const engagementScores = {
      happy: {
        happy: 100,
        excited: 90,
        neutral: 70,
        calm: 60,
        sad: 40,
        angry: 30,
        fearful: 20,
      },
      sad: {
        sad: 100,
        fearful: 80,
        angry: 70,
        neutral: 60,
        calm: 50,
        happy: 30,
        excited: 20,
      },
      excited: {
        excited: 100,
        happy: 90,
        neutral: 70,
        calm: 50,
        sad: 30,
        angry: 40,
        fearful: 20,
      },
      calm: {
        calm: 100,
        neutral: 90,
        happy: 80,
        sad: 60,
        excited: 50,
        fearful: 40,
        angry: 30,
      },
    };

    if (
      engagementScores[videoMood] &&
      engagementScores[videoMood][userEmotion]
    ) {
      return engagementScores[videoMood][userEmotion];
    }
    return 50; // Default engagement level
  };

  const getRandomEngagement = () => {
    return Math.floor(Math.random() * (85 - 50 + 1)) + 50;
  };

  const fetchMeetingStatus = async () => {
    try {
      const response = await axios.get(
        `http://localhost:5000/api/meeting-status/${id}`
      );
      return response.data.status;
    } catch (error) {
      console.error("Error fetching meeting status:", error);
      return "error";
    }
  };

  const checkParticipantStatus = async () => {
    try {
      const response = await axios.get(
        `http://localhost:5000/api/check-participant-status/${id}/${user.name}`
      );
      return response.data.status;
    } catch (error) {
      console.error("Error checking participant status:", error);
      return "error";
    }
  };

  useEffect(() => {
    const fetchParticipantsAndStatus = async () => {
      try {
        const [participantsResponse, meetingStatus, participantStatus] =
          await Promise.all([
            axios.get(`http://localhost:5000/api/get-participants/${id}`),
            fetchMeetingStatus(),
            checkParticipantStatus(),
          ]);
        setParticipants(participantsResponse.data.participants);
        setMeetingStatus(meetingStatus);

        if (meetingStatus === "ended" && !isHost) {
          handleMeetingEnded("The host has ended the watch party.");
        } else if (meetingStatus === "expired") {
          handleMeetingEnded("The watch party has expired.");
        } else if (participantStatus === "kicked_out") {
          handleKickedOut();
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchParticipantsAndStatus();
    const intervalId = setInterval(fetchParticipantsAndStatus, 2000);
    return () => clearInterval(intervalId);
  }, [id, isHost, user.name]);

  useEffect(() => {
    setIsHost(watchParty.hostName === user.name);
    if (user.name) {
      addParticipant(user.name);
    }
  }, [id, watchParty.hostName, user.name]);

  useEffect(() => {
    if (watchParty) {
      const partyStartTime = new Date(watchParty.date + "T" + watchParty.time);
      const partyEndTime = new Date(
        partyStartTime.getTime() + watchParty.duration * 60000
      );

      const updateTimeRemaining = () => {
        const currentTime = new Date();
        if (currentTime < partyEndTime) {
          setTimeRemaining(Math.floor((partyEndTime - currentTime) / 1000));
        } else {
          setTimeRemaining(0);
          setPartyEnded(true);
          if (!isHost) {
            handleMeetingEnded("The watch party has expired.");
          } else {
            handleEndParty();
          }
        }
      };
      updateTimeRemaining();
      const timer = setInterval(updateTimeRemaining, 1000);
      return () => clearInterval(timer);
    }
  }, [watchParty, isHost]);

  useEffect(() => {
    const fetchChatMessages = async () => {
      try {
        const response = await axios.get(
          `http://localhost:5000/api/chat/${id}`
        );
        setChatMessages(response.data.chat_messages);
      } catch (error) {
        console.error("Error fetching chat messages:", error);
      }
    };

    fetchChatMessages();
    const intervalId = setInterval(fetchChatMessages, 2000);
    return () => clearInterval(intervalId);
  }, [id]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        emojiPickerRef.current &&
        !emojiPickerRef.current.contains(event.target)
      ) {
        setShowEmojiPicker(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const addParticipant = async (name) => {
    try {
      await axios.post(`http://localhost:5000/api/add-participant/${id}`, {
        name,
      });
    } catch (error) {
      console.error("Error adding participant:", error);
    }
  };

  const removeParticipant = async (name) => {
    try {
      await axios.post(`http://localhost:5000/api/remove-participant/${id}`, {
        name,
      });
    } catch (error) {
      console.error("Error removing participant:", error);
      setError("Failed to remove participant. Please try again.");
    }
  };

  const handleSendComment = async () => {
    if (newComment.trim() && isChatEnabled) {
      try {
        setIsLoading(true);
        await axios.post(`http://localhost:5000/api/chat/${id}`, {
          author: user.name,
          text: newComment,
        });
        setNewComment("");
        setIsLoading(false);
      } catch (error) {
        setIsLoading(false);
        setError("Failed to send comment. Please try again later.");
      }
    }
  };

  const handleLikeDislike = (sentiment) => {
    setVideoSentiments({ sentiment });
  };

  const handleLeaveParty = async () => {
    await removeParticipant(user.name);
    dispatch(clearWatchPartyDetails());
    navigate("/home");
  };

  const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`;
  };

  const handleMeetingEnded = (message) => {
    setError(message + " You will be redirected to the home page.");
    setTimeout(() => {
      dispatch(clearWatchPartyDetails());
      navigate("/home");
    }, 3000);
  };

  const handleKickedOut = () => {
    setError(
      "You have been removed from the watch party by the host. You will be redirected to the home page."
    );
    setTimeout(() => {
      dispatch(clearWatchPartyDetails());
      navigate("/home");
    }, 3000);
  };

  const handleEndParty = async () => {
    try {
      await axios.post(
        `http://localhost:5000/api/end-watch-party/${watchParty.watchPartyId}`
      );
      setMeetingStatus("ended");
      handleMeetingEnded("You have ended the watch party.");
      setShowEndPartyAlert(true);
    } catch (error) {
      console.error("Error ending watch party:", error);
      setError("Failed to end the watch party. Please try again.");
    }
  };

  const handleCancelEndParty = () => {
    setShowEndPartyAlert(false);
  };

  const handleKickOutMember = async (memberName) => {
    try {
      await removeParticipant(memberName);
      if (memberName === user.name) {
        handleMeetingEnded(
          "You have been removed from the watch party by the host."
        );
      }
    } catch (error) {
      console.error("Error kicking out member:", error);
      setError("Failed to remove participant. Please try again.");
    }
  };

  const handleToggleChat = () => {
    setIsChatEnabled(!isChatEnabled);
  };

  const handleCopyInviteLink = () => {
    navigator.clipboard.writeText(inviteLink);
    toast.success("Invite link copied to clipboard!", {
      position: "top-right",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
    });
  };

  const formatMessageTime = (timestamp) => {
    return moment(timestamp).format("HH:mm");
  };

  const handleEmojiClick = (emojiObject) => {
    setNewComment((prevComment) => prevComment + emojiObject.emoji);
    setShowEmojiPicker(false);
  };

  const toggleEmojiPicker = () => {
    setShowEmojiPicker(!showEmojiPicker);
  };

  const handleSubscribe = () => {
    setIsSubscribed(!isSubscribed);
    // Here you would typically make an API call to update the subscription status
  };

  const handleScroll = () => {
    if (videoListRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = videoListRef.current;
      if (scrollTop + clientHeight === scrollHeight) {
        // Load more videos here
        console.log("Reached end of video list. Load more videos.");
      }
    }
  };

  useEffect(() => {
    const updateEmotionFeed = async () => {
      try {
        const response = await fetch("http://localhost:5000/emotion_feed");
        const data = await response.json();
        setEmotion(data.emotion);
        setHeartRate(data.heart_rate);
        updateEmotionData(data.emotion);
        setHeartRateHistory((prevHistory) => [
          ...prevHistory,
          { time: new Date(), rate: data.heart_rate },
        ]);
        setAccumulatedHeartRate((prev) => [...prev, data.heart_rate]);
        setAccumulatedEmotion((prev) => [...prev, data.emotion]);
        const individualEngagement = calculateIndividualEngagement(
          data.emotion,
          videoMood
        );
        setAverageHeartRate((prevAverage) => {
          const newAverage = prevAverage * 0.7 + data.heart_rate * 0.3;
          return Math.round(newAverage);
        });
      } catch (error) {
        console.error("Error fetching emotion feed:", error);
      }
    };
    const interval = setInterval(updateEmotionFeed, 1000);
    // Send emotion stats every 5 seconds
    const statsInterval = setInterval(() => {
      setGroupHeartRateHistory((prev) => {
        const newData = [
          ...prev.slice(1),
          Math.floor(Math.random() * (120 - 60 + 1) + 60),
        ];
        return newData;
      });
    }, 1000);
    return () => {
      clearInterval(interval);
      clearInterval(statsInterval);
      sendEmotionStats(); // Send final stats when component unmounts
    };
  }, [currentVideo, videoMood]);

  const updateEmotionData = (newEmotion) => {
    setEmotionData((prevData) => {
      const updatedData = { ...prevData };
      updatedData[newEmotion] = (updatedData[newEmotion] || 0) + 1;
      return updatedData;
    });
  };

  const sendEmotionStats = async () => {
    if (!currentVideoDetails) return;

    const currentStats = {
      userEmail: user.email,
      videoName: currentVideoDetails.videoName,
      companyEmail: currentVideoDetails.agency,
      heartRate: accumulatedHeartRate,
      emotion: accumulatedEmotion,
    };

    try {
      const response = await axios.post(
        "http://localhost:5000/store_emotion_stats",
        currentStats
      );

      if (response.status === 200) {
        console.log("Emotion stats stored successfully");
      } else {
        console.error("Failed to store emotion stats");
      }
    } catch (error) {
      console.error("Error storing emotion stats:", error);
    }
  };

  // Function to fetch and update group emotion data
  const fetchGroupEmotionData = async () => {
    try {
      const response = await axios.get(
        `http://localhost:5000/api/group-emotion/${id}`
      );
      setGroupEmotionData(response.data.emotionData);
      setGroupHeartRateHistory(response.data.heartRateHistory);
    } catch (error) {
      console.error("Error fetching group emotion data:", error);
    }
  };

  useEffect(() => {
    fetchGroupEmotionData();
    const interval = setInterval(fetchGroupEmotionData, 5000);
    return () => clearInterval(interval);
  }, [id]);

  // Chart data for group emotions
  const groupEmotionChartData = {
    labels: ["Happy", "Sad", "Angry", "Surprised", "Neutral", "Fearful"],
    datasets: [
      {
        data: Array(6)
          .fill()
          .map(() => Math.floor(Math.random() * 100)),
        backgroundColor: [
          "#FF6384",
          "#36A2EB",
          "#FFCE56",
          "#4BC0C0",
          "#9966FF",
          "#FF9F40",
        ],
      },
    ],
  };

  // Chart data for group heart rate
  const groupHeartRateChartData = {
    labels: Array(20)
      .fill()
      .map((_, index) => index),
    datasets: [
      {
        label: "Group Heart Rate",
        data: Array(20)
          .fill()
          .map(() => Math.floor(Math.random() * (120 - 60 + 1) + 60)),
        borderColor: "rgb(75, 192, 192)",
        tension: 0.1,
      },
    ],
  };

  function getYouTubeVideoId(url) {
    const regExp =
      /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return match && match[2].length === 11 ? match[2] : null;
  }

  // New function to filter and sort videos
  const getFilteredAndSortedVideos = () => {
    return videos
      .filter((video) => {
        const matchesSearch = video.videoName
          .toLowerCase()
          .includes(searchTerm.toLowerCase());
        const matchesMood = !filterMood || video.mood === filterMood;
        return matchesSearch && matchesMood;
      })
      .sort((a, b) => {
        switch (sortBy) {
          case "views":
            return (b.views || 0) - (a.views || 0);
          case "likes":
            return (b.likes || 0) - (a.likes || 0);
          case "date":
            return new Date(b.uploadDate) - new Date(a.uploadDate);
          default:
            return 0;
        }
      });
  };

  if (!watchParty) {
    return <div>Loading watch party details...</div>;
  }

  return (
    <div className="flex flex-col h-screen bg-gray-100">
      <ToastContainer />

      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">FanNeuro Watch Party</h1>
            <p className="text-sm">Hosted by {watchParty.hostName}</p>
          </div>
          <div className="flex items-center space-x-4">
            <p className="mr-4">Welcome, {user.name}</p>
            <button
              className="bg-white text-blue-600 hover:bg-blue-100 font-bold py-2 px-4 rounded flex items-center transition duration-300"
              onClick={handleCopyInviteLink}
            >
              <FaLink className="mr-2" />
              Invite
            </button>
            <button
              className="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded transition duration-300"
              onClick={handleLeaveParty}
            >
              Leave Party
            </button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left sidebar - Participants */}
        <div className="w-64 bg-white shadow-lg p-4 overflow-y-auto">
          <h2 className="text-xl font-bold mb-4 border-b pb-2">
            Participants ({participants.length})
          </h2>
          <ul className="space-y-2">
            {participants.map((participant, index) => (
              <li
                key={index}
                className={`flex items-center justify-between p-2 rounded ${
                  participant === watchParty.hostName
                    ? "bg-blue-100"
                    : "hover:bg-gray-100"
                }`}
              >
                <div className="flex items-center">
                  <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center mr-2">
                    {participant[0].toUpperCase()}
                  </div>
                  <span
                    className={
                      participant === watchParty.hostName ? "font-bold" : ""
                    }
                  >
                    {participant}{" "}
                    {participant === watchParty.hostName && (
                      <span className="text-xs bg-blue-500 text-white px-2 py-1 rounded-full ml-2">
                        Host
                      </span>
                    )}
                  </span>
                </div>
                {isHost && participant !== watchParty.hostName && (
                  <button
                    onClick={() => handleKickOutMember(participant)}
                    className="text-red-500 hover:text-red-700 transition duration-300"
                    title="Remove user"
                  >
                    <FaUserSlash />
                  </button>
                )}
              </li>
            ))}
          </ul>
        </div>

        {/* Main content area */}
        <div className="flex-1 p-4 overflow-y-auto">
          {/* Video player and details */}
          <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-4">
            <div className="relative">
              <ReactPlayer
                ref={playerRef}
                url={currentVideo}
                controls
                width="100%"
                height="auto"
                style={{ aspectRatio: "16 / 9" }}
                playing={true}
                onProgress={(progress) => {
                  if (
                    isHost &&
                    Math.abs(progress.playedSeconds - currentVideoTime) > 5
                  ) {
                    axios.post(
                      `http://localhost:5000/api/update-watch-party/${id}`,
                      {
                        currentVideoTime: progress.playedSeconds,
                      }
                    );
                    setCurrentVideoTime(progress.playedSeconds);
                  }
                }}
              />
              {!partyEnded && (
                <div className="absolute top-2 right-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded">
                  Time Remaining: {formatTime(timeRemaining)}
                </div>
              )}
            </div>
            {currentVideoDetails && (
              <div className="p-4">
                <h2 className="text-2xl font-bold mb-2">
                  {currentVideoDetails.videoName}
                </h2>
                <p className="text-gray-600 mb-4">
                  {currentVideoDetails.videoDescription}
                </p>
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center space-x-4">
                    <span className="flex items-center">
                      <FaEye className="mr-2" />
                      {currentVideoDetails.views || 0}
                    </span>
                    <button className="flex items-center space-x-1">
                      <FaThumbsUp />
                      <span>{currentVideoDetails.likes || 0}</span>
                    </button>
                    <button className="flex items-center space-x-1">
                      <FaThumbsDown />
                      <span>{currentVideoDetails.dislikes || 0}</span>
                    </button>
                  </div>
                  <button className="flex items-center space-x-1 bg-gray-200 hover:bg-gray-300 px-3 py-1 rounded transition duration-300">
                    <FaShare />
                    <span>Share</span>
                  </button>
                </div>
                <div className="flex justify-between items-center">
                  <p className="font-semibold">
                    {currentVideoDetails.agency || "Unknown Agency"}
                  </p>
                  <button
                    onClick={handleSubscribe}
                    className={`flex items-center space-x-2 px-4 py-2 rounded transition duration-300 ${
                      isSubscribed
                        ? "bg-gray-300"
                        : "bg-red-600 text-white hover:bg-red-700"
                    }`}
                  >
                    {isSubscribed ? <FaBell /> : <FaYoutube />}
                    <span>{isSubscribed ? "Subscribed" : "Subscribe"}</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Engagement and Sentiment Section */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-white p-4 rounded-lg shadow-lg">
              <h3 className="text-xl font-bold mb-2">Group Engagement</h3>
              <div className="flex justify-between items-center">
                <div className="text-6xl font-bold text-center text-blue-600">
                  {groupEngagement}%
                </div>
                <div>
                  <p className="text-lg font-semibold">Average Heart Rate</p>
                  <p className="text-4xl font-bold text-red-500">
                    {averageHeartRate} bpm
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Emotion Detection Section */}
          <div className="bg-white p-4 rounded-lg shadow-lg mb-6">
            <h3 className="text-xl font-bold mb-4">Emotion Detection</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="font-semibold mb-2">
                  Current Emotion:{" "}
                  <span className="text-blue-600">{emotion}</span>
                </p>
                <p className="font-semibold">
                  Heart Rate:{" "}
                  <span className="text-red-600">{heartRate} bpm</span>
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">
                  Personal Emotion Distribution
                </h4>
                <Pie
                  data={{
                    labels: Object.keys(emotionData),
                    datasets: [
                      {
                        data: Object.values(emotionData),
                        backgroundColor: [
                          "#FF6384",
                          "#36A2EB",
                          "#FFCE56",
                          "#4BC0C0",
                          "#9966FF",
                          "#FF9F40",
                        ],
                      },
                    ],
                  }}
                />
              </div>
            </div>
          </div>

          {/* Group Emotion Section */}
          <div className="bg-white p-4 rounded-lg shadow-lg mb-6">
            <h3 className="text-xl font-bold mb-4">Group Emotions</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold mb-2">
                  Group Emotion Distribution
                </h4>
                <Pie data={groupEmotionChartData} />
              </div>
            </div>
          </div>
        </div>

        {/* Right sidebar - Chat and Video List */}
        <div className="w-80 bg-white shadow-lg flex flex-col">
          {/* Chat Section */}
          <div className="flex-1 flex flex-col">
            <h3 className="text-xl font-bold p-4 bg-gray-100">Chat</h3>
            <div className="flex-1 overflow-y-auto p-4">
              {chatMessages.map((message, index) => (
                <div
                  key={index}
                  className={`mb-2 p-2 rounded-lg max-w-[70%] ${
                    message.author === user.name
                      ? "ml-auto bg-blue-100"
                      : "bg-gray-100"
                  }`}
                >
                  <p className="text-sm font-semibold mb-1">{message.author}</p>
                  <p className="mb-1">{message.text}</p>
                  <p className="text-xs text-gray-500">
                    {formatMessageTime(message.timestamp)}
                  </p>
                </div>
              ))}
            </div>
            <div className="p-4 border-t">
              <div className="flex items-center bg-gray-100 rounded-full p-2">
                <input
                  type="text"
                  className="flex-grow bg-transparent outline-none px-3"
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  disabled={!isChatEnabled}
                  placeholder="Type a message..."
                />
                <div className="relative" ref={emojiPickerRef}>
                  <button
                    onClick={toggleEmojiPicker}
                    className="text-gray-500 hover:text-gray-700 mr-2 transition duration-300"
                  >
                    😊
                  </button>
                  {showEmojiPicker && (
                    <div className="absolute bottom-10 right-0">
                      <EmojiPicker onEmojiClick={handleEmojiClick} />
                    </div>
                  )}
                </div>
                <button
                  onClick={handleSendComment}
                  className="bg-blue-500 text-white rounded-full p-2 ml-2 hover:bg-blue-600 transition duration-300"
                  disabled={!isChatEnabled || isLoading}
                >
                  {isLoading ? (
                    <span className="loading loading-spinner loading-sm"></span>
                  ) : (
                    <FaRegCommentAlt />
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Video List */}
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <h3
              className="text-xl font-bold p-4 bg-gray-100 flex justify-between items-center cursor-pointer"
              onClick={() => setShowVideoList(!showVideoList)}
            >
              Available Videos
              {showVideoList ? <FaChevronUp /> : <FaChevronDown />}
            </h3>
            {showVideoList && (
              <div className="p-4">
                <input
                  type="text"
                  placeholder="Search videos..."
                  className="w-full p-2 mb-4 border rounded"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <div className="flex justify-between mb-4">
                  <select
                    className="p-2 border rounded"
                    value={filterMood}
                    onChange={(e) => setFilterMood(e.target.value)}
                  >
                    <option value="">All Moods</option>
                    <option value="happy">Happy</option>
                    <option value="sad">Sad</option>
                    <option value="excited">Excited</option>
                    <option value="calm">Calm</option>
                  </select>
                  <select
                    className="p-2 border rounded"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                  >
                    <option value="default">Sort by</option>
                    <option value="views">Most Viewed</option>
                    <option value="likes">Most Liked</option>
                    <option value="date">Newest</option>
                  </select>
                </div>
              </div>
            )}
            <div
              ref={videoListRef}
              className="h-64 overflow-y-auto px-4 pb-4"
              onScroll={handleScroll}
            >
              {getFilteredAndSortedVideos().map((video) => (
                <div
                  key={video._id}
                  className={`mb-4 ${
                    isHost
                      ? "cursor-pointer hover:bg-gray-100"
                      : "cursor-not-allowed opacity-60"
                  } rounded-lg overflow-hidden transition duration-300`}
                  onClick={() => playVideo(video._id)}
                >
                  <div className="relative pb-[56.25%]">
                    <img
                      src={`https://img.youtube.com/vi/${getYouTubeVideoId(
                        video.youtubeLink
                      )}/0.jpg`}
                      alt={video.videoName}
                      className="absolute top-0 left-0 w-full h-full object-cover"
                    />
                    {!isHost && (
                      <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                        <span className="text-white text-sm">
                          Host-only control
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="p-2">
                    <h4 className="text-sm font-semibold mb-1 line-clamp-2">
                      {video.videoName}
                    </h4>
                    <p className="text-xs text-gray-600">
                      {video.agency || "Unknown Agency"}
                    </p>
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>{video.views || 0} views</span>
                      <span>{moment(video.uploadDate).fromNow()}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-gray-800 to-gray-900 text-white p-4">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex space-x-4">
            <button
              className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-md transition duration-300 flex items-center"
              onClick={() => handleLikeDislike("like")}
            >
              <FaHeart className="mr-2" />
              Like
            </button>
            <button
              className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md transition duration-300 flex items-center"
              onClick={() => handleLikeDislike("dislike")}
            >
              <FaThumbsDown className="mr-2" />
              Dislike
            </button>
          </div>
          {isHost && (
            <div className="flex space-x-4">
              <button
                className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md transition duration-300"
                onClick={() => setShowEndPartyAlert(true)}
              >
                End Party
              </button>
              <button
                className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md transition duration-300"
                onClick={handleToggleChat}
              >
                {isChatEnabled ? "Disable Chat" : "Enable Chat"}
              </button>
            </div>
          )}
        </div>
      </footer>

      {/* End Party Confirmation Alert */}
      {showEndPartyAlert && (
        <AlertMessage
          title="End Watch Party"
          message="Are you sure you want to end this watch party for all participants?"
          type="warning"
          onClose={() => setShowEndPartyAlert(false)}
          onConfirm={async () => {
            try {
              await axios.post(
                `http://localhost:5000/api/end-watch-party/${watchParty.watchPartyId}`
              );
              setMeetingStatus("ended");
              handleMeetingEnded("You have ended the watch party.");
            } catch (error) {
              console.error("Error ending watch party:", error);
              setError("Failed to end the watch party. Please try again.");
            }
          }}
        />
      )}

      {/* Error Alert */}
      {error && (
        <AlertMessage
          title="Error"
          message={error}
          type="error"
          onClose={() => setError(null)}
        />
      )}
    </div>
  );
};

export default WatchParty;
