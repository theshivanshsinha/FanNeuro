export const ADD_FRIEND = "ADD_FRIEND";
export const REMOVE_FRIEND_REQUEST = "REMOVE_FRIEND_REQUEST";
export const SET_FRIEND_REQUESTS = "SET_FRIEND_REQUESTS";
export const SET_FRIENDS = "SET_FRIENDS";

export const addFriend = (friend) => ({
  type: ADD_FRIEND,
  payload: friend,
});

export const removeFriendRequest = (requestId) => ({
  type: REMOVE_FRIEND_REQUEST,
  payload: requestId,
});

export const setFriendRequests = (requests) => ({
  type: SET_FRIEND_REQUESTS,
  payload: requests,
});

export const setFriends = (friends) => ({
  type: SET_FRIENDS,
  payload: friends,
});
