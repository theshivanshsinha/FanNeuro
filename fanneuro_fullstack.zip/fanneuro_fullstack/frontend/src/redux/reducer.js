import { combineReducers } from "redux";
import {
  ADD_FRIEND,
  REMOVE_FRIEND_REQUEST,
  SET_FRIEND_REQUESTS,
  SET_FRIENDS,
} from "./actions";

const user = (state = {}, action) => {
  switch (action.type) {
    case "SET_USER_DATA":
      return {
        ...state,
        user: {
          name: action.payload.name,
          email: action.payload.email,
          phone: action.payload.phone,
          gender: action.payload.gender,
          city: action.payload.city,
          age: action.payload.age,
          date_of_birth: action.payload.date_of_birth,
          profile_photo_url: action.payload.profile_photo_url,
        },
      };
    default:
      return state;
  }
};

const friends = (state = [], action) => {
  switch (action.type) {
    case SET_FRIENDS:
      return action.payload;
    case ADD_FRIEND:
      return [...state, action.payload];
    default:
      return state;
  }
};

const friendRequests = (state = [], action) => {
  switch (action.type) {
    case SET_FRIEND_REQUESTS:
      return action.payload;
    case REMOVE_FRIEND_REQUEST:
      return state.filter((request) => request.id !== action.payload);
    default:
      return state;
  }
};

export default combineReducers({
  user,
  friends,
  friendRequests,
});
