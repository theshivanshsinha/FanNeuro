// store.js
import { configureStore, createSlice, combineReducers } from "@reduxjs/toolkit";

// Initial state
const initialState = {
  user: {
    name: "",
    email: "",
    phone: "",
    gender: "",
    city: "",
    age: "",
    date_of_birth: "",
    profile_photo_url: "",
  },
  friendRequests: [],
  friends: [],
  agency: {
    companyName: "",
    companyEmail: "",
    companyTelephone: "",
    companyAddress: "",
    companyLogo: "",
  },
  watchParty: {
    isHost: false, // Add isHost to the initial state
    // other properties related to watch party
  },
};

// User slice
const userSlice = createSlice({
  name: "user",
  initialState: initialState.user,
  reducers: {
    setUserData: (state, action) => {
      return { ...state, ...action.payload };
    },
  },
});

// Agency slice
const agencySlice = createSlice({
  name: "agency",
  initialState: initialState.agency,
  reducers: {
    setAgencyData: (state, action) => {
      return { ...state, ...action.payload };
    },
  },
});

// Friend requests slice
const friendRequestsSlice = createSlice({
  name: "friendRequests",
  initialState: initialState.friendRequests,
  reducers: {
    setFriendRequests: (state, action) => action.payload,
    addFriendRequest: (state, action) => [...state, action.payload],
    removeFriendRequest: (state, action) =>
      state.filter((request) => request.email !== action.payload),
  },
});

// Friends slice
const friendsSlice = createSlice({
  name: "friends",
  initialState: initialState.friends,
  reducers: {
    setFriends: (state, action) => action.payload,
    addFriend: (state, action) => [...state, action.payload],
    removeFriend: (state, action) =>
      state.filter((friend) => friend.email !== action.payload),
  },
});

// Watch Party slice
const watchPartySlice = createSlice({
  name: "watchParty",
  initialState: initialState.watchParty,
  reducers: {
    setWatchPartyDetails: (state, action) => action.payload,
    clearWatchPartyDetails: () => initialState.watchParty,
    setIsHost: (state, action) => {
      state.isHost = action.payload;
    },
  },
});

// Export actions from slices
export const { setUserData } = userSlice.actions;
export const { setFriendRequests, addFriendRequest, removeFriendRequest } =
  friendRequestsSlice.actions;
export const { setFriends, addFriend, removeFriend } = friendsSlice.actions;
export const { setAgencyData } = agencySlice.actions;
export const { setWatchPartyDetails, clearWatchPartyDetails, setIsHost } =
  watchPartySlice.actions;

// Combine reducers
const rootReducer = combineReducers({
  user: userSlice.reducer,
  friendRequests: friendRequestsSlice.reducer,
  friends: friendsSlice.reducer,
  agency: agencySlice.reducer,
  watchParty: watchPartySlice.reducer,
});

// Configure the Redux store
const store = configureStore({
  reducer: rootReducer,
});

export default store;
